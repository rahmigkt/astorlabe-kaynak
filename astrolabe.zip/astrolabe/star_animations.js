// Star Animation System for Astrolabe
(function() {
    'use strict';
    
    // Configuration
    const config = {
        starCount: 150,
        shootingStarInterval: 4000,
        minStarSize: 1,
        maxStarSize: 3,
        animationDuration: {
            min: 15,
            max: 45
        }
    };
    
    // Create stars container
    function createStarsContainer() {
        const container = document.createElement('div');
        container.className = 'stars-container';
        document.body.appendChild(container);
        return container;
    }
    
    // Generate random number between min and max
    function random(min, max) {
        return Math.random() * (max - min) + min;
    }
    
    // Create a single star element
    function createStar() {
        const star = document.createElement('div');
        star.className = 'star';
        
        // Random position
        star.style.left = `${random(0, 100)}%`;
        star.style.top = `${random(-10, 10)}%`;
        
        // Random size
        const size = random(config.minStarSize, config.maxStarSize);
        star.style.width = `${size}px`;
        star.style.height = `${size}px`;
        
        // Random animation duration
        const duration = random(config.animationDuration.min, config.animationDuration.max);
        star.style.animationDuration = `${duration}s`;
        
        // Random animation delay
        star.style.animationDelay = `${random(0, duration)}s`;
        
        // Random opacity
        star.style.opacity = random(0.4, 1);
        
        // Add shimmer effect to some stars
        if (Math.random() > 0.7) {
            star.classList.add('shimmer');
            star.style.animation = `shimmer ${random(2, 4)}s ease-in-out infinite`;
        }
        
        return star;
    }
    
    // Create shooting star
    function createShootingStar(container) {
        const shootingStar = document.createElement('div');
        shootingStar.className = 'shooting-star';
        
        // Random starting position (top-right area)
        shootingStar.style.right = `${random(-20, 30)}%`;
        shootingStar.style.top = `${random(0, 30)}%`;
        
        // Random animation duration
        shootingStar.style.animationDuration = `${random(2, 4)}s`;
        
        container.appendChild(shootingStar);
        
        // Remove after animation completes
        setTimeout(() => {
            shootingStar.remove();
        }, 4000);
    }
    
    // Initialize star field
    function initializeStarField() {
        const container = createStarsContainer();
        
        // Create static stars
        for (let i = 0; i < config.starCount; i++) {
            container.appendChild(createStar());
        }
        
        // Create shooting stars periodically
        setInterval(() => {
            if (Math.random() > 0.3) { // 70% chance of creating a shooting star
                createShootingStar(container);
            }
        }, config.shootingStarInterval);
        
        // Add parallax effect on mouse move
        document.addEventListener('mousemove', (e) => {
            const x = (e.clientX / window.innerWidth - 0.5) * 20;
            const y = (e.clientY / window.innerHeight - 0.5) * 20;
            container.style.transform = `translate(${x}px, ${y}px)`;
        });
    }
    
    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeStarField);
    } else {
        initializeStarField();
    }
    
    // Reinitialize on window resize for better distribution
    let resizeTimeout;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            const container = document.querySelector('.stars-container');
            if (container) {
                container.remove();
                initializeStarField();
            }
        }, 500);
    });
})();