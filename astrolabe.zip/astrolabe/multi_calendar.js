// Multi-Calendar Display for Astrolabe
// Displays Julian, Gregorian, Rumi, and Hijri dates in sync with astrolabe

const MultiCalendar = (function() {
    
    // Get current language
    function getCurrentLanguage() {
        return sessionStorage.getItem('astrolabeLanguage') || 'latin';
    }
    
    // Month names in different languages
    const monthNames = {
        latin: {
            gregorian: ['January', 'February', 'March', 'April', 'May', 'June',
                       'July', 'August', 'September', 'October', 'November', 'December'],
            rumi: ['March', 'April', 'May', 'June', 'July', 'August',
                  'September', 'October', 'November', 'December', 'January', 'February'],
            hijri: ['Muharram', 'Safar', "Rabi' al-Awwal", "Rabi' al-Thani",
                   "Jumada al-Awwal", "Jumada al-Thani", 'Rajab', "Sha'ban",
                   'Ramadan', 'Shawwal', "Dhu al-Qi'dah", "Dhu al-Hijjah"]
        },
        turkish: {
            gregorian: ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
                       'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'],
            rumi: ['Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos',
                  'Eylül', 'Ekim', 'Kasım', 'Aralık', 'Ocak', 'Şubat'],
            hijri: ['Muharrem', 'Safer', "Rebiülevvel", "Rebiülahir",
                   "Cemaziyelevvel", "Cemaziyelahir", 'Recep', 'Şaban',
                   'Ramazan', 'Şevval', "Zilkade", "Zilhicce"]
        },
        arabic: {
            gregorian: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                       'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'],
            rumi: ['آذار', 'نيسان', 'أيار', 'حزيران', 'تموز', 'آب',
                  'أيلول', 'تشرين الأول', 'تشرين الثاني', 'كانون الأول', 'كانون الثاني', 'شباط'],
            hijri: ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر',
                   'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان',
                   'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة']
        }
    };
    
    // Get date from astrolabe system
    function getAstrolabeDate() {
        // Try to get from existing astrolabe elements
        const year = document.getElementById('local_year')?.innerHTML || 
                    document.getElementById('yearspan')?.innerHTML || 
                    new Date().getFullYear();
        
        const month = document.getElementById('local_month')?.innerHTML || 
                     (new Date().getMonth() + 1);
        
        const day = document.getElementById('local_day')?.innerHTML || 
                   document.getElementById('daynum_span')?.innerHTML || 
                   new Date().getDate();
        
        const hour = document.getElementById('local_hour')?.innerHTML || 
                    document.getElementById('hourspan')?.innerHTML || 
                    new Date().getHours();
        
        const minute = document.getElementById('local_minutes')?.innerHTML || 
                      document.getElementById('minutesspan')?.innerHTML || 
                      new Date().getMinutes();
        
        return new Date(year, month - 1, day, hour, minute);
    }
    
    // Get Julian Date from astrolabe or calculate
    function getJulianDate(date) {
        // First try to get from astrolabe
        const astrolabeJD = document.getElementById('juliandate_span')?.innerHTML;
        if (astrolabeJD && astrolabeJD !== '') {
            return parseFloat(astrolabeJD).toFixed(6);
        }
        
        // Calculate if not available
        const a = Math.floor((14 - (date.getMonth() + 1)) / 12);
        const y = date.getFullYear() + 4800 - a;
        const m = (date.getMonth() + 1) + 12 * a - 3;
        
        const jdn = date.getDate() + Math.floor((153 * m + 2) / 5) + 365 * y + 
                   Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
        
        const jd = jdn + (date.getHours() - 12) / 24 + 
                  date.getMinutes() / 1440 + date.getSeconds() / 86400;
        
        return jd.toFixed(6);
    }
    
    // Format Gregorian date
    function getGregorianDate(date) {
        const lang = getCurrentLanguage();
        const months = monthNames[lang]?.gregorian || monthNames.latin.gregorian;
        
        return `${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
    }
    
    // Calculate Rumi date (Ottoman fiscal calendar)
    function getRumiDate(date) {
        const lang = getCurrentLanguage();
        const months = monthNames[lang]?.rumi || monthNames.latin.rumi;
        
        // Rumi calendar is 584 years behind and 13 days behind Gregorian
        let rumiYear = date.getFullYear() - 584;
        
        // Create a date 13 days earlier
        let rumiDate = new Date(date);
        rumiDate.setDate(date.getDate() - 13);
        
        // Rumi year starts on March 1 (old style)
        if (rumiDate.getMonth() < 2) { // Before March
            rumiYear--;
        }
        
        // Map to Rumi months (starting from March)
        let rumiMonth = (rumiDate.getMonth() + 10) % 12;
        
        return `${rumiDate.getDate()} ${months[rumiMonth]} ${rumiYear}`;
    }
    
    // Calculate Hijri date
    function getHijriDate(date) {
        const lang = getCurrentLanguage();
        const hijriMonths = monthNames[lang]?.hijri || monthNames.latin.hijri;
        
        // Get Julian Day
        const jd = parseFloat(getJulianDate(date));
        
        // Calculate Hijri date using Umm al-Qura algorithm approximation
        const epochJd = 1948084; // Hijri epoch (16 July 622 CE)
        const daysSinceEpoch = jd - epochJd;
        
        // Average lunar year is 354.367 days
        const lunarYear = 354.36707;
        const hijriYear = Math.floor(daysSinceEpoch / lunarYear) + 1;
        
        // Calculate month and day
        const yearRemainder = daysSinceEpoch % lunarYear;
        const lunarMonth = 29.530588; // Average lunar month
        const hijriMonth = Math.floor(yearRemainder / lunarMonth) + 1;
        const hijriDay = Math.floor(yearRemainder % lunarMonth) + 1;
        
        // Ensure month is within bounds
        const monthIndex = Math.min(Math.max(hijriMonth - 1, 0), 11);
        
        return `${hijriDay} ${hijriMonths[monthIndex]} ${hijriYear}`;
    }
    
    // Update all date displays
    function updateDates() {
        const date = getAstrolabeDate();
        
        // Update Julian
        const julianDisplay = document.getElementById('julian-display');
        if (julianDisplay) {
            julianDisplay.textContent = getJulianDate(date);
        }
        
        // Update Gregorian
        const gregorianDisplay = document.getElementById('gregorian-display');
        if (gregorianDisplay) {
            gregorianDisplay.textContent = getGregorianDate(date);
        }
        
        // Update Rumi
        const rumiDisplay = document.getElementById('rumi-display');
        if (rumiDisplay) {
            rumiDisplay.textContent = getRumiDate(date);
        }
        
        // Update Hijri
        const hijriDisplay = document.getElementById('hijri-display');
        if (hijriDisplay) {
            hijriDisplay.textContent = getHijriDate(date);
        }
    }
    
    // Initialize
    function init() {
        // Initial update
        updateDates();
        
        // Listen for changes in astrolabe time
        const observer = new MutationObserver(updateDates);
        
        // Observe changes to time elements
        const timeElements = [
            'juliandate_span', 'local_year', 'local_month', 
            'local_day', 'local_hour', 'local_minutes',
            'yearspan', 'daynum_span', 'hourspan', 'minutesspan'
        ];
        
        timeElements.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                observer.observe(element, { 
                    childList: true, 
                    characterData: true, 
                    subtree: true 
                });
            }
        });
        
        // Also update periodically
        setInterval(updateDates, 1000);
    }
    
    // Public API
    return {
        init: init,
        updateDates: updateDates
    };
})();

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', MultiCalendar.init);
} else {
    MultiCalendar.init();
}