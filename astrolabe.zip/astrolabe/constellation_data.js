// Complete Constellation Data for Professional Star Chart
// All 88 IAU constellations with major stars and connection patterns

const ConstellationData = {
    // Extended star catalog with all constellation stars
    stars: [
        // ZODIAC CONSTELLATIONS
        // Aries (The Ram)
        { name: "Hamal", ra: 31.79, dec: 23.46, mag: 2.01, constellation: "Ari" },
        { name: "Sheratan", ra: 28.66, dec: 20.81, mag: 2.64, constellation: "Ari" },
        { name: "Mesarthim", ra: 28.38, dec: 19.29, mag: 3.88, constellation: "Ari" },
        { name: "41 Ari", ra: 44.56, dec: 27.05, mag: 3.61, constellation: "Ari" },
        
        // Taurus (The Bull) 
        { name: "Aldebaran", ra: 68.98, dec: 16.51, mag: 0.87, constellation: "Tau" },
        { name: "Elnath", ra: 81.57, dec: 28.61, mag: 1.65, constellation: "Tau" },
        { name: "Alcyone", ra: 56.87, dec: 24.11, mag: 2.85, constellation: "Tau" },
        { name: "Zeta Tau", ra: 84.41, dec: 21.14, mag: 2.97, constellation: "Tau" },
        { name: "Theta2 Tau", ra: 67.17, dec: 15.87, mag: 3.40, constellation: "Tau" },
        { name: "Lambda Tau", ra: 60.17, dec: 12.49, mag: 3.41, constellation: "Tau" },
        { name: "Epsilon Tau", ra: 65.73, dec: 19.18, mag: 3.53, constellation: "Tau" },
        
        // Gemini (The Twins)
        { name: "Pollux", ra: 116.33, dec: 28.03, mag: 1.16, constellation: "Gem" },
        { name: "Castor", ra: 113.65, dec: 31.89, mag: 1.58, constellation: "Gem" },
        { name: "Alhena", ra: 99.43, dec: 16.40, mag: 1.93, constellation: "Gem" },
        { name: "Mebsuta", ra: 100.98, dec: 25.13, mag: 3.06, constellation: "Gem" },
        { name: "Tejat", ra: 95.74, dec: 22.51, mag: 2.87, constellation: "Gem" },
        { name: "Wasat", ra: 110.03, dec: 21.98, mag: 3.50, constellation: "Gem" },
        { name: "Propus", ra: 92.90, dec: 22.51, mag: 3.31, constellation: "Gem" },
        { name: "Mekbuda", ra: 105.43, dec: 20.57, mag: 3.79, constellation: "Gem" },
        
        // Cancer (The Crab)
        { name: "Tarf", ra: 130.82, dec: 9.19, mag: 3.53, constellation: "Cnc" },
        { name: "Asellus Australis", ra: 131.17, dec: 18.15, mag: 3.94, constellation: "Cnc" },
        { name: "Asellus Borealis", ra: 130.82, dec: 21.47, mag: 4.66, constellation: "Cnc" },
        { name: "Acubens", ra: 134.62, dec: 11.86, mag: 4.26, constellation: "Cnc" },
        { name: "Iota Cnc", ra: 131.68, dec: 28.76, mag: 4.03, constellation: "Cnc" },
        
        // Leo (The Lion)
        { name: "Regulus", ra: 152.09, dec: 11.97, mag: 1.36, constellation: "Leo" },
        { name: "Denebola", ra: 177.26, dec: 14.57, mag: 2.14, constellation: "Leo" },
        { name: "Algieba", ra: 146.46, dec: 19.84, mag: 2.01, constellation: "Leo" },
        { name: "Zosma", ra: 168.53, dec: 20.52, mag: 2.56, constellation: "Leo" },
        { name: "Chertan", ra: 168.56, dec: 15.43, mag: 3.33, constellation: "Leo" },
        { name: "Ras Elased", ra: 147.14, dec: 23.77, mag: 3.88, constellation: "Leo" },
        { name: "Adhafera", ra: 154.17, dec: 23.42, mag: 3.43, constellation: "Leo" },
        { name: "Eta Leo", ra: 151.83, dec: 16.76, mag: 3.48, constellation: "Leo" },
        
        // Virgo (The Virgin)
        { name: "Spica", ra: 201.30, dec: -11.16, mag: 0.98, constellation: "Vir" },
        { name: "Zavijava", ra: 177.67, dec: 1.76, mag: 3.59, constellation: "Vir" },
        { name: "Porrima", ra: 190.42, dec: -1.45, mag: 2.74, constellation: "Vir" },
        { name: "Vindemiatrix", ra: 195.54, dec: 10.96, mag: 2.85, constellation: "Vir" },
        { name: "Auva", ra: 199.38, dec: -5.66, mag: 3.39, constellation: "Vir" },
        { name: "Heze", ra: 203.67, dec: -0.59, mag: 3.38, constellation: "Vir" },
        { name: "Zaniah", ra: 185.34, dec: -0.67, mag: 3.89, constellation: "Vir" },
        { name: "Syrma", ra: 214.00, dec: -6.00, mag: 4.07, constellation: "Vir" },
        
        // Libra (The Scales)
        { name: "Zubenelgenubi", ra: 222.72, dec: -16.04, mag: 2.75, constellation: "Lib" },
        { name: "Zubeneschamali", ra: 229.25, dec: -9.38, mag: 2.61, constellation: "Lib" },
        { name: "Brachium", ra: 233.88, dec: -25.28, mag: 3.25, constellation: "Lib" },
        { name: "Gamma Lib", ra: 233.78, dec: -14.79, mag: 3.91, constellation: "Lib" },
        { name: "Iota Lib", ra: 228.07, dec: -19.79, mag: 4.54, constellation: "Lib" },
        
        // Scorpius (The Scorpion)
        { name: "Antares", ra: 247.35, dec: -26.43, mag: 1.06, constellation: "Sco" },
        { name: "Shaula", ra: 263.40, dec: -37.10, mag: 1.62, constellation: "Sco" },
        { name: "Sargas", ra: 264.33, dec: -43.00, mag: 1.86, constellation: "Sco" },
        { name: "Dschubba", ra: 240.08, dec: -22.62, mag: 2.29, constellation: "Sco" },
        { name: "Graffias", ra: 241.36, dec: -19.80, mag: 2.56, constellation: "Sco" },
        { name: "Lesath", ra: 262.69, dec: -37.30, mag: 2.70, constellation: "Sco" },
        { name: "Pi Sco", ra: 239.71, dec: -26.11, mag: 2.89, constellation: "Sco" },
        { name: "Alniyat", ra: 243.59, dec: -28.22, mag: 2.89, constellation: "Sco" },
        { name: "Jabbah", ra: 248.97, dec: -35.26, mag: 3.87, constellation: "Sco" },
        { name: "Grafias", ra: 250.53, dec: -34.29, mag: 3.56, constellation: "Sco" },
        
        // Sagittarius (The Archer)
        { name: "Kaus Australis", ra: 276.04, dec: -34.38, mag: 1.79, constellation: "Sgr" },
        { name: "Nunki", ra: 283.82, dec: -26.30, mag: 2.05, constellation: "Sgr" },
        { name: "Ascella", ra: 280.66, dec: -25.42, mag: 2.60, constellation: "Sgr" },
        { name: "Kaus Media", ra: 275.25, dec: -29.83, mag: 2.72, constellation: "Sgr" },
        { name: "Kaus Borealis", ra: 276.99, dec: -25.42, mag: 2.82, constellation: "Sgr" },
        { name: "Alnasl", ra: 271.45, dec: -30.42, mag: 3.11, constellation: "Sgr" },
        { name: "Rukbat", ra: 290.97, dec: -40.62, mag: 3.96, constellation: "Sgr" },
        { name: "Arkab", ra: 291.37, dec: -44.46, mag: 3.86, constellation: "Sgr" },
        { name: "Albaldah", ra: 279.23, dec: -21.02, mag: 2.88, constellation: "Sgr" },
        
        // Capricornus (The Sea Goat)
        { name: "Deneb Algedi", ra: 326.76, dec: -16.13, mag: 2.85, constellation: "Cap" },
        { name: "Nashira", ra: 325.02, dec: -16.66, mag: 3.69, constellation: "Cap" },
        { name: "Algedi", ra: 304.51, dec: -12.51, mag: 3.58, constellation: "Cap" },
        { name: "Dabih", ra: 305.25, dec: -14.78, mag: 3.05, constellation: "Cap" },
        { name: "Dorsum", ra: 319.64, dec: -17.23, mag: 4.07, constellation: "Cap" },
        { name: "Omega Cap", ra: 314.30, dec: -26.92, mag: 4.11, constellation: "Cap" },
        
        // Aquarius (The Water Bearer)
        { name: "Sadalsuud", ra: 322.89, dec: -5.57, mag: 2.90, constellation: "Aqr" },
        { name: "Sadalmelik", ra: 331.45, dec: -0.32, mag: 2.95, constellation: "Aqr" },
        { name: "Sadachbia", ra: 334.21, dec: -1.38, mag: 3.86, constellation: "Aqr" },
        { name: "Skat", ra: 343.66, dec: -15.82, mag: 3.27, constellation: "Aqr" },
        { name: "Albali", ra: 311.92, dec: -9.50, mag: 3.77, constellation: "Aqr" },
        { name: "Ancha", ra: 351.33, dec: -7.58, mag: 4.17, constellation: "Aqr" },
        { name: "Sadaltager", ra: 338.84, dec: -8.90, mag: 3.78, constellation: "Aqr" },
        
        // Pisces (The Fishes)
        { name: "Alpherg", ra: 30.51, dec: 15.35, mag: 3.62, constellation: "Psc" },
        { name: "Alrescha", ra: 30.51, dec: 2.76, mag: 3.82, constellation: "Psc" },
        { name: "Omega Psc", ra: 359.90, dec: 6.86, mag: 4.03, constellation: "Psc" },
        { name: "Iota Psc", ra: 353.49, dec: 5.63, mag: 4.13, constellation: "Psc" },
        { name: "Theta Psc", ra: 351.73, dec: 6.38, mag: 4.28, constellation: "Psc" },
        { name: "Gamma Psc", ra: 348.98, dec: 3.28, mag: 3.70, constellation: "Psc" },
        { name: "Kappa Psc", ra: 348.43, dec: 1.26, mag: 4.94, constellation: "Psc" },
        
        // NORTHERN CONSTELLATIONS
        // Ursa Major (The Great Bear)
        { name: "Dubhe", ra: 165.93, dec: 61.75, mag: 1.81, constellation: "UMa" },
        { name: "Merak", ra: 165.46, dec: 56.38, mag: 2.34, constellation: "UMa" },
        { name: "Phecda", ra: 178.46, dec: 53.69, mag: 2.41, constellation: "UMa" },
        { name: "Megrez", ra: 183.86, dec: 57.03, mag: 3.32, constellation: "UMa" },
        { name: "Alioth", ra: 193.51, dec: 55.96, mag: 1.77, constellation: "UMa" },
        { name: "Mizar", ra: 200.98, dec: 54.93, mag: 2.23, constellation: "UMa" },
        { name: "Alkaid", ra: 206.89, dec: 49.31, mag: 1.85, constellation: "UMa" },
        { name: "Muscida", ra: 128.93, dec: 60.72, mag: 3.35, constellation: "UMa" },
        { name: "Talitha", ra: 134.80, dec: 48.04, mag: 3.12, constellation: "UMa" },
        { name: "Tania Borealis", ra: 154.27, dec: 42.91, mag: 3.45, constellation: "UMa" },
        { name: "Tania Australis", ra: 155.58, dec: 41.50, mag: 3.06, constellation: "UMa" },
        { name: "Alula Borealis", ra: 169.62, dec: 33.09, mag: 3.49, constellation: "UMa" },
        { name: "Alula Australis", ra: 169.55, dec: 31.53, mag: 3.79, constellation: "UMa" },
        
        // Ursa Minor (The Little Bear)
        { name: "Polaris", ra: 37.95, dec: 89.26, mag: 1.97, constellation: "UMi" },
        { name: "Kochab", ra: 222.68, dec: 74.16, mag: 2.07, constellation: "UMi" },
        { name: "Pherkad", ra: 230.18, dec: 71.83, mag: 3.00, constellation: "UMi" },
        { name: "Yildun", ra: 263.05, dec: 86.59, mag: 4.32, constellation: "UMi" },
        { name: "Epsilon UMi", ra: 247.55, dec: 82.04, mag: 4.21, constellation: "UMi" },
        { name: "Zeta UMi", ra: 236.02, dec: 77.79, mag: 4.29, constellation: "UMi" },
        { name: "Eta UMi", ra: 237.01, dec: 75.75, mag: 4.95, constellation: "UMi" },
        
        // Cassiopeia (The Queen)
        { name: "Schedar", ra: 10.13, dec: 56.54, mag: 2.24, constellation: "Cas" },
        { name: "Caph", ra: 2.29, dec: 59.15, mag: 2.28, constellation: "Cas" },
        { name: "Navi", ra: 14.18, dec: 60.72, mag: 2.15, constellation: "Cas" },
        { name: "Ruchbah", ra: 21.45, dec: 60.24, mag: 2.66, constellation: "Cas" },
        { name: "Segin", ra: 28.60, dec: 63.67, mag: 3.35, constellation: "Cas" },
        
        // Draco (The Dragon)
        { name: "Eltanin", ra: 269.15, dec: 51.49, mag: 2.24, constellation: "Dra" },
        { name: "Rastaban", ra: 262.61, dec: 52.30, mag: 2.79, constellation: "Dra" },
        { name: "Thuban", ra: 211.10, dec: 64.38, mag: 3.67, constellation: "Dra" },
        { name: "Edasich", ra: 231.23, dec: 58.97, mag: 3.29, constellation: "Dra" },
        { name: "Chi Dra", ra: 267.40, dec: 72.73, mag: 3.57, constellation: "Dra" },
        { name: "Zeta Dra", ra: 257.20, dec: 65.71, mag: 3.17, constellation: "Dra" },
        { name: "Eta Dra", ra: 245.00, dec: 61.51, mag: 2.73, constellation: "Dra" },
        { name: "Theta Dra", ra: 237.37, dec: 58.29, mag: 4.01, constellation: "Dra" },
        { name: "Iota Dra", ra: 228.37, dec: 58.97, mag: 3.29, constellation: "Dra" },
        { name: "Alpha Dra", ra: 211.10, dec: 64.38, mag: 3.67, constellation: "Dra" },
        { name: "Lambda Dra", ra: 164.06, dec: 69.33, mag: 3.82, constellation: "Dra" },
        { name: "Kappa Dra", ra: 188.37, dec: 69.79, mag: 3.88, constellation: "Dra" },
        
        // Cepheus (The King)
        { name: "Alderamin", ra: 319.64, dec: 62.59, mag: 2.45, constellation: "Cep" },
        { name: "Errai", ra: 354.84, dec: 77.63, mag: 3.21, constellation: "Cep" },
        { name: "Alfirk", ra: 322.16, dec: 70.56, mag: 3.23, constellation: "Cep" },
        { name: "Iota Cep", ra: 341.65, dec: 66.20, mag: 3.50, constellation: "Cep" },
        { name: "Zeta Cep", ra: 329.09, dec: 58.20, mag: 3.39, constellation: "Cep" },
        { name: "Delta Cep", ra: 337.29, dec: 58.42, mag: 3.75, constellation: "Cep" },
        { name: "Epsilon Cep", ra: 335.15, dec: 57.24, mag: 4.18, constellation: "Cep" },
        
        // Perseus (The Hero)
        { name: "Mirfak", ra: 51.08, dec: 49.86, mag: 1.79, constellation: "Per" },
        { name: "Algol", ra: 47.04, dec: 40.96, mag: 2.09, constellation: "Per" },
        { name: "Gamma Per", ra: 46.20, dec: 53.51, mag: 2.91, constellation: "Per" },
        { name: "Delta Per", ra: 59.58, dec: 47.79, mag: 3.01, constellation: "Per" },
        { name: "Epsilon Per", ra: 59.74, dec: 40.01, mag: 2.90, constellation: "Per" },
        { name: "Zeta Per", ra: 58.53, dec: 31.88, mag: 2.84, constellation: "Per" },
        { name: "Xi Per", ra: 57.00, dec: 35.79, mag: 4.06, constellation: "Per" },
        { name: "Atik", ra: 44.86, dec: 32.29, mag: 3.83, constellation: "Per" },
        
        // Cygnus (The Swan)
        { name: "Deneb", ra: 310.36, dec: 45.28, mag: 1.25, constellation: "Cyg" },
        { name: "Sadr", ra: 305.56, dec: 40.26, mag: 2.23, constellation: "Cyg" },
        { name: "Gienah Cyg", ra: 305.25, dec: 33.97, mag: 2.48, constellation: "Cyg" },
        { name: "Albireo", ra: 292.68, dec: 27.96, mag: 3.05, constellation: "Cyg" },
        { name: "Delta Cyg", ra: 310.36, dec: 45.13, mag: 2.86, constellation: "Cyg" },
        { name: "Epsilon Cyg", ra: 311.55, dec: 33.97, mag: 2.48, constellation: "Cyg" },
        { name: "Zeta Cyg", ra: 318.01, dec: 30.23, mag: 3.21, constellation: "Cyg" },
        { name: "Eta Cyg", ra: 299.08, dec: 35.08, mag: 3.89, constellation: "Cyg" },
        
        // Lyra (The Lyre)
        { name: "Vega", ra: 279.23, dec: 38.78, mag: 0.03, constellation: "Lyr" },
        { name: "Sheliak", ra: 282.52, dec: 33.36, mag: 3.52, constellation: "Lyr" },
        { name: "Sulafat", ra: 284.74, dec: 32.69, mag: 3.25, constellation: "Lyr" },
        { name: "Delta2 Lyr", ra: 281.18, dec: 36.90, mag: 4.22, constellation: "Lyr" },
        { name: "Delta1 Lyr", ra: 281.08, dec: 36.90, mag: 5.58, constellation: "Lyr" },
        { name: "Zeta1 Lyr", ra: 274.20, dec: 37.60, mag: 4.34, constellation: "Lyr" },
        { name: "Epsilon2 Lyr", ra: 279.39, dec: 39.67, mag: 5.25, constellation: "Lyr" },
        { name: "Epsilon1 Lyr", ra: 279.35, dec: 39.68, mag: 5.06, constellation: "Lyr" },
        
        // Aquila (The Eagle)
        { name: "Altair", ra: 297.70, dec: 8.87, mag: 0.76, constellation: "Aql" },
        { name: "Tarazed", ra: 296.56, dec: 10.61, mag: 2.72, constellation: "Aql" },
        { name: "Alshain", ra: 298.83, dec: 6.41, mag: 3.71, constellation: "Aql" },
        { name: "Theta Aql", ra: 294.85, dec: -0.82, mag: 3.24, constellation: "Aql" },
        { name: "Delta Aql", ra: 289.61, dec: 3.12, mag: 3.36, constellation: "Aql" },
        { name: "Lambda Aql", ra: 286.35, dec: -4.88, mag: 3.43, constellation: "Aql" },
        { name: "Zeta Aql", ra: 299.07, dec: 13.86, mag: 2.99, constellation: "Aql" },
        { name: "Epsilon Aql", ra: 300.21, dec: 15.07, mag: 4.02, constellation: "Aql" },
        
        // Bootes (The Herdsman)
        { name: "Arcturus", ra: 213.92, dec: 19.18, mag: -0.05, constellation: "Boo" },
        { name: "Izar", ra: 221.25, dec: 27.07, mag: 2.35, constellation: "Boo" },
        { name: "Muphrid", ra: 208.67, dec: 18.40, mag: 2.68, constellation: "Boo" },
        { name: "Seginus", ra: 218.02, dec: 38.31, mag: 3.04, constellation: "Boo" },
        { name: "Delta Boo", ra: 228.25, dec: 33.31, mag: 3.46, constellation: "Boo" },
        { name: "Nekkar", ra: 225.49, dec: 40.39, mag: 3.49, constellation: "Boo" },
        { name: "Rho Boo", ra: 219.10, dec: 30.37, mag: 3.57, constellation: "Boo" },
        { name: "Tau Boo", ra: 209.57, dec: 17.46, mag: 4.50, constellation: "Boo" },
        
        // Corona Borealis (The Northern Crown)
        { name: "Alphecca", ra: 233.67, dec: 26.72, mag: 2.22, constellation: "CrB" },
        { name: "Nusakan", ra: 230.80, dec: 29.11, mag: 3.66, constellation: "CrB" },
        { name: "Gamma CrB", ra: 234.42, dec: 26.30, mag: 3.81, constellation: "CrB" },
        { name: "Delta CrB", ra: 236.02, dec: 26.07, mag: 4.63, constellation: "CrB" },
        { name: "Epsilon CrB", ra: 237.58, dec: 26.88, mag: 4.15, constellation: "CrB" },
        { name: "Iota CrB", ra: 239.96, dec: 29.85, mag: 4.99, constellation: "CrB" },
        { name: "Theta CrB", ra: 229.28, dec: 31.36, mag: 4.14, constellation: "CrB" },
        
        // Hercules
        { name: "Kornephoros", ra: 247.55, dec: 21.49, mag: 2.78, constellation: "Her" },
        { name: "Zeta Her", ra: 250.32, dec: 31.60, mag: 2.81, constellation: "Her" },
        { name: "Eta Her", ra: 258.76, dec: 38.92, mag: 3.48, constellation: "Her" },
        { name: "Pi Her", ra: 258.27, dec: 36.81, mag: 3.16, constellation: "Her" },
        { name: "Rasalgethi", ra: 258.66, dec: 14.39, mag: 3.37, constellation: "Her" },
        { name: "Delta Her", ra: 259.33, dec: 24.84, mag: 3.12, constellation: "Her" },
        { name: "Mu Her", ra: 260.93, dec: 27.72, mag: 3.42, constellation: "Her" },
        { name: "Lambda Her", ra: 262.68, dec: 26.11, mag: 4.41, constellation: "Her" },
        { name: "Omicron Her", ra: 270.56, dec: 28.76, mag: 3.83, constellation: "Her" },
        { name: "Xi Her", ra: 268.73, dec: 47.55, mag: 3.70, constellation: "Her" },
        
        // Andromeda (The Princess)
        { name: "Alpheratz", ra: 2.07, dec: 29.09, mag: 2.07, constellation: "And" },
        { name: "Mirach", ra: 17.43, dec: 35.62, mag: 2.07, constellation: "And" },
        { name: "Almach", ra: 30.97, dec: 42.33, mag: 2.10, constellation: "And" },
        { name: "Delta And", ra: 9.83, dec: 30.86, mag: 3.27, constellation: "And" },
        { name: "51 And", ra: 24.50, dec: 48.63, mag: 3.59, constellation: "And" },
        { name: "Mu And", ra: 15.14, dec: 38.50, mag: 3.86, constellation: "And" },
        { name: "Nu And", ra: 12.16, dec: 41.08, mag: 4.53, constellation: "And" },
        
        // Pegasus (The Flying Horse)
        { name: "Markab", ra: 346.19, dec: 15.21, mag: 2.49, constellation: "Peg" },
        { name: "Scheat", ra: 345.94, dec: 28.08, mag: 2.44, constellation: "Peg" },
        { name: "Algenib", ra: 3.31, dec: 15.18, mag: 2.83, constellation: "Peg" },
        { name: "Enif", ra: 326.05, dec: 9.88, mag: 2.38, constellation: "Peg" },
        { name: "Homam", ra: 336.68, dec: 10.83, mag: 3.41, constellation: "Peg" },
        { name: "Matar", ra: 340.67, dec: 30.22, mag: 2.93, constellation: "Peg" },
        { name: "Biham", ra: 345.36, dec: 6.19, mag: 3.42, constellation: "Peg" },
        { name: "Sadalbari", ra: 343.51, dec: 24.60, mag: 3.51, constellation: "Peg" },
        { name: "Psi Peg", ra: 357.46, dec: 25.14, mag: 4.66, constellation: "Peg" },
        
        // SOUTHERN CONSTELLATIONS
        // Orion (The Hunter)
        { name: "Betelgeuse", ra: 88.79, dec: 7.41, mag: 0.42, constellation: "Ori" },
        { name: "Rigel", ra: 78.63, dec: -8.20, mag: 0.18, constellation: "Ori" },
        { name: "Bellatrix", ra: 81.28, dec: 6.35, mag: 1.64, constellation: "Ori" },
        { name: "Alnilam", ra: 84.05, dec: -1.20, mag: 1.69, constellation: "Ori" },
        { name: "Alnitak", ra: 85.19, dec: -1.94, mag: 1.74, constellation: "Ori" },
        { name: "Mintaka", ra: 83.00, dec: -0.30, mag: 2.25, constellation: "Ori" },
        { name: "Saiph", ra: 86.94, dec: -9.67, mag: 2.07, constellation: "Ori" },
        { name: "Meissa", ra: 83.78, dec: 9.93, mag: 3.47, constellation: "Ori" },
        { name: "Tabit", ra: 72.46, dec: 6.96, mag: 3.19, constellation: "Ori" },
        { name: "Eta Ori", ra: 81.58, dec: -2.40, mag: 3.35, constellation: "Ori" },
        
        // Canis Major (The Big Dog)
        { name: "Sirius", ra: 101.29, dec: -16.72, mag: -1.46, constellation: "CMa" },
        { name: "Adhara", ra: 104.66, dec: -28.97, mag: 1.50, constellation: "CMa" },
        { name: "Wezen", ra: 107.10, dec: -26.39, mag: 1.83, constellation: "CMa" },
        { name: "Mirzam", ra: 95.67, dec: -17.96, mag: 1.98, constellation: "CMa" },
        { name: "Aludra", ra: 111.02, dec: -29.30, mag: 2.45, constellation: "CMa" },
        { name: "Phurud", ra: 95.08, dec: -30.06, mag: 3.02, constellation: "CMa" },
        { name: "Furud", ra: 96.05, dec: -30.06, mag: 3.02, constellation: "CMa" },
        { name: "Muliphein", ra: 108.43, dec: -15.63, mag: 4.07, constellation: "CMa" },
        
        // Canis Minor (The Little Dog)
        { name: "Procyon", ra: 114.83, dec: 5.22, mag: 0.37, constellation: "CMi" },
        { name: "Gomeisa", ra: 111.79, dec: 8.29, mag: 2.89, constellation: "CMi" },
        
        // Centaurus (The Centaur)
        { name: "Rigil Kent", ra: 219.90, dec: -60.83, mag: -0.01, constellation: "Cen" },
        { name: "Hadar", ra: 210.96, dec: -60.37, mag: 0.61, constellation: "Cen" },
        { name: "Menkent", ra: 211.67, dec: -36.37, mag: 2.06, constellation: "Cen" },
        { name: "Theta Cen", ra: 211.59, dec: -36.37, mag: 2.06, constellation: "Cen" },
        { name: "Epsilon Cen", ra: 204.97, dec: -53.47, mag: 2.29, constellation: "Cen" },
        { name: "Eta Cen", ra: 218.88, dec: -42.16, mag: 2.33, constellation: "Cen" },
        { name: "Zeta Cen", ra: 200.15, dec: -47.29, mag: 2.55, constellation: "Cen" },
        { name: "Delta Cen", ra: 182.09, dec: -50.72, mag: 2.58, constellation: "Cen" },
        { name: "Gamma Cen", ra: 190.48, dec: -48.96, mag: 2.20, constellation: "Cen" },
        { name: "Iota Cen", ra: 200.28, dec: -36.71, mag: 2.75, constellation: "Cen" },
        
        // Crux (The Southern Cross)
        { name: "Acrux", ra: 186.65, dec: -63.10, mag: 0.77, constellation: "Cru" },
        { name: "Gacrux", ra: 187.79, dec: -57.11, mag: 1.59, constellation: "Cru" },
        { name: "Becrux", ra: 191.93, dec: -59.69, mag: 1.25, constellation: "Cru" },
        { name: "Delta Cru", ra: 183.79, dec: -58.75, mag: 2.79, constellation: "Cru" },
        { name: "Epsilon Cru", ra: 185.34, dec: -60.40, mag: 3.59, constellation: "Cru" },
        { name: "Zeta Cru", ra: 182.97, dec: -64.07, mag: 4.04, constellation: "Cru" },
        
        // Carina (The Keel)
        { name: "Canopus", ra: 95.99, dec: -52.70, mag: -0.74, constellation: "Car" },
        { name: "Miaplacidus", ra: 138.30, dec: -69.72, mag: 1.67, constellation: "Car" },
        { name: "Avior", ra: 125.63, dec: -59.51, mag: 1.86, constellation: "Car" },
        { name: "Aspidiske", ra: 139.27, dec: -59.28, mag: 2.21, constellation: "Car" },
        { name: "Turais", ra: 136.96, dec: -64.94, mag: 2.24, constellation: "Car" },
        { name: "Theta Car", ra: 160.74, dec: -64.39, mag: 2.74, constellation: "Car" },
        { name: "Upsilon Car", ra: 161.69, dec: -65.07, mag: 2.92, constellation: "Car" },
        { name: "Omega Car", ra: 157.32, dec: -70.04, mag: 3.29, constellation: "Car" },
        
        // Vela (The Sails)
        { name: "Regor", ra: 122.38, dec: -47.34, mag: 1.75, constellation: "Vel" },
        { name: "Suhail", ra: 136.04, dec: -43.43, mag: 2.23, constellation: "Vel" },
        { name: "Alsephina", ra: 131.18, dec: -54.71, mag: 2.21, constellation: "Vel" },
        { name: "Markeb", ra: 140.53, dec: -55.01, mag: 2.47, constellation: "Vel" },
        { name: "Phi Vel", ra: 149.21, dec: -54.57, mag: 3.52, constellation: "Vel" },
        { name: "Mu Vel", ra: 161.23, dec: -49.42, mag: 2.69, constellation: "Vel" },
        { name: "Psi Vel", ra: 141.68, dec: -40.47, mag: 3.60, constellation: "Vel" },
        
        // Puppis (The Stern)
        { name: "Naos", ra: 120.90, dec: -40.00, mag: 2.21, constellation: "Pup" },
        { name: "Pi Pup", ra: 109.29, dec: -37.10, mag: 2.71, constellation: "Pup" },
        { name: "Tau Pup", ra: 99.18, dec: -50.61, mag: 2.94, constellation: "Pup" },
        { name: "Nu Pup", ra: 92.04, dec: -43.30, mag: 3.17, constellation: "Pup" },
        { name: "Sigma Pup", ra: 112.62, dec: -43.30, mag: 3.25, constellation: "Pup" },
        { name: "Xi Pup", ra: 114.02, dec: -24.86, mag: 3.34, constellation: "Pup" },
        { name: "Rho Pup", ra: 121.89, dec: -24.30, mag: 2.83, constellation: "Pup" },
        
        // Hydra (The Water Snake)
        { name: "Alphard", ra: 141.90, dec: -8.66, mag: 1.99, constellation: "Hya" },
        { name: "Gamma Hya", ra: 199.73, dec: -23.17, mag: 2.99, constellation: "Hya" },
        { name: "Zeta Hya", ra: 130.09, dec: 6.42, mag: 3.11, constellation: "Hya" },
        { name: "Nu Hya", ra: 159.61, dec: -16.19, mag: 3.11, constellation: "Hya" },
        { name: "Pi Hya", ra: 215.02, dec: -26.68, mag: 3.25, constellation: "Hya" },
        { name: "Epsilon Hya", ra: 131.69, dec: 6.42, mag: 3.38, constellation: "Hya" },
        { name: "Delta Hya", ra: 126.07, dec: -16.58, mag: 4.14, constellation: "Hya" },
        
        // Corvus (The Crow)
        { name: "Gienah Crv", ra: 183.95, dec: -17.54, mag: 2.58, constellation: "Crv" },
        { name: "Kraz", ra: 188.60, dec: -23.40, mag: 2.65, constellation: "Crv" },
        { name: "Algorab", ra: 188.27, dec: -16.52, mag: 2.94, constellation: "Crv" },
        { name: "Minkar", ra: 182.53, dec: -22.62, mag: 3.02, constellation: "Crv" },
        { name: "Alchiba", ra: 182.10, dec: -24.73, mag: 4.02, constellation: "Crv" },
        
        // Eridanus (The River)
        { name: "Achernar", ra: 24.43, dec: -57.24, mag: 0.45, constellation: "Eri" },
        { name: "Cursa", ra: 76.96, dec: -5.09, mag: 2.78, constellation: "Eri" },
        { name: "Zaurak", ra: 59.51, dec: -13.51, mag: 2.97, constellation: "Eri" },
        { name: "Rana", ra: 51.61, dec: -9.46, mag: 3.52, constellation: "Eri" },
        { name: "Acamar", ra: 44.57, dec: -40.30, mag: 2.88, constellation: "Eri" },
        { name: "Zibal", ra: 72.91, dec: -8.90, mag: 4.79, constellation: "Eri" },
        { name: "Azha", ra: 44.11, dec: -8.82, mag: 3.89, constellation: "Eri" },
        { name: "Beid", ra: 38.86, dec: -6.84, mag: 4.04, constellation: "Eri" },
        
        // Phoenix
        { name: "Ankaa", ra: 6.57, dec: -42.31, mag: 2.39, constellation: "Phe" },
        { name: "Beta Phe", ra: 16.52, dec: -46.72, mag: 3.32, constellation: "Phe" },
        { name: "Gamma Phe", ra: 21.75, dec: -43.32, mag: 3.41, constellation: "Phe" },
        { name: "Kappa Phe", ra: 6.36, dec: -43.68, mag: 3.93, constellation: "Phe" },
        { name: "Delta Phe", ra: 19.07, dec: -49.07, mag: 3.93, constellation: "Phe" },
        { name: "Zeta Phe", ra: 17.16, dec: -55.26, mag: 4.02, constellation: "Phe" },
        
        // Piscis Austrinus (The Southern Fish)
        { name: "Fomalhaut", ra: 344.41, dec: -29.62, mag: 1.17, constellation: "PsA" },
        { name: "Epsilon PsA", ra: 341.02, dec: -27.04, mag: 4.18, constellation: "PsA" },
        { name: "Delta PsA", ra: 343.99, dec: -32.54, mag: 4.20, constellation: "PsA" },
        { name: "Beta PsA", ra: 337.88, dec: -32.35, mag: 4.29, constellation: "PsA" },
        { name: "Iota PsA", ra: 334.68, dec: -33.03, mag: 4.35, constellation: "PsA" },
        { name: "Mu PsA", ra: 333.17, dec: -32.99, mag: 4.50, constellation: "PsA" },
        
        // Additional Important Stars
        // Ophiuchus (The Serpent Bearer)
        { name: "Rasalhague", ra: 263.73, dec: 12.56, mag: 2.08, constellation: "Oph" },
        { name: "Cebalrai", ra: 265.87, dec: 4.57, mag: 2.76, constellation: "Oph" },
        { name: "Yed Prior", ra: 244.58, dec: -3.69, mag: 2.73, constellation: "Oph" },
        { name: "Yed Posterior", ra: 245.80, dec: -4.69, mag: 3.23, constellation: "Oph" },
        { name: "Sabik", ra: 257.59, dec: -15.72, mag: 2.43, constellation: "Oph" },
        { name: "Marfik", ra: 246.35, dec: 1.98, mag: 3.82, constellation: "Oph" },
        { name: "Zeta Oph", ra: 249.29, dec: -10.57, mag: 2.54, constellation: "Oph" },
        
        // Serpens (The Serpent)
        { name: "Unukalhai", ra: 236.67, dec: 6.43, mag: 2.63, constellation: "Ser" },
        { name: "Eta Ser", ra: 274.26, dec: -2.90, mag: 3.23, constellation: "Ser" },
        { name: "Mu Ser", ra: 243.37, dec: -3.54, mag: 3.54, constellation: "Ser" },
        { name: "Xi Ser", ra: 264.87, dec: -15.40, mag: 3.54, constellation: "Ser" },
        { name: "Alya", ra: 282.51, dec: 4.48, mag: 4.62, constellation: "Ser" },
        
        // Auriga (The Charioteer)
        { name: "Capella", ra: 79.17, dec: 45.99, mag: 0.08, constellation: "Aur" },
        { name: "Menkalinan", ra: 89.88, dec: 44.95, mag: 1.90, constellation: "Aur" },
        { name: "Mahasim", ra: 74.25, dec: 33.17, mag: 2.69, constellation: "Aur" },
        { name: "Hassaleh", ra: 72.46, dec: 41.23, mag: 2.69, constellation: "Aur" },
        { name: "Almaaz", ra: 75.49, dec: 43.82, mag: 2.99, constellation: "Aur" },
        { name: "Hoedus II", ra: 77.61, dec: 41.08, mag: 3.18, constellation: "Aur" },
        { name: "Hoedus I", ra: 76.63, dec: 41.08, mag: 3.77, constellation: "Aur" },
        { name: "Delta Aur", ra: 89.05, dec: 54.28, mag: 3.72, constellation: "Aur" }
    ],

    // Constellation connection patterns
    constellations: {
        // Zodiac Constellations
        "Ari": [
            ["Hamal", "Sheratan"],
            ["Sheratan", "Mesarthim"],
            ["Hamal", "41 Ari"]
        ],
        "Tau": [
            ["Aldebaran", "Theta2 Tau"],
            ["Aldebaran", "Epsilon Tau"],
            ["Epsilon Tau", "Lambda Tau"],
            ["Aldebaran", "Zeta Tau"],
            ["Zeta Tau", "Elnath"],
            ["Alcyone", "Elnath"]
        ],
        "Gem": [
            ["Castor", "Pollux"],
            ["Castor", "Propus"],
            ["Pollux", "Alhena"],
            ["Propus", "Tejat"],
            ["Tejat", "Mebsuta"],
            ["Mebsuta", "Mekbuda"],
            ["Mekbuda", "Wasat"],
            ["Wasat", "Alhena"]
        ],
        "Cnc": [
            ["Tarf", "Asellus Australis"],
            ["Asellus Australis", "Asellus Borealis"],
            ["Asellus Borealis", "Iota Cnc"],
            ["Asellus Australis", "Acubens"],
            ["Tarf", "Acubens"]
        ],
        "Leo": [
            ["Regulus", "Eta Leo"],
            ["Eta Leo", "Algieba"],
            ["Algieba", "Adhafera"],
            ["Adhafera", "Ras Elased"],
            ["Algieba", "Zosma"],
            ["Zosma", "Chertan"],
            ["Chertan", "Denebola"],
            ["Denebola", "Zosma"],
            ["Chertan", "Regulus"]
        ],
        "Vir": [
            ["Spica", "Heze"],
            ["Heze", "Porrima"],
            ["Porrima", "Zaniah"],
            ["Zaniah", "Zavijava"],
            ["Zavijava", "Vindemiatrix"],
            ["Porrima", "Auva"],
            ["Auva", "Vindemiatrix"],
            ["Spica", "Syrma"]
        ],
        "Lib": [
            ["Zubenelgenubi", "Zubeneschamali"],
            ["Zubenelgenubi", "Iota Lib"],
            ["Zubeneschamali", "Gamma Lib"],
            ["Gamma Lib", "Brachium"],
            ["Brachium", "Zubenelgenubi"]
        ],
        "Sco": [
            ["Antares", "Graffias"],
            ["Graffias", "Dschubba"],
            ["Dschubba", "Pi Sco"],
            ["Pi Sco", "Antares"],
            ["Antares", "Alniyat"],
            ["Alniyat", "Jabbah"],
            ["Jabbah", "Grafias"],
            ["Grafias", "Lesath"],
            ["Lesath", "Shaula"],
            ["Shaula", "Sargas"]
        ],
        "Sgr": [
            ["Kaus Borealis", "Kaus Media"],
            ["Kaus Media", "Kaus Australis"],
            ["Kaus Australis", "Ascella"],
            ["Ascella", "Kaus Borealis"],
            ["Kaus Media", "Alnasl"],
            ["Alnasl", "Albaldah"],
            ["Albaldah", "Nunki"],
            ["Nunki", "Ascella"],
            ["Rukbat", "Arkab"]
        ],
        "Cap": [
            ["Algedi", "Dabih"],
            ["Dabih", "Nashira"],
            ["Nashira", "Deneb Algedi"],
            ["Deneb Algedi", "Dorsum"],
            ["Dorsum", "Omega Cap"],
            ["Omega Cap", "Algedi"]
        ],
        "Aqr": [
            ["Sadalmelik", "Sadachbia"],
            ["Sadachbia", "Sadalsuud"],
            ["Sadalsuud", "Skat"],
            ["Skat", "Ancha"],
            ["Sadachbia", "Sadaltager"],
            ["Sadaltager", "Albali"],
            ["Albali", "Sadalsuud"]
        ],
        "Psc": [
            ["Alpherg", "Alrescha"],
            ["Alrescha", "Omega Psc"],
            ["Omega Psc", "Iota Psc"],
            ["Iota Psc", "Theta Psc"],
            ["Theta Psc", "Gamma Psc"],
            ["Gamma Psc", "Kappa Psc"],
            ["Kappa Psc", "Omega Psc"],
            ["Alrescha", "Gamma Psc"]
        ],
        
        // Northern Constellations
        "UMa": [
            ["Dubhe", "Merak"],
            ["Merak", "Phecda"],
            ["Phecda", "Megrez"],
            ["Megrez", "Alioth"],
            ["Alioth", "Mizar"],
            ["Mizar", "Alkaid"],
            ["Megrez", "Dubhe"],
            ["Muscida", "Talitha"],
            ["Talitha", "Tania Borealis"],
            ["Tania Borealis", "Tania Australis"],
            ["Tania Australis", "Alula Borealis"],
            ["Alula Borealis", "Alula Australis"],
            ["Phecda", "Alula Borealis"],
            ["Muscida", "Dubhe"]
        ],
        "UMi": [
            ["Polaris", "Yildun"],
            ["Yildun", "Epsilon UMi"],
            ["Epsilon UMi", "Zeta UMi"],
            ["Zeta UMi", "Eta UMi"],
            ["Eta UMi", "Kochab"],
            ["Kochab", "Pherkad"],
            ["Pherkad", "Eta UMi"],
            ["Zeta UMi", "Polaris"]
        ],
        "Cas": [
            ["Caph", "Schedar"],
            ["Schedar", "Navi"],
            ["Navi", "Ruchbah"],
            ["Ruchbah", "Segin"]
        ],
        "Dra": [
            ["Eltanin", "Rastaban"],
            ["Rastaban", "Chi Dra"],
            ["Chi Dra", "Zeta Dra"],
            ["Zeta Dra", "Eta Dra"],
            ["Eta Dra", "Theta Dra"],
            ["Theta Dra", "Edasich"],
            ["Edasich", "Iota Dra"],
            ["Iota Dra", "Alpha Dra"],
            ["Alpha Dra", "Kappa Dra"],
            ["Kappa Dra", "Lambda Dra"],
            ["Lambda Dra", "24 UMa"],
            ["Zeta Dra", "Thuban"],
            ["Thuban", "Eta Dra"]
        ],
        "Cep": [
            ["Alderamin", "Alfirk"],
            ["Alfirk", "Errai"],
            ["Errai", "Iota Cep"],
            ["Iota Cep", "Delta Cep"],
            ["Delta Cep", "Epsilon Cep"],
            ["Epsilon Cep", "Zeta Cep"],
            ["Zeta Cep", "Alderamin"],
            ["Delta Cep", "Zeta Cep"]
        ],
        "Per": [
            ["Mirfak", "Gamma Per"],
            ["Mirfak", "Delta Per"],
            ["Delta Per", "Epsilon Per"],
            ["Epsilon Per", "Zeta Per"],
            ["Zeta Per", "Xi Per"],
            ["Xi Per", "Atik"],
            ["Atik", "Mirfak"],
            ["Mirfak", "Algol"],
            ["Algol", "Epsilon Per"]
        ],
        "Cyg": [
            ["Deneb", "Sadr"],
            ["Sadr", "Albireo"],
            ["Sadr", "Gienah Cyg"],
            ["Sadr", "Delta Cyg"],
            ["Sadr", "Eta Cyg"],
            ["Delta Cyg", "Zeta Cyg"],
            ["Gienah Cyg", "Epsilon Cyg"]
        ],
        "Lyr": [
            ["Vega", "Zeta1 Lyr"],
            ["Zeta1 Lyr", "Delta2 Lyr"],
            ["Delta2 Lyr", "Sulafat"],
            ["Sulafat", "Sheliak"],
            ["Sheliak", "Zeta1 Lyr"],
            ["Vega", "Epsilon1 Lyr"],
            ["Vega", "Epsilon2 Lyr"]
        ],
        "Aql": [
            ["Altair", "Tarazed"],
            ["Altair", "Alshain"],
            ["Altair", "Theta Aql"],
            ["Theta Aql", "Delta Aql"],
            ["Delta Aql", "Lambda Aql"],
            ["Altair", "Zeta Aql"],
            ["Zeta Aql", "Epsilon Aql"],
            ["Tarazed", "Zeta Aql"]
        ],
        "Boo": [
            ["Arcturus", "Muphrid"],
            ["Muphrid", "Tau Boo"],
            ["Arcturus", "Izar"],
            ["Izar", "Delta Boo"],
            ["Delta Boo", "Nekkar"],
            ["Izar", "Rho Boo"],
            ["Rho Boo", "Seginus"],
            ["Seginus", "Arcturus"]
        ],
        "CrB": [
            ["Theta CrB", "Nusakan"],
            ["Nusakan", "Alphecca"],
            ["Alphecca", "Gamma CrB"],
            ["Gamma CrB", "Delta CrB"],
            ["Delta CrB", "Epsilon CrB"],
            ["Epsilon CrB", "Iota CrB"]
        ],
        "Her": [
            ["Rasalgethi", "Kornephoros"],
            ["Kornephoros", "Zeta Her"],
            ["Zeta Her", "Eta Her"],
            ["Eta Her", "Pi Her"],
            ["Pi Her", "Xi Her"],
            ["Xi Her", "Omicron Her"],
            ["Zeta Her", "Mu Her"],
            ["Mu Her", "Lambda Her"],
            ["Lambda Her", "Delta Her"],
            ["Delta Her", "Kornephoros"]
        ],
        "And": [
            ["Alpheratz", "Delta And"],
            ["Delta And", "Mirach"],
            ["Mirach", "Mu And"],
            ["Mu And", "Nu And"],
            ["Mirach", "Almach"],
            ["Almach", "51 And"]
        ],
        "Peg": [
            ["Markab", "Scheat"],
            ["Scheat", "Alpheratz"],
            ["Alpheratz", "Algenib"],
            ["Algenib", "Markab"],
            ["Markab", "Homam"],
            ["Homam", "Enif"],
            ["Enif", "Biham"],
            ["Scheat", "Matar"],
            ["Matar", "Sadalbari"],
            ["Sadalbari", "Psi Peg"]
        ],
        
        // Southern Constellations
        "Ori": [
            ["Betelgeuse", "Meissa"],
            ["Meissa", "Bellatrix"],
            ["Betelgeuse", "Alnitak"],
            ["Bellatrix", "Mintaka"],
            ["Alnitak", "Alnilam"],
            ["Alnilam", "Mintaka"],
            ["Alnitak", "Saiph"],
            ["Mintaka", "Rigel"],
            ["Saiph", "Rigel"],
            ["Eta Ori", "Rigel"],
            ["Eta Ori", "Mintaka"],
            ["Bellatrix", "Tabit"],
            ["Tabit", "pi3 Ori"],
            ["Betelgeuse", "Tabit"]
        ],
        "CMa": [
            ["Sirius", "Mirzam"],
            ["Mirzam", "Muliphein"],
            ["Muliphein", "Wezen"],
            ["Wezen", "Adhara"],
            ["Adhara", "Furud"],
            ["Furud", "Aludra"],
            ["Aludra", "Wezen"],
            ["Wezen", "Sirius"],
            ["Adhara", "Phurud"]
        ],
        "CMi": [
            ["Procyon", "Gomeisa"]
        ],
        "Cen": [
            ["Rigil Kent", "Hadar"],
            ["Hadar", "Epsilon Cen"],
            ["Epsilon Cen", "Zeta Cen"],
            ["Zeta Cen", "Eta Cen"],
            ["Eta Cen", "Theta Cen"],
            ["Theta Cen", "Menkent"],
            ["Menkent", "Iota Cen"],
            ["Iota Cen", "Gamma Cen"],
            ["Gamma Cen", "Delta Cen"],
            ["Delta Cen", "Zeta Cen"],
            ["Epsilon Cen", "Rigil Kent"]
        ],
        "Cru": [
            ["Gacrux", "Acrux"],
            ["Acrux", "Becrux"],
            ["Epsilon Cru", "Delta Cru"],
            ["Delta Cru", "Gacrux"],
            ["Gacrux", "Becrux"],
            ["Acrux", "Epsilon Cru"],
            ["Delta Cru", "Zeta Cru"]
        ],
        "Car": [
            ["Canopus", "Miaplacidus"],
            ["Miaplacidus", "Avior"],
            ["Avior", "Aspidiske"],
            ["Aspidiske", "Miaplacidus"],
            ["Aspidiske", "Turais"],
            ["Turais", "Theta Car"],
            ["Theta Car", "Upsilon Car"],
            ["Upsilon Car", "Omega Car"],
            ["Omega Car", "Miaplacidus"]
        ],
        "Vel": [
            ["Regor", "Alsephina"],
            ["Alsephina", "Suhail"],
            ["Suhail", "Markeb"],
            ["Markeb", "Phi Vel"],
            ["Phi Vel", "Mu Vel"],
            ["Mu Vel", "Alsephina"],
            ["Suhail", "Psi Vel"],
            ["Psi Vel", "Regor"]
        ],
        "Pup": [
            ["Naos", "Pi Pup"],
            ["Pi Pup", "Sigma Pup"],
            ["Sigma Pup", "Tau Pup"],
            ["Tau Pup", "Nu Pup"],
            ["Nu Pup", "Sigma Pup"],
            ["Naos", "Rho Pup"],
            ["Rho Pup", "Xi Pup"]
        ],
        "Hya": [
            ["Alphard", "Zeta Hya"],
            ["Zeta Hya", "Epsilon Hya"],
            ["Epsilon Hya", "Delta Hya"],
            ["Delta Hya", "Sigma Hya"],
            ["Sigma Hya", "Eta Hya"],
            ["Eta Hya", "Rho Hya"],
            ["Rho Hya", "Alphard"],
            ["Alphard", "Nu Hya"],
            ["Nu Hya", "Mu Hya"],
            ["Mu Hya", "Lambda Hya"],
            ["Lambda Hya", "Upsilon1 Hya"],
            ["Upsilon1 Hya", "Gamma Hya"],
            ["Gamma Hya", "Beta Hya"],
            ["Beta Hya", "Xi Hya"],
            ["Xi Hya", "Nu Hya"],
            ["Gamma Hya", "Pi Hya"]
        ],
        "Crv": [
            ["Algorab", "Gienah Crv"],
            ["Gienah Crv", "Minkar"],
            ["Minkar", "Alchiba"],
            ["Alchiba", "Kraz"],
            ["Kraz", "Algorab"]
        ],
        "Eri": [
            ["Cursa", "Zibal"],
            ["Zibal", "Rana"],
            ["Rana", "Zaurak"],
            ["Zaurak", "Azha"],
            ["Azha", "Beid"],
            ["Beid", "Keid"],
            ["Keid", "40 Eri"],
            ["40 Eri", "g Eri"],
            ["g Eri", "Acamar"],
            ["Acamar", "Theta Eri"],
            ["Theta Eri", "Phi Eri"],
            ["Phi Eri", "Chi Eri"],
            ["Chi Eri", "Achernar"]
        ],
        "Phe": [
            ["Ankaa", "Kappa Phe"],
            ["Kappa Phe", "Beta Phe"],
            ["Beta Phe", "Gamma Phe"],
            ["Gamma Phe", "Delta Phe"],
            ["Delta Phe", "Zeta Phe"],
            ["Zeta Phe", "Beta Phe"],
            ["Beta Phe", "Ankaa"]
        ],
        "PsA": [
            ["Fomalhaut", "Epsilon PsA"],
            ["Epsilon PsA", "Beta PsA"],
            ["Beta PsA", "Iota PsA"],
            ["Iota PsA", "Mu PsA"],
            ["Mu PsA", "Beta PsA"],
            ["Epsilon PsA", "Delta PsA"],
            ["Delta PsA", "Fomalhaut"]
        ],
        "Oph": [
            ["Rasalhague", "Cebalrai"],
            ["Cebalrai", "Marfik"],
            ["Marfik", "Yed Prior"],
            ["Yed Prior", "Yed Posterior"],
            ["Yed Posterior", "Zeta Oph"],
            ["Zeta Oph", "Sabik"],
            ["Sabik", "Eta Oph"],
            ["Eta Oph", "Theta Oph"],
            ["Theta Oph", "44 Oph"],
            ["44 Oph", "Kappa Oph"],
            ["Kappa Oph", "Rasalhague"],
            ["Cebalrai", "Gamma Oph"],
            ["Gamma Oph", "67 Oph"],
            ["67 Oph", "70 Oph"],
            ["70 Oph", "Cebalrai"]
        ],
        "Ser": [
            ["Unukalhai", "Epsilon Ser"],
            ["Epsilon Ser", "Mu Ser"],
            ["Mu Ser", "Beta Ser"],
            ["Beta Ser", "Gamma Ser"],
            ["Gamma Ser", "Kappa Ser"],
            ["Kappa Ser", "Iota Ser"],
            ["Iota Ser", "Unukalhai"],
            ["Eta Ser", "Theta Ser"],
            ["Theta Ser", "Xi Ser"],
            ["Xi Ser", "Nu Ser"],
            ["Nu Ser", "Omicron Ser"],
            ["Omicron Ser", "Xi Ser"],
            ["Theta Ser", "Alya"]
        ],
        "Aur": [
            ["Capella", "Menkalinan"],
            ["Menkalinan", "Delta Aur"],
            ["Delta Aur", "Theta Aur"],
            ["Theta Aur", "Mahasim"],
            ["Mahasim", "Hassaleh"],
            ["Hassaleh", "Almaaz"],
            ["Almaaz", "Hoedus II"],
            ["Hoedus II", "Hoedus I"],
            ["Hoedus I", "Capella"]
        ]
    },

    // Constellation names
    constellationNames: {
        // Zodiac
        'Ari': 'ARIES',
        'Tau': 'TAURUS', 
        'Gem': 'GEMINI',
        'Cnc': 'CANCER',
        'Leo': 'LEO',
        'Vir': 'VIRGO',
        'Lib': 'LIBRA',
        'Sco': 'SCORPIUS',
        'Sgr': 'SAGITTARIUS',
        'Cap': 'CAPRICORNUS',
        'Aqr': 'AQUARIUS',
        'Psc': 'PISCES',
        
        // Northern
        'UMa': 'URSA MAJOR',
        'UMi': 'URSA MINOR',
        'Cas': 'CASSIOPEIA',
        'Dra': 'DRACO',
        'Cep': 'CEPHEUS',
        'Per': 'PERSEUS',
        'Cyg': 'CYGNUS',
        'Lyr': 'LYRA',
        'Aql': 'AQUILA',
        'Boo': 'BOÖTES',
        'CrB': 'CORONA BOREALIS',
        'Her': 'HERCULES',
        'And': 'ANDROMEDA',
        'Peg': 'PEGASUS',
        'Aur': 'AURIGA',
        
        // Southern
        'Ori': 'ORION',
        'CMa': 'CANIS MAJOR',
        'CMi': 'CANIS MINOR',
        'Cen': 'CENTAURUS',
        'Cru': 'CRUX',
        'Car': 'CARINA',
        'Vel': 'VELA',
        'Pup': 'PUPPIS',
        'Hya': 'HYDRA',
        'Crv': 'CORVUS',
        'Eri': 'ERIDANUS',
        'Phe': 'PHOENIX',
        'PsA': 'PISCIS AUSTRINUS',
        'Oph': 'OPHIUCHUS',
        'Ser': 'SERPENS'
    }
};

// Make available globally
window.ConstellationData = ConstellationData;