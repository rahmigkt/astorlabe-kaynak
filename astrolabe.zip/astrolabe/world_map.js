// World Map Module
// Interactive 2D projection world map synchronized with the astrolabe
// Equirectangular projection for simplicity and clarity

const WorldMap = (function() {
    let mapSVG = null;
    let marker = null;
    let isDragging = false;
    let currentLat = 40.7128; // Default: New York
    let currentLon = -74.0060;
    
    // Map dimensions
    const MAP_WIDTH = 360;
    const MAP_HEIGHT = 180;
    const MAP_SCALE = 1.5;
    
    function init() {
        createMapContainer();
        createMapSVG();
        drawWorldMap();
        createMarker();
        setupEventListeners();
        syncWithAstrolabe();
    }
    
    function createMapContainer() {
        // Find the star chart container to place the map after it
        const starChartContainer = document.querySelector('.star-chart-container');
        if (!starChartContainer) {
            // If star chart doesn't exist, place after astrolabe
            const astrolabeContainer = document.querySelector('.astrolabe-container');
            if (!astrolabeContainer) return;
            astrolabeContainer.insertAdjacentHTML('afterend', getMapHTML());
        } else {
            starChartContainer.insertAdjacentHTML('afterend', getMapHTML());
        }
    }
    
    function getMapHTML() {
        return `
            <div class="world-map-container" style="margin-top: 40px; margin-bottom: 20px;">
                <div class="world-map-header" style="text-align: center; margin-bottom: 20px;">
                    <h3 class="world-map-title" style="color: #cc4444; font-size: 1.2em; margin: 0; text-transform: uppercase; letter-spacing: 2px; font-weight: 300;">World Location Selector</h3>
                    <span class="world-map-subtitle" style="color: rgba(204, 68, 68, 0.6); font-size: 0.9em;">Click anywhere on the map to set your location</span>
                </div>
                <div class="world-map-wrapper" style="background: linear-gradient(135deg, #2a2a2a 0%, #333333 50%, #2a2a2a 100%); padding: 25px; border-radius: 15px; border: 1px solid rgba(204, 68, 68, 0.3); box-shadow: 0 10px 40px rgba(0,0,0,0.5), inset 0 1px 0 rgba(204, 68, 68, 0.2);">
                    <svg id="world-map-svg" viewBox="0 0 ${MAP_WIDTH * MAP_SCALE} ${MAP_HEIGHT * MAP_SCALE}" preserveAspectRatio="xMidYMid meet" style="width: 100%; max-width: 900px; margin: 0 auto; display: block; cursor: crosshair; filter: drop-shadow(0 5px 15px rgba(0,0,0,0.3));">
                        <defs>
                            <!-- Ocean gradient -->
                            <radialGradient id="oceanGradient" cx="50%" cy="50%" r="50%">
                                <stop offset="0%" style="stop-color:#0a2540;stop-opacity:1" />
                                <stop offset="70%" style="stop-color:#051a2e;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#020d1a;stop-opacity:1" />
                            </radialGradient>
                            
                            <!-- Land gradient patterns for different continents -->
                            <linearGradient id="landGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#661111;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#440a0a;stop-opacity:1" />
                            </linearGradient>
                            
                            <linearGradient id="landGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#771515;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#550f0f;stop-opacity:1" />
                            </linearGradient>
                            
                            <linearGradient id="desertGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" style="stop-color:#8b5555;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#6b4545;stop-opacity:1" />
                            </linearGradient>
                            
                            <!-- Glow effects -->
                            <filter id="landGlow" x="-50%" y="-50%" width="200%" height="200%">
                                <feGaussianBlur stdDeviation="0.8" result="coloredBlur"/>
                                <feMerge>
                                    <feMergeNode in="coloredBlur"/>
                                    <feMergeNode in="SourceGraphic"/>
                                </feMerge>
                            </filter>
                            
                            <filter id="cityGlow">
                                <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                                <feMerge>
                                    <feMergeNode in="coloredBlur"/>
                                    <feMergeNode in="SourceGraphic"/>
                                </feMerge>
                            </filter>
                            
                            <!-- Grid pattern -->
                            <pattern id="gridPattern" x="0" y="0" width="30" height="30" patternUnits="userSpaceOnUse">
                                <line x1="0" y1="0" x2="0" y2="30" stroke="rgba(204, 68, 68, 0.1)" stroke-width="0.5"/>
                                <line x1="0" y1="0" x2="30" y2="0" stroke="rgba(204, 68, 68, 0.1)" stroke-width="0.5"/>
                            </pattern>
                        </defs>
                    </svg>
                </div>
                <div class="world-map-info" style="text-align: center; margin-top: 15px; padding: 10px; background: rgba(51, 51, 51, 0.4); border-radius: 8px; border: 1px solid rgba(204, 68, 68, 0.2);">
                    <span id="map-lat-display" style="color: #cc4444; font-weight: 500;">Lat: --</span>
                    <span style="color: rgba(204, 68, 68, 0.4); margin: 0 10px;">|</span>
                    <span id="map-lon-display" style="color: #cc4444; font-weight: 500;">Lon: --</span>
                    <span style="color: rgba(204, 68, 68, 0.4); margin: 0 10px;">|</span>
                    <span id="map-location-name" style="color: rgb(193, 177, 88); font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">--</span>
                </div>
            </div>
        `;
    }
    
    function createMapSVG() {
        mapSVG = document.getElementById('world-map-svg');
        if (!mapSVG) return;
        
        // Background
        const bg = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        bg.setAttribute('width', MAP_WIDTH * MAP_SCALE);
        bg.setAttribute('height', MAP_HEIGHT * MAP_SCALE);
        bg.setAttribute('fill', 'url(#oceanGradient)');
        mapSVG.appendChild(bg);
        
        // Grid lines group
        const gridGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        gridGroup.setAttribute('id', 'map-grid');
        gridGroup.setAttribute('stroke', 'rgba(135, 206, 235, 0.2)');
        gridGroup.setAttribute('stroke-width', '0.5');
        gridGroup.setAttribute('fill', 'none');
        mapSVG.appendChild(gridGroup);
        
        // Land masses group
        const landGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        landGroup.setAttribute('id', 'map-land');
        landGroup.setAttribute('fill', '#cc4444');
        landGroup.setAttribute('stroke', 'rgba(204, 68, 68, 0.4)');
        landGroup.setAttribute('stroke-width', '0.5');
        landGroup.setAttribute('filter', 'url(#landGlow)');
        mapSVG.appendChild(landGroup);
    }
    
    function drawWorldMap() {
        const gridGroup = document.getElementById('map-grid');
        const landGroup = document.getElementById('map-land');
        
        if (!gridGroup || !landGroup) return;
        
        // Draw graticule (lat/lon grid)
        drawGraticule(gridGroup);
        
        // Draw detailed continents from WorldMapData
        drawDetailedContinents(landGroup);
        
        // Draw major cities
        drawCities();
        
        // Draw ocean labels
        drawOceanLabels();
    }
    
    function drawGraticule(gridGroup) {
        const data = window.WorldMapData;
        if (!data) return;
        
        // Draw meridians (longitude lines)
        for (let lon = -180; lon <= 180; lon += data.graticule.meridians) {
            const x = lonToX(lon);
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', x);
            line.setAttribute('y1', 0);
            line.setAttribute('x2', x);
            line.setAttribute('y2', MAP_HEIGHT * MAP_SCALE);
            line.setAttribute('stroke', lon === 0 ? 'rgba(135, 206, 235, 0.3)' : 'rgba(135, 206, 235, 0.15)');
            line.setAttribute('stroke-width', lon === 0 ? '1' : '0.5');
            line.setAttribute('stroke-dasharray', lon % 30 === 0 ? 'none' : '2,2');
            gridGroup.appendChild(line);
        }
        
        // Draw parallels (latitude lines)
        for (let lat = -75; lat <= 75; lat += data.graticule.parallels) {
            const y = latToY(lat);
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', 0);
            line.setAttribute('y1', y);
            line.setAttribute('x2', MAP_WIDTH * MAP_SCALE);
            line.setAttribute('y2', y);
            line.setAttribute('stroke', lat === 0 ? 'rgba(135, 206, 235, 0.3)' : 'rgba(135, 206, 235, 0.15)');
            line.setAttribute('stroke-width', lat === 0 ? '1' : '0.5');
            line.setAttribute('stroke-dasharray', lat % 30 === 0 ? 'none' : '2,2');
            gridGroup.appendChild(line);
        }
        
        // Add special lines for tropics and Arctic/Antarctic circles
        const specialLines = [
            { lat: 23.5, name: 'Tropic of Cancer', color: 'rgba(255, 102, 102, 0.2)' },
            { lat: -23.5, name: 'Tropic of Capricorn', color: 'rgba(255, 102, 102, 0.2)' },
            { lat: 66.5, name: 'Arctic Circle', color: 'rgba(204, 68, 68, 0.2)' },
            { lat: -66.5, name: 'Antarctic Circle', color: 'rgba(204, 68, 68, 0.2)' }
        ];
        
        specialLines.forEach(special => {
            const y = latToY(special.lat);
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', 0);
            line.setAttribute('y1', y);
            line.setAttribute('x2', MAP_WIDTH * MAP_SCALE);
            line.setAttribute('y2', y);
            line.setAttribute('stroke', special.color);
            line.setAttribute('stroke-width', '0.8');
            line.setAttribute('stroke-dasharray', '5,3');
            gridGroup.appendChild(line);
        });
    }
    
    function drawContinents(landGroup) {
        // Simplified continent shapes
        const continents = [
            // North America
            { 
                points: [
                    [-170, 70], [-170, 50], [-130, 40], [-120, 35], [-110, 30],
                    [-100, 25], [-95, 20], [-90, 20], [-85, 25], [-80, 30],
                    [-75, 40], [-70, 45], [-65, 45], [-55, 50], [-50, 60],
                    [-60, 70], [-80, 75], [-100, 75], [-140, 72], [-170, 70]
                ]
            },
            // South America
            {
                points: [
                    [-80, 10], [-75, 5], [-70, 0], [-65, -5], [-60, -10],
                    [-55, -20], [-60, -30], [-65, -40], [-70, -50], [-75, -55],
                    [-72, -52], [-68, -45], [-60, -35], [-50, -30], [-40, -20],
                    [-35, -10], [-40, -5], [-45, 0], [-50, 5], [-60, 8],
                    [-70, 10], [-80, 10]
                ]
            },
            // Europe & Asia
            {
                points: [
                    [-10, 70], [0, 68], [20, 70], [40, 68], [60, 70], [90, 70],
                    [120, 70], [150, 65], [170, 60], [180, 65], [180, 40],
                    [160, 30], [140, 35], [120, 25], [110, 20], [100, 10],
                    [95, 5], [80, 10], [70, 15], [60, 20], [50, 25],
                    [40, 30], [30, 30], [20, 35], [10, 40], [0, 42],
                    [-5, 45], [-10, 50], [-8, 60], [-10, 70]
                ]
            },
            // Africa
            {
                points: [
                    [-15, 35], [-10, 30], [-5, 25], [0, 20], [10, 20],
                    [20, 15], [30, 10], [40, 5], [50, 10], [52, 12],
                    [45, 0], [40, -10], [35, -20], [30, -30], [20, -35],
                    [18, -34], [15, -30], [10, -20], [5, -10], [0, 0],
                    [-5, 5], [-10, 10], [-15, 20], [-18, 25], [-15, 35]
                ]
            },
            // Australia
            {
                points: [
                    [110, -20], [115, -22], [125, -18], [135, -15], [145, -18],
                    [150, -25], [152, -30], [150, -35], [145, -38], [140, -38],
                    [135, -35], [130, -32], [125, -32], [120, -33], [115, -30],
                    [110, -25], [110, -20]
                ]
            }
        ];
        
        continents.forEach(continent => {
            const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            let d = 'M';
            continent.points.forEach((point, i) => {
                const x = lonToX(point[0]);
                const y = latToY(point[1]);
                d += ` ${x},${y}`;
            });
            d += ' Z';
            path.setAttribute('d', d);
            landGroup.appendChild(path);
        });
    }
    
    function createMarker() {
        const markerGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        markerGroup.setAttribute('id', 'location-marker');
        markerGroup.style.cursor = 'grab';
        
        // Outer circle with pulsing animation
        const outerCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        outerCircle.setAttribute('r', '8');
        outerCircle.setAttribute('fill', 'none');
        outerCircle.setAttribute('stroke', '#ff0000');
        outerCircle.setAttribute('stroke-width', '2');
        outerCircle.setAttribute('opacity', '0.6');
        
        const pulseAnimate = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
        pulseAnimate.setAttribute('attributeName', 'r');
        pulseAnimate.setAttribute('values', '8;12;8');
        pulseAnimate.setAttribute('dur', '2s');
        pulseAnimate.setAttribute('repeatCount', 'indefinite');
        outerCircle.appendChild(pulseAnimate);
        
        const opacityAnimate = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
        opacityAnimate.setAttribute('attributeName', 'opacity');
        opacityAnimate.setAttribute('values', '0.6;0.2;0.6');
        opacityAnimate.setAttribute('dur', '2s');
        opacityAnimate.setAttribute('repeatCount', 'indefinite');
        outerCircle.appendChild(opacityAnimate);
        
        // Inner circle
        const innerCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        innerCircle.setAttribute('r', '4');
        innerCircle.setAttribute('fill', '#ff0000');
        innerCircle.setAttribute('stroke', '#ffffff');
        innerCircle.setAttribute('stroke-width', '1');
        
        // Crosshair
        const crossV = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        crossV.setAttribute('x1', '0');
        crossV.setAttribute('y1', '-15');
        crossV.setAttribute('x2', '0');
        crossV.setAttribute('y2', '15');
        crossV.setAttribute('stroke', '#ff0000');
        crossV.setAttribute('stroke-width', '1');
        crossV.setAttribute('opacity', '0.5');
        
        const crossH = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        crossH.setAttribute('x1', '-15');
        crossH.setAttribute('y1', '0');
        crossH.setAttribute('x2', '15');
        crossH.setAttribute('y2', '0');
        crossH.setAttribute('stroke', '#ff0000');
        crossH.setAttribute('stroke-width', '1');
        crossH.setAttribute('opacity', '0.5');
        
        markerGroup.appendChild(crossV);
        markerGroup.appendChild(crossH);
        markerGroup.appendChild(outerCircle);
        markerGroup.appendChild(innerCircle);
        
        if (mapSVG) {
            mapSVG.appendChild(markerGroup);
            marker = markerGroup;
            updateMarkerPosition();
        }
    }
    
    function setupEventListeners() {
        if (!mapSVG) return;
        
        // Mouse events
        mapSVG.addEventListener('mousedown', handleMapClick);
        mapSVG.addEventListener('mousemove', handleMapDrag);
        mapSVG.addEventListener('mouseup', handleMapRelease);
        mapSVG.addEventListener('mouseleave', handleMapRelease);
        
        // Touch events for mobile
        mapSVG.addEventListener('touchstart', handleMapTouch);
        mapSVG.addEventListener('touchmove', handleMapTouchMove);
        mapSVG.addEventListener('touchend', handleMapRelease);
    }
    
    function handleMapClick(e) {
        e.preventDefault();
        isDragging = true;
        const point = getPointFromEvent(e);
        if (point) {
            updateLocation(point.lat, point.lon);
            if (marker) marker.style.cursor = 'grabbing';
        }
    }
    
    function handleMapDrag(e) {
        if (!isDragging) return;
        e.preventDefault();
        const point = getPointFromEvent(e);
        if (point) {
            updateLocation(point.lat, point.lon);
        }
    }
    
    function handleMapRelease(e) {
        isDragging = false;
        if (marker) marker.style.cursor = 'grab';
    }
    
    function handleMapTouch(e) {
        e.preventDefault();
        if (e.touches.length === 1) {
            isDragging = true;
            const point = getPointFromEvent(e.touches[0]);
            if (point) {
                updateLocation(point.lat, point.lon);
            }
        }
    }
    
    function handleMapTouchMove(e) {
        if (!isDragging) return;
        e.preventDefault();
        if (e.touches.length === 1) {
            const point = getPointFromEvent(e.touches[0]);
            if (point) {
                updateLocation(point.lat, point.lon);
            }
        }
    }
    
    function getPointFromEvent(e) {
        const rect = mapSVG.getBoundingClientRect();
        const x = (e.clientX - rect.left) * (MAP_WIDTH * MAP_SCALE / rect.width);
        const y = (e.clientY - rect.top) * (MAP_HEIGHT * MAP_SCALE / rect.height);
        
        const lon = xToLon(x);
        const lat = yToLat(y);
        
        return { lat, lon };
    }
    
    function updateLocation(lat, lon) {
        currentLat = Math.max(-90, Math.min(90, lat));
        currentLon = Math.max(-180, Math.min(180, lon));
        
        updateMarkerPosition();
        updateDisplay();
        updateAstrolabe();
    }
    
    function updateMarkerPosition() {
        if (!marker) return;
        
        const x = lonToX(currentLon);
        const y = latToY(currentLat);
        
        marker.setAttribute('transform', `translate(${x}, ${y})`);
    }
    
    function updateDisplay() {
        const latDisplay = document.getElementById('map-lat-display');
        const lonDisplay = document.getElementById('map-lon-display');
        const locationName = document.getElementById('map-location-name');
        
        if (latDisplay) {
            latDisplay.textContent = `Lat: ${currentLat.toFixed(2)}°${currentLat >= 0 ? 'N' : 'S'}`;
        }
        if (lonDisplay) {
            lonDisplay.textContent = `Lon: ${Math.abs(currentLon).toFixed(2)}°${currentLon >= 0 ? 'E' : 'W'}`;
        }
        if (locationName) {
            locationName.textContent = getLocationName(currentLat, currentLon);
        }
    }
    
    function updateAstrolabe() {
        // Update latitude slider
        const latSlider = document.getElementById('latitudeSlider');
        if (latSlider) {
            $(latSlider).val(currentLat).slider('refresh');
            $(latSlider).trigger('change');
        }
        
        // Update longitude display and trigger updates
        const lonElem = document.getElementById('longitude');
        if (lonElem) {
            // Convert longitude to time zone offset approximation
            // This is simplified - actual time zones are more complex
            lonElem.innerHTML = currentLon;
        }
        
        const lonSpan = document.getElementById('lonspan');
        if (lonSpan) {
            lonSpan.textContent = currentLon.toFixed(2);
        }
        
        // Update star chart if available
        if (window.StarChart && window.StarChart.setLocation) {
            window.StarChart.setLocation(currentLat, currentLon);
        }
        
        // Trigger astrolabe update
        if (typeof tympanum === 'function') {
            tympanum();
        }
        if (typeof cosmic_update === 'function') {
            const jd = parseFloat(document.getElementById('julian_day_local')?.textContent);
            if (!isNaN(jd)) {
                cosmic_update(jd);
            }
        }
    }
    
    function syncWithAstrolabe() {
        // Watch for latitude changes
        const latSlider = document.getElementById('latitudeSlider');
        if (latSlider) {
            // Get initial value
            currentLat = parseFloat(latSlider.value) || currentLat;
            updateMarkerPosition();
            updateDisplay();
            
            // Listen for changes
            $(latSlider).on('change', function(e) {
                const newLat = parseFloat(e.target.value);
                if (!isNaN(newLat) && newLat !== currentLat) {
                    currentLat = newLat;
                    updateMarkerPosition();
                    updateDisplay();
                }
            });
        }
        
        // Get initial longitude
        const lonSpan = document.getElementById('lonspan');
        if (lonSpan) {
            const lonValue = parseFloat(lonSpan.textContent);
            if (!isNaN(lonValue)) {
                currentLon = lonValue;
                updateMarkerPosition();
                updateDisplay();
            }
        }
    }
    
    function getLocationName(lat, lon) {
        // Major cities for reference
        const cities = [
            { name: 'New York', lat: 40.71, lon: -74.01 },
            { name: 'London', lat: 51.51, lon: -0.13 },
            { name: 'Paris', lat: 48.86, lon: 2.35 },
            { name: 'Tokyo', lat: 35.68, lon: 139.69 },
            { name: 'Sydney', lat: -33.87, lon: 151.21 },
            { name: 'Cairo', lat: 30.04, lon: 31.24 },
            { name: 'Istanbul', lat: 41.01, lon: 28.98 },
            { name: 'Beijing', lat: 39.90, lon: 116.41 },
            { name: 'Moscow', lat: 55.76, lon: 37.62 },
            { name: 'Rio de Janeiro', lat: -22.91, lon: -43.17 },
            { name: 'Los Angeles', lat: 34.05, lon: -118.24 },
            { name: 'Mexico City', lat: 19.43, lon: -99.13 },
            { name: 'Mumbai', lat: 19.08, lon: 72.88 },
            { name: 'Dubai', lat: 25.20, lon: 55.27 },
            { name: 'Singapore', lat: 1.35, lon: 103.82 }
        ];
        
        // Find nearest city
        let nearestCity = '';
        let minDistance = Infinity;
        
        cities.forEach(city => {
            const distance = Math.sqrt(
                Math.pow(city.lat - lat, 2) + 
                Math.pow(city.lon - lon, 2)
            );
            if (distance < minDistance) {
                minDistance = distance;
                nearestCity = city.name;
            }
        });
        
        // If very close to a city, show its name
        if (minDistance < 2) {
            return `Near ${nearestCity}`;
        }
        
        // Otherwise show ocean/continent
        if (lon > -30 && lon < 60 && lat > -40 && lat < 40) {
            return 'Africa/Middle East';
        } else if (lon > 60 && lon < 150 && lat > -10 && lat < 70) {
            return 'Asia';
        } else if (lon > -170 && lon < -30 && lat > 15 && lat < 70) {
            return 'North America';
        } else if (lon > -85 && lon < -35 && lat > -60 && lat < 15) {
            return 'South America';
        } else if (lon > -20 && lon < 40 && lat > 35 && lat < 70) {
            return 'Europe';
        } else if (lon > 110 && lon < 160 && lat > -45 && lat < -10) {
            return 'Australia';
        } else if (lat < -60) {
            return 'Antarctica';
        } else if (lat > 70) {
            return 'Arctic';
        } else {
            return 'Ocean';
        }
    }
    
    // Coordinate conversion functions
    function lonToX(lon) {
        return ((lon + 180) / 360) * MAP_WIDTH * MAP_SCALE;
    }
    
    function latToY(lat) {
        return ((90 - lat) / 180) * MAP_HEIGHT * MAP_SCALE;
    }
    
    function xToLon(x) {
        return (x / (MAP_WIDTH * MAP_SCALE)) * 360 - 180;
    }
    
    function yToLat(y) {
        return 90 - (y / (MAP_HEIGHT * MAP_SCALE)) * 180;
    }
    
    // Public API
    return {
        init: init,
        setLocation: function(lat, lon) {
            updateLocation(lat, lon);
        },
        getLocation: function() {
            return { lat: currentLat, lon: currentLon };
        }
    };
})();

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', WorldMap.init);
} else {
    WorldMap.init();
}

// Make WorldMap available globally
window.WorldMap = WorldMap;