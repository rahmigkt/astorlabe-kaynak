var xmlns = "http://www.w3.org/2000/svg";
var interval1;

//-----------------------------------
//--- Initialize panel buttons ------
//-----------------------------------
function panel_button_init(){

	var button_names = ["now_button", "stop_button", "ff_button", "rr_button"];
	var button_spacing = 5;
	var outer_button_radius = 6;
	var inner_button_radius = outer_button_radius - 1;

	for (var i=0; i<=3; i++){
		var cx = (2*i - 3) * (button_spacing/2 + outer_button_radius);
		var transform_string = "translate(" + cx + ")";
		var button_name = button_names[i];
		var g = document.getElementById(button_name + "_group");
		g.setAttribute("transform", transform_string);
		
		// Dış çember
		var c1 = document.createElementNS(xmlns, "circle");
		c1.setAttribute("cx", 0);
		c1.setAttribute("cy", 0);
		c1.setAttribute("r", outer_button_radius);
		c1.setAttribute("class", "panel_button_outer");
		g.appendChild(c1);
		
		// İç arka plan çemberi
		var c2 = document.createElementNS(xmlns, "circle");
		c2.setAttribute("cx", 0);
		c2.setAttribute("cy", 0);
		c2.setAttribute("r", inner_button_radius);
		c2.setAttribute("class", "panel_button_inner");
		g.appendChild(c2);
	}

	make_now_button(inner_button_radius);
	make_ff_button(inner_button_radius);
	make_stop_button(inner_button_radius);
	make_rr_button(inner_button_radius);

	$(".panel_button").on("vmouseover", function(){
	  $(this).css("cursor","pointer");
	});
	$(".panel_button_inner").addClass("button_inactive_background");
	$(".panel_button_outer").addClass("button_inactive_rim");

	document.getElementById("now_button_group").addEventListener("click", now_button_pressed);
	document.getElementById("stop_button_group").addEventListener("click", stop_button_pressed);
	document.getElementById("ff_button_group").addEventListener("click", ff_button_pressed);
	document.getElementById("rr_button_group").addEventListener("click", rr_button_pressed);

	// culture toggles
	$("#latin_toggle").on("vmouseover", function(){
		$(this).css("cursor","pointer");
	});
	$("#arabic_toggle").on("vmouseover", function(){
		$(this).css("cursor","pointer");
	});

}


//-----------------------------------
//--- Draw button svgs --------------
//-----------------------------------
function make_now_button(r){
	var g = document.getElementById("now_button_group");
	
	// Record button - kırmızı nokta
	var recordDot = document.createElementNS(xmlns, "circle");
	recordDot.setAttributeNS(null, "cx", 0);
	recordDot.setAttributeNS(null, "cy", 0);
	recordDot.setAttributeNS(null, "r", r * 0.5);
	recordDot.setAttributeNS(null, "fill", "#cc4444");
	recordDot.setAttributeNS(null, "stroke", "none");
	recordDot.setAttributeNS(null, "class", "button_icon");
	g.appendChild(recordDot);
}

function make_stop_button(r){
	var g = document.getElementById("stop_button_group");
	// Stop button - kare
	var stopSquare = document.createElementNS(xmlns, "rect");
	var size = r * 0.9;
	stopSquare.setAttributeNS(null, "x", -size/2);
	stopSquare.setAttributeNS(null, "y", -size/2);
	stopSquare.setAttributeNS(null, "width", size);
	stopSquare.setAttributeNS(null, "height", size);
	stopSquare.setAttributeNS(null, "fill", "#cc4444");
	stopSquare.setAttributeNS(null, "stroke", "none");
	stopSquare.setAttributeNS(null, "class", "button_icon");
	g.appendChild(stopSquare);
}

function make_ff_button(r){
	var g = document.getElementById("ff_button_group");
	// Play button - üçgen
	var playPath = document.createElementNS(xmlns, "path");
	var size = r * 0.7;
	var d = "M " + (-size * 0.8) + "," + (-size) + " L " + (size * 1.2) + ",0 L " + (-size * 0.8) + "," + (size) + " Z";
	playPath.setAttributeNS(null, "d", d);
	playPath.setAttributeNS(null, "fill", "#cc4444");
	playPath.setAttributeNS(null, "stroke", "none");
	playPath.setAttributeNS(null, "class", "button_icon");
	g.appendChild(playPath);
}

function make_rr_button(r){
	var g = document.getElementById("rr_button_group");
	// Rewind button - ters üçgen
	var rewindPath = document.createElementNS(xmlns, "path");
	var size = r * 0.7;
	var d = "M " + (size * 0.8) + "," + (-size) + " L " + (-size * 1.2) + ",0 L " + (size * 0.8) + "," + (size) + " Z";
	rewindPath.setAttributeNS(null, "d", d);
	rewindPath.setAttributeNS(null, "fill", "#cc4444");
	rewindPath.setAttributeNS(null, "stroke", "none");
	rewindPath.setAttributeNS(null, "class", "button_icon");
	g.appendChild(rewindPath);
}

function set_clockhands(){
	// Artık saat ibreleri yok, bu fonksiyon boş kalabilir
}

//-----------------------------------
//--- Event handlers ----------------
//-----------------------------------
function now_button_pressed(){
	$(".panel_button_inner").removeClass("button_active_background").addClass("button_inactive_background");
	$(".panel_button_outer").removeClass("button_active_rim").addClass("button_inactive_rim");
	$(".button_icon").removeClass("active");
	$("#now_button_group > .panel_button_inner").removeClass("button_inactive_background").addClass("button_active_background");
	$("#now_button_group > .panel_button_outer").removeClass("button_inactive_rim").addClass("button_active_rim");
	$("#now_button_group > .button_icon").addClass("active");
	now();
	star_precess();
	clearInterval(interval1);
	interval1 = setInterval(function(){now()},1000);
	document.getElementById("run_status").innerHTML = "run";
	document.getElementById("ff_speed").innerHTML = 0;
	document.getElementById("rr_speed").innerHTML = 0;
	$("#speedpar").html(" ");
}

function stop_button_pressed(){
	$(".panel_button_inner").removeClass("button_active_background").addClass("button_inactive_background");
	$(".panel_button_outer").removeClass("button_active_rim").addClass("button_inactive_rim");
	$(".button_icon").removeClass("active");
	$("#stop_button_group > .panel_button_inner").removeClass("button_inactive_background").addClass("button_active_background");
	$("#stop_button_group > .panel_button_outer").removeClass("button_inactive_rim").addClass("button_active_rim");
	$("#stop_button_group > .button_icon").addClass("active");
	clearInterval(interval1);
	document.getElementById("run_status").innerHTML = "stop";
	document.getElementById("ff_speed").innerHTML = 0;
	document.getElementById("rr_speed").innerHTML = 0;
	$("#speedpar").html(" ");
}

function ff_button_pressed(){
	$(".panel_button_inner").removeClass("button_active_background").addClass("button_inactive_background");
	$(".panel_button_outer").removeClass("button_active_rim").addClass("button_inactive_rim");
	$(".button_icon").removeClass("active");
	$("#ff_button_group > .panel_button_inner").removeClass("button_inactive_background").addClass("button_active_background");
	$("#ff_button_group > .panel_button_outer").removeClass("button_inactive_rim").addClass("button_active_rim");
	$("#ff_button_group > .button_icon").addClass("active");
	clearInterval(interval1);
	document.getElementById("run_status").innerHTML = "ff";
	document.getElementById("rr_speed").innerHTML = 0;
	var speed = Number(document.getElementById("ff_speed").innerHTML);
	speed += 1;
	var increment = 0;
	if(speed==1){
		increment = 1/1440;
    	$("#speedpar").html("Speed 1: increment = +1 minute");
    }
	else if(speed==2){
		increment = 1/144;
    	$("#speedpar").html("Speed 2: increment = +10 minutes");
    }
	else if(speed > 2){
		speed = 3;
		increment = 1;
    	$("#speedpar").html("Speed 3: increment = +1 day");
    }
    document.getElementById("ff_speed").innerHTML = speed;
	interval1 = setInterval(function(){wheelAdvance(increment)}, 50);
}

function rr_button_pressed(){
	$(".panel_button_inner").removeClass("button_active_background").addClass("button_inactive_background");
	$(".panel_button_outer").removeClass("button_active_rim").addClass("button_inactive_rim");
	$(".button_icon").removeClass("active");
	$("#rr_button_group > .panel_button_inner").removeClass("button_inactive_background").addClass("button_active_background");
	$("#rr_button_group > .panel_button_outer").removeClass("button_inactive_rim").addClass("button_active_rim");
	$("#rr_button_group > .button_icon").addClass("active");
	clearInterval(interval1);
	document.getElementById("run_status").innerHTML = "rr";
	document.getElementById("ff_speed").innerHTML = 0;
	var speed = Number(document.getElementById("rr_speed").innerHTML);
	speed += 1;
	var increment = 0;
	if(speed==1){
		increment = -1/1440;
    	$("#speedpar").html("Speed 1: increment = -1 minute");
    }
	else if(speed==2){
		increment = -1/144;
    	$("#speedpar").html("Speed 2: increment = -10 minutes");
    }
	else if(speed > 2){
		speed = 3;
		increment = -1;
    	$("#speedpar").html("Speed 3: increment = -1 day");
    }
    document.getElementById("rr_speed").innerHTML = speed;
	interval1 = setInterval(function(){wheelAdvance(increment)}, 50);
}


//-----------------------------------
//--- Culture toggle ----------------
//-----------------------------------
function latin_toggle_pressed(){
	$("#limbtext").removeClass("hidden").addClass("visible");
	$("#limbtext_arabic").removeClass("visible").addClass("hidden");
	$("#lowercusps_textgroup").removeClass("hidden").addClass("visible");
	$("#uppercusps_textgroup").removeClass("hidden").addClass("visible");
	$("#c1r_latin").removeClass("hidden").addClass("visible");
	$("#vdegmarkings_arabic").removeClass("visible").addClass("hidden");
	$("#latin_toggle").removeClass("culturetoggle");
	$("#arabic_toggle").addClass("culturetoggle");
	$(".rete_group").removeClass("active_rete").addClass("inactive_rete");
	$("#reteGroup_default").addClass("active_rete");
	$("#index_toggle_div").removeClass("ui-state-disabled");
	$("#almuri_toggle_div").css("display","none");
	$("#ruleGroup_inner").css("visibility","inherit");
}

function arabic_toggle_pressed(){
	$("#limbtext").removeClass("visible").addClass("hidden");
	$("#limbtext_arabic").removeClass("hidden").addClass("visible");
	$("#lowercusps_textgroup").removeClass("visible").addClass("hidden");
	$("#uppercusps_textgroup").removeClass("visible").addClass("hidden");
	$("#c1r_latin").removeClass("visible").addClass("hidden");
	$("#vdegmarkings_arabic").removeClass("hidden").addClass("visible");
	$("#arabic_toggle").removeClass("culturetoggle");
	$("#latin_toggle").addClass("culturetoggle");
	$(".rete_group").removeClass("active_rete").addClass("inactive_rete");
	$("#reteGroup_51459").addClass("active_rete");
	$("#index_toggle_div").addClass("ui-state-disabled");
	$("#almuri_toggle_div").css("display","inherit");
	$("#ruleGroup_inner").css("visibility","hidden");

}


//----------------------------------------
//---------------------------------------- 
//--- Initialize settings dropdown menu --
//----------------------------------------
//----------------------------------------
function settings_menu_init(){

	// Populate select dropdowns
	initialize_bcce_radio_buttons();
	populate_month_select();
	populate_hour_select();
	populate_minute_select();
	initialize_dst_radio_buttons();

	// Extend expand/collapse functionality to datetime_div
	$("#datetime_div").on("vmouseover", function(){
		$(this).css("cursor","pointer");
	});
	$("#datetime_div").on("click", function(){
		if ($("#settings_button").hasClass("ui-collapsible-collapsed")) {
			$("#settings_button").collapsible("expand");
			$("html, body").animate({scrollTop: $("#settings_button").offset().top}, 600);
		}
		else{
		  $("#settings_button").collapsible("collapse");
		}
	});

	// When settings is expanded, set datetime values to current local values
	$("#settings_button").on("collapsibleexpand", function() {
		// Apply translations when modal opens
		const currentLang = sessionStorage.getItem('astrolabeLanguage') || 'latin';
		if (typeof applyTranslations === 'function') {
			applyTranslations(currentLang);
		}
		
		var year = Number(document.getElementById("local_year").innerHTML);
		$(".radio1_on").addClass("hidden");
		if (year > 1) {
			$("#radio1_CE > .radio1_on").removeClass("hidden").addClass("visible");
		}
		else {
			$("#radio1_BC > .radio1_on").removeClass("hidden").addClass("visible");
			year = 1 - year;
		}
		var dst = Number(document.getElementById("daylightsaving").innerHTML);
		$(".radio2_on").addClass("hidden");
		if (dst == 1) {
			$("#radio2_ON > .radio2_on").removeClass("hidden").addClass("visible");
			$("#dst_radiospan").text(1);
		}
		else {
			$("#radio2_OFF > .radio2_on").removeClass("hidden").addClass("visible");
			$("#dst_radiospan").text(0);
		}
		document.getElementById("year_numberinput").value = year;
		var month = String(document.getElementById("local_month").innerHTML);
		$("#month_select").val(month).selectmenu("refresh");
		dayselect_configure();
		var day = String(document.getElementById("local_day").innerHTML);
		$("#day_select").val(day).selectmenu("refresh");
		var hour = String(document.getElementById("local_hour").innerHTML);
		$("#hour_select").val(hour).selectmenu("refresh");
		var minutes = String(document.getElementById("local_minutes").innerHTML);
		$("#minute_select").val(minutes).selectmenu("refresh");
		var tzo = -Number(document.getElementById("utc_offset").innerHTML)/60;
		$("#timeZoneSlider").val(tzo).slider("refresh");
		var lon = document.getElementById("longitude").innerHTML;
		var lonstring = Math.abs(lon) + "°" + ["W","","E"][(1 + Math.sign(lon))];
		$("#lonspan").text(lonstring);
		$("html, body").animate({scrollTop: $("#settings_button").offset().top}, 600);
	});

	$("#settings_button").on("collapsiblecollapse", function() {
		$("html, body").animate({scrollTop: $("#svg_astrolabe").offset().top}, 500);
	});

	// Reconfigure the day options whenever the selected year or month changes
	$("#year_numberinput").change(function(){
		year_rangecheck();
  		dayselect_configure();
	});

	$("#month_select").change(function(){
  		dayselect_configure();
	});
	// Update lonspan when slider is moved
  	$("#timeZoneSlider").change(function(){
  		longitude_adjust();
	});

	$("#settings_cancel").on("click", function(){
		$("#settings_button").collapsible("collapse");
		$('html, body').animate({scrollTop: $("#svg_astrolabe").offset().top}, 500);
	});

	$("#settings_enter").on("click", function(){
  		stop_button_pressed();
  		var tzo = Number($("#timeZoneSlider").val());
		var dst = Number($("#dst_radiospan").text());
		var lon = 15 * (tzo - dst);
		var utc_offset = -60 * tzo;
		document.getElementById("longitude").innerHTML = lon;
		document.getElementById("daylightsaving").innerHTML = $("#dst_radiospan").text();
		document.getElementById("utc_offset").innerHTML = utc_offset;
		var ymdhms_local = new Array(0,0,0,0,0,0);
		var y = Number($("#year_numberinput").val());
		if ($("#radio1_BC > .radio1_on").hasClass("visible")){
			y = 1 - y;
		}
		ymdhms_local[0] = y;
		ymdhms_local[1] = Number($("#month_select").val());
		ymdhms_local[2] = Number($("#day_select").val());
		ymdhms_local[3] = Number($("#hour_select").val());
		ymdhms_local[4] = Number($("#minute_select").val());
		ymdhms_local[5] = 0;
		var jd_local = jd_from_array(ymdhms_local);
		fullDateSet(jd_local);
		cosmic_update(jd_local);
		star_precess();
		$("#settings_button").collapsible("collapse");
		$('html, body').animate({scrollTop: $("#svg_astrolabe").offset().top}, 600);
	});
}


function initialize_bcce_radio_buttons(){
	var svg_radio1 = document.getElementById("svg_radio1");
	var g0 = document.createElementNS(xmlns, "g");
	svg_radio1.appendChild(g0);
	g0.setAttribute("id", "bcce_radio_group");
	g0.setAttribute("transform", "matrix(1,0,0,-1,18,5)");
	g0.setAttribute("font-family", "Arial, Helvetica, sans-serif");
	g0.setAttribute("font-size", 3.5);
	g0.setAttribute("font-weight", "bold");
	g0.setAttribute("fill", "#222");
	g0.setAttribute("stroke", "none");
	g0.setAttribute("text-anchor","left");
	// Get button labels based on current language
	function getBCCELabels() {
		const currentLang = sessionStorage.getItem('astrolabeLanguage') || 'latin';
		const labels = {
			latin: ["BC", "CE"],
			turkish: ["MÖ", "MS"],
			arabic: ["ق.م", "م"]
		};
		return labels[currentLang] || labels.latin;
	}
	var button_labels = getBCCELabels();
	for (var i=0; i<button_labels.length; i++){
		var g1 = document.createElementNS(xmlns, "g");
		g0.appendChild(g1);
		g1.setAttribute("class","radio1");
		g1.setAttribute("id", "radio1_" + button_labels[i]);
		var x = -15 + 18 * i;
		var rect = document.createElementNS(xmlns, "rect");
		rect.setAttribute("x", x);
		rect.setAttribute("y", -5);
		rect.setAttribute("width", 14);
		rect.setAttribute("height", 10);
		rect.setAttribute("fill", "white");
		g1.appendChild(rect);
		var tx = document.createElementNS(xmlns, "text");
		tx.setAttributeNS(null,"transform", "matrix(1,0,0,-1,0,0)");
		tx.setAttributeNS(null,"x", x + 8);
		tx.setAttributeNS(null,"y", 2.2);
		var tn = document.createTextNode(button_labels[i]);
		tx.appendChild(tn);
		g1.appendChild(tx);
		var c = document.createElementNS(xmlns, "circle");
		c.setAttribute("cx", x + 4);
		c.setAttribute("cy", -1);
		c.setAttribute("r", 3);
		c.setAttribute("fill", "white");
		c.setAttribute("stroke", "#222");
		c.setAttribute("stroke-width", 0.3);
		g1.appendChild(c);
		var c = document.createElementNS(xmlns, "circle");
		c.setAttribute("cx", x + 4);
		c.setAttribute("cy", -1);
		c.setAttribute("r", 2);
		c.setAttribute("fill", "#333");
		c.setAttribute("stroke", "#333");
		c.setAttribute("stroke-width", 0.3);
		c.setAttribute("class", "radio1_on");
		g1.appendChild(c);
	}
	$(".radio1_on").addClass("hidden");
	$(".radio1").on("vmouseover", function(){
	  $(this).css("cursor","pointer");
	});
	$("#radio1_BC").on("click", function(){
		$(".radio1_on").removeClass("visible").addClass("hidden");
		$("#radio1_BC > .radio1_on").removeClass("hidden").addClass("visible");
		year_rangecheck();
	});
	$("#radio1_CE").on("click", function(){
		$(".radio1_on").removeClass("visible").addClass("hidden");
		$("#radio1_CE > .radio1_on").removeClass("hidden").addClass("visible");
		year_rangecheck();
	});
}

function initialize_dst_radio_buttons(){
	var svg_radio2 = document.getElementById("svg_radio2");
	var g0 = document.createElementNS(xmlns, "g");
	svg_radio2.appendChild(g0);
	g0.setAttribute("transform", "matrix(1,0,0,-1,18,5)");
	g0.setAttribute("font-family", "Arial, Helvetica, sans-serif");
	g0.setAttribute("font-size", 3.5);
	g0.setAttribute("font-weight", "bold");
	g0.setAttribute("fill", "#222");
	g0.setAttribute("stroke", "none");
	g0.setAttribute("text-anchor","left");
	// Get button labels based on current language
	function getOnOffLabels() {
		const currentLang = sessionStorage.getItem('astrolabeLanguage') || 'latin';
		const labels = {
			latin: ["ON", "OFF"],
			turkish: ["AÇIK", "KAPALI"],
			arabic: ["تشغيل", "إيقاف"]
		};
		return labels[currentLang] || labels.latin;
	}
	var button_labels = getOnOffLabels();
	for (var i=0; i<button_labels.length; i++){
		var g1 = document.createElementNS(xmlns, "g");
		g0.appendChild(g1);
		g1.setAttribute("class","radio2");
		g1.setAttribute("id", "radio2_" + button_labels[i]);
		var x = -15 + 18 * i;
		var rect = document.createElementNS(xmlns, "rect");
		rect.setAttribute("x", x);
		rect.setAttribute("y", -5);
		rect.setAttribute("width", 14);
		rect.setAttribute("height", 10);
		rect.setAttribute("fill", "white");
		g1.appendChild(rect);
		var tx = document.createElementNS(xmlns, "text");
		tx.setAttributeNS(null,"transform", "matrix(1,0,0,-1,0,0)");
		tx.setAttributeNS(null,"x", x + 8);
		tx.setAttributeNS(null,"y", 2.2);
		var tn = document.createTextNode(button_labels[i]);
		tx.appendChild(tn);
		g1.appendChild(tx);
		var c = document.createElementNS(xmlns, "circle");
		c.setAttribute("cx", x + 4);
		c.setAttribute("cy", -1);
		c.setAttribute("r", 3);
		c.setAttribute("fill", "white");
		c.setAttribute("stroke", "#222");
		c.setAttribute("stroke-width", 0.3);
		g1.appendChild(c);
		var c = document.createElementNS(xmlns, "circle");
		c.setAttribute("cx", x + 4);
		c.setAttribute("cy", -1);
		c.setAttribute("r", 2);
		c.setAttribute("fill", "#333");
		c.setAttribute("stroke", "#333");
		c.setAttribute("stroke-width", 0.3);
		c.setAttribute("class", "radio2_on");
		g1.appendChild(c);
	}
	$(".radio2_on").addClass("hidden");
	$(".radio2").on("vmouseover", function(){
	  $(this).css("cursor","pointer");
	});
	$("#radio2_ON").on("click", function(){
		$(".radio2_on").addClass("hidden");
		$("#radio2_ON > .radio2_on").removeClass("hidden").addClass("visible");
		$("#dst_radiospan").text(1);
		longitude_adjust();
	});
	$("#radio2_OFF").on("click", function(){
		$(".radio2_on").addClass("hidden");
		$("#radio2_OFF > .radio2_on").removeClass("hidden").addClass("visible");
		$("#dst_radiospan").text(0);
		longitude_adjust();
	});
}


function populate_month_select(){
	// Get month names based on current language
	function getMonthNames() {
		const currentLang = sessionStorage.getItem('astrolabeLanguage') || 'latin';
		const months = {
			latin: ["January","February","March","April","May","June","July","August","September","October","November","December"],
			turkish: ["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"],
			arabic: ["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"]
		};
		return months[currentLang] || months.latin;
	}
	var months = getMonthNames();
	$("#month_select").empty();
	for (i=0; i<months.length; i++){
		var optiontext = months[i];
		var optionvalue = String(i + 1);
		$("#month_select").append(new Option(optiontext, optionvalue));
	}
}

function populate_hour_select(){
	// Get hour format based on current language
	function getHourLabels() {
		const currentLang = sessionStorage.getItem('astrolabeLanguage') || 'latin';
		const ampm = {
			latin: ['AM', 'PM'],
			turkish: ['ÖÖ', 'ÖS'],
			arabic: ['ص', 'م']
		};
		const labels = ampm[currentLang] || ampm.latin;
		return [
			"12 " + labels[0],"1 " + labels[0],"2 " + labels[0],"3 " + labels[0],"4 " + labels[0],"5 " + labels[0],
			"6 " + labels[0],"7 " + labels[0],"8 " + labels[0],"9 " + labels[0],"10 " + labels[0],"11 " + labels[0],
			"12 " + labels[1],"1 " + labels[1],"2 " + labels[1],"3 " + labels[1],"4 " + labels[1],"5 " + labels[1],
			"6 " + labels[1],"7 " + labels[1],"8 " + labels[1],"9 " + labels[1],"10 " + labels[1],"11 " + labels[1]
		];
	}
	var hours = getHourLabels();
	$("#hour_select").empty();
	for (i=0; i<hours.length; i++){
		var optiontext = hours[i];
		var optionvalue = String(i);
		$("#hour_select").append(new Option(optiontext, optionvalue));
	}
}

function populate_minute_select(){
	$("#minute_select").empty();
	for (i=0; i<60; i++){
		var optiontext = ("0"+String(i)).slice(-2);
		var optionvalue = String(i);
		$("#minute_select").append(new Option(optiontext, optionvalue));
	}
}

function year_rangecheck(){
	var yearval = Number($("#year_numberinput").val());
	if ($("#radio1_BC > .radio1_on").hasClass("visible")){
		yearval = 1 - yearval;
	}
	yearval = Math.min(3000, yearval);
	yearval = Math.max(-1999, yearval);
	if (yearval < 1) {
		$(".radio1_on").addClass("hidden");
		$("#radio1_BC > .radio1_on").removeClass("hidden").addClass("visible");
		yearval = 1 - yearval;
	}
	document.getElementById("year_numberinput").value = yearval;
}

function dayselect_configure(){
	var y = Number($("#year_numberinput").val());
	var m = Number($("#month_select").val());
	var d = Number($("#day_select").val());
	if ($("#radio1_BC > .radio1_on").hasClass("visible")){
		y = 1 - y;
	}
	var days28 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28]; 
	var days29 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29];
	var days30 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30];
	var days31 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
	var oct1582 = [1,2,3,4,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
	var days = days31;
	var thirtydaymonths = [4,6,9,11];
	if (thirtydaymonths.includes(m)) {
		days = days30;
	}
	if (m==2){
		if (leapYearQuery(y) == 1) {days = days29;}
		else {days = days28;}
	}
	if (y == 1582 && m == 10) {days = oct1582;}
	// Remove all options from day_select and append new ones
	$("#day_select").empty();
	for (i=0; i<days.length; i++){
		var optionvalue = String(days[i]);
		var optiontext = days[i];
		$("#day_select").append(new Option(optionvalue, optiontext));
	}
	// Keep old day value unless it is not present in the new month
	if (days.includes(d) == false){
		d = days[days.length - 1];
	}
	$("#day_select").val(d).selectmenu("refresh");
	// Ensure daylight savings is off for December, January, February
	if ([12,1,2].includes(m)){
		$(".radio2_on").addClass("hidden");
		$("#radio2_OFF > .radio2_on").removeClass("hidden").addClass("visible");
		$("#dst_radiospan").text(0);
	}
}

function longitude_adjust(){
	var dst = Number($("#dst_radiospan").text());
	var lon = 15 * (Number($("#timeZoneSlider").val()) - dst);
	var lonstring = Math.abs(lon) + "°" + ["W","","E"][(1 + Math.sign(lon))];
	$("#lonspan").text(lonstring);
}






