<?php
/**
 * Simple WebSocket Server for Real-time Astrolabe Sync
 * Run: php websocket_server.php
 */

class AstrolabeWebSocketServer {
    private $host = 'localhost';
    private $port = 8080;
    private $socket;
    private $clients = [];
    private $sessions = [];
    
    public function __construct($host = 'localhost', $port = 8080) {
        $this->host = $host;
        $this->port = $port;
    }
    
    public function start() {
        echo "🚀 Starting Astrolabe WebSocket Server on {$this->host}:{$this->port}\n";
        
        $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        socket_set_option($this->socket, SOL_SOCKET, SO_REUSEADDR, 1);
        socket_bind($this->socket, $this->host, $this->port);
        socket_listen($this->socket);
        
        echo "✅ Server listening on ws://{$this->host}:{$this->port}\n";
        echo "📡 Waiting for client connections...\n\n";
        
        while (true) {
            $changed = [$this->socket];
            $changed = array_merge($changed, $this->clients);
            $write = null;
            $except = null;
            
            socket_select($changed, $write, $except, 0, 10);
            
            if (in_array($this->socket, $changed)) {
                $new_client = socket_accept($this->socket);
                $this->clients[] = $new_client;
                
                $header = socket_read($new_client, 1024);
                $this->performHandshake($header, $new_client, $this->host, $this->port);
                
                echo "🔗 New client connected! Total clients: " . count($this->clients) . "\n";
                
                // Send welcome message
                $this->send($new_client, json_encode([
                    'type' => 'welcome',
                    'message' => 'Connected to Astrolabe WebSocket Server',
                    'timestamp' => time()
                ]));
                
                $found_socket = array_search($this->socket, $changed);
                unset($changed[$found_socket]);
            }
            
            foreach ($changed as $changed_socket) {
                while (socket_recv($changed_socket, $buf, 1024, 0) >= 1) {
                    $received_text = $this->unmask($buf);
                    $received_data = json_decode($received_text, true);
                    
                    if ($received_data) {
                        $this->handleMessage($changed_socket, $received_data);
                    }
                    break 2;
                }
                
                $buf = @socket_read($changed_socket, 1024, PHP_BINARY_READ);
                if ($buf === false || $buf === '') {
                    $found_socket = array_search($changed_socket, $this->clients);
                    if ($found_socket !== false) {
                        socket_getpeername($changed_socket, $ip);
                        unset($this->clients[$found_socket]);
                        echo "❌ Client {$ip} disconnected. Total clients: " . count($this->clients) . "\n";
                    }
                }
            }
        }
        
        socket_close($this->socket);
    }
    
    private function handleMessage($client, $data) {
        echo "📨 Received: " . json_encode($data) . "\n";
        
        switch ($data['type']) {
            case 'ping':
                $this->send($client, json_encode([
                    'type' => 'pong',
                    'timestamp' => time()
                ]));
                break;
                
            case 'join_session':
                $sessionKey = $data['sessionKey'] ?? 'default';
                $clientType = $data['clientType'] ?? 'unknown'; // 'control' or 'display'
                
                if (!isset($this->sessions[$sessionKey])) {
                    $this->sessions[$sessionKey] = [];
                }
                
                $this->sessions[$sessionKey][] = [
                    'socket' => $client,
                    'type' => $clientType,
                    'joined_at' => time()
                ];
                
                echo "👥 Client joined session '{$sessionKey}' as '{$clientType}'\n";
                
                // Send confirmation
                $this->send($client, json_encode([
                    'type' => 'session_joined',
                    'sessionKey' => $sessionKey,
                    'clientType' => $clientType
                ]));
                break;
                
            case 'astrolabe_sync':
                $sessionKey = $data['sessionKey'] ?? 'default';
                
                // Broadcast to all other clients in the same session
                if (isset($this->sessions[$sessionKey])) {
                    foreach ($this->sessions[$sessionKey] as $session_client) {
                        if ($session_client['socket'] !== $client) {
                            $this->send($session_client['socket'], json_encode([
                                'type' => 'astrolabe_update',
                                'data' => $data['data'],
                                'from' => $data['from'] ?? 'unknown',
                                'timestamp' => time()
                            ]));
                        }
                    }
                    echo "🔄 Synced astrolabe data for session '{$sessionKey}'\n";
                }
                break;
                
            case 'heartbeat':
                // Keep connection alive
                break;
                
            default:
                echo "❓ Unknown message type: {$data['type']}\n";
        }
    }
    
    private function send($client, $msg) {
        $msg = $this->mask($msg);
        socket_write($client, $msg, strlen($msg));
    }
    
    private function performHandshake($headers, $socket, $host, $port) {
        $lines = preg_split("/\r\n/", $headers);
        $headerArray = [];
        foreach ($lines as $line) {
            $line = chop($line);
            if (preg_match('/\A(\S+): (.*)\z/', $line, $matches)) {
                $headerArray[$matches[1]] = $matches[2];
            }
        }
        
        $secKey = isset($headerArray['Sec-WebSocket-Key']) ? $headerArray['Sec-WebSocket-Key'] : '';
        $secAccept = base64_encode(pack('H*', sha1($secKey . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')));
        
        $response = "HTTP/1.1 101 Switching Protocols\r\n" .
                   "Upgrade: websocket\r\n" .
                   "Connection: Upgrade\r\n" .
                   "Sec-WebSocket-Accept: $secAccept\r\n\r\n";
        
        socket_write($socket, $response, strlen($response));
    }
    
    private function mask($text) {
        $b1 = 0x81;
        $length = strlen($text);
        
        if ($length <= 125) {
            $header = pack('CC', $b1, $length);
        } elseif ($length > 125 && $length < 65536) {
            $header = pack('CCn', $b1, 126, $length);
        } elseif ($length >= 65536) {
            $header = pack('CCNN', $b1, 127, $length);
        }
        
        return $header . $text;
    }
    
    private function unmask($text) {
        $length = ord($text[1]) & 127;
        
        if ($length == 126) {
            $masks = substr($text, 4, 4);
            $data = substr($text, 8);
        } elseif ($length == 127) {
            $masks = substr($text, 10, 4);
            $data = substr($text, 14);
        } else {
            $masks = substr($text, 2, 4);
            $data = substr($text, 6);
        }
        
        $text = "";
        for ($i = 0; $i < strlen($data); ++$i) {
            $text .= $data[$i] ^ $masks[$i % 4];
        }
        
        return $text;
    }
}

// Start the server
// Use 0.0.0.0 to accept connections from any IP on local network
$server = new AstrolabeWebSocketServer('0.0.0.0', 8080);
try {
    $server->start();
} catch (Exception $e) {
    echo "❌ Server error: " . $e->getMessage() . "\n";
}
?>