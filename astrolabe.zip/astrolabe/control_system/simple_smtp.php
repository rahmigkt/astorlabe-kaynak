<?php
/**
 * Simple SMTP Email Sender
 * Lightweight SMTP implementation for sending emails
 */
class SimpleSmtp {
    private $smtp_host;
    private $smtp_port;
    private $smtp_username;
    private $smtp_password;
    private $smtp_encryption;
    private $connection;
    private $debug = false;
    
    public function __construct($host, $port, $username, $password, $encryption = 'tls') {
        $this->smtp_host = $host;
        $this->smtp_port = $port;
        $this->smtp_username = $username;
        $this->smtp_password = $password;
        $this->smtp_encryption = $encryption;
    }
    
    public function setDebug($debug = true) {
        $this->debug = $debug;
    }
    
    private function log($message) {
        if ($this->debug) {
            error_log('📧 SMTP: ' . $message);
        }
    }
    
    private function sendCommand($command, $expected_code = 250) {
        $this->log("Sending: $command");
        fwrite($this->connection, $command . "\r\n");
        
        $response = fgets($this->connection);
        $this->log("Response: " . trim($response));
        
        $code = substr($response, 0, 3);
        if ($code != $expected_code) {
            throw new Exception("SMTP Error: Expected $expected_code, got $code - $response");
        }
        
        return $response;
    }
    
    public function connect() {
        $this->log("Connecting to {$this->smtp_host}:{$this->smtp_port}");
        
        // Create socket connection
        $context = stream_context_create();
        
        if ($this->smtp_encryption == 'ssl') {
            $this->connection = stream_socket_client("ssl://{$this->smtp_host}:{$this->smtp_port}", $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $context);
        } else {
            $this->connection = stream_socket_client("{$this->smtp_host}:{$this->smtp_port}", $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $context);
        }
        
        if (!$this->connection) {
            throw new Exception("Failed to connect to SMTP server: $errstr ($errno)");
        }
        
        // Read initial greeting
        $response = fgets($this->connection);
        $this->log("Server greeting: " . trim($response));
        
        // Send EHLO
        $this->sendCommand("EHLO " . gethostname(), 250);
        
        // Start TLS if needed
        if ($this->smtp_encryption == 'tls') {
            $this->sendCommand("STARTTLS", 220);
            
            if (!stream_socket_enable_crypto($this->connection, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                throw new Exception("Failed to enable TLS encryption");
            }
            
            // Send EHLO again after TLS
            $this->sendCommand("EHLO " . gethostname(), 250);
        }
        
        // Authenticate
        $this->sendCommand("AUTH LOGIN", 334);
        $this->sendCommand(base64_encode($this->smtp_username), 334);
        $this->sendCommand(base64_encode($this->smtp_password), 235);
        
        return true;
    }
    
    public function sendEmail($from, $to, $subject, $body, $headers = []) {
        try {
            // Set sender
            $this->sendCommand("MAIL FROM: <$from>");
            
            // Set recipient
            $this->sendCommand("RCPT TO: <$to>");
            
            // Start data
            $this->sendCommand("DATA", 354);
            
            // Send headers
            fwrite($this->connection, "From: $from\r\n");
            fwrite($this->connection, "To: $to\r\n");
            fwrite($this->connection, "Subject: $subject\r\n");
            fwrite($this->connection, "Content-Type: text/html; charset=UTF-8\r\n");
            
            // Send custom headers
            foreach ($headers as $header) {
                fwrite($this->connection, $header . "\r\n");
            }
            
            fwrite($this->connection, "\r\n");
            
            // Send body
            fwrite($this->connection, $body . "\r\n");
            
            // End data
            $this->sendCommand(".", 250);
            
            return true;
            
        } catch (Exception $e) {
            $this->log("Error sending email: " . $e->getMessage());
            return false;
        }
    }
    
    public function disconnect() {
        if ($this->connection) {
            try {
                // Some servers respond with 250 instead of 221 for QUIT
                fwrite($this->connection, "QUIT\r\n");
                $response = fgets($this->connection);
                $this->log("QUIT Response: " . trim($response));
                // Don't throw error on disconnect, just log it
            } catch (Exception $e) {
                $this->log("Error during disconnect: " . $e->getMessage());
            }
            fclose($this->connection);
            $this->connection = null;
        }
    }
    
    public function __destruct() {
        $this->disconnect();
    }
}
?>