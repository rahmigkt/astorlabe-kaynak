<?php
// Test script for AI horoscope generation
header('Content-Type: text/html; charset=utf-8');

// Test data similar to what control.php sends
$testData = [
    'date' => 'Mon Sep 08 2025',
    'latitude' => 41,
    'year' => 2025,
    'month' => 9,
    'day' => 8,
    'hour' => 6,
    'minute' => 29
];

echo "<!DOCTYPE html>
<html lang='tr'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>AI Horoscope Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #1a1a1a; color: #fff; }
        .test-container { max-width: 800px; margin: 0 auto; }
        .log { background: #000; padding: 10px; margin: 10px 0; border-radius: 5px; font-family: monospace; white-space: pre-wrap; }
        .error { color: #ff6b6b; }
        .success { color: #51cf66; }
        .info { color: #74c0fc; }
        button { background: #339af0; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; }
        button:hover { background: #228be6; }
        #output { background: #2d2d2d; padding: 15px; border-radius: 5px; min-height: 100px; }
    </style>
</head>
<body>
    <div class='test-container'>
        <h1>🌟 AI Burç Yorumu Testi</h1>
        <p>Test verileri:</p>
        <div class='log info'>" . json_encode($testData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</div>
        
        <button onclick='testHoroscope()'>Test Başlat</button>
        <button onclick='clearOutput()'>Temizle</button>
        
        <h3>Sonuç:</h3>
        <div id='output'>Test başlatmak için butona tıklayın...</div>
        
        <h3>Log:</h3>
        <div id='log' class='log'></div>
    </div>

    <script>
        function log(message, type = 'info') {
            const logEl = document.getElementById('log');
            const timestamp = new Date().toLocaleTimeString('tr-TR');
            logEl.innerHTML += `<span class='${type}'>[${timestamp}] ${message}</span>\\n`;
            logEl.scrollTop = logEl.scrollHeight;
        }
        
        function clearOutput() {
            document.getElementById('output').innerHTML = '';
            document.getElementById('log').innerHTML = '';
        }
        
        async function testHoroscope() {
            const output = document.getElementById('output');
            const testData = " . json_encode($testData) . ";
            
            log('AI yorumu oluşturuluyor...', 'info');
            output.innerHTML = '<div style=\"text-align: center; padding: 20px;\">🌌 Yıldızlar okunuyor...</div>';
            
            try {
                const response = await fetch('ai_horoscope.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(testData)
                });
                
                log(`HTTP Yanıt: ${response.status} ${response.statusText}`, response.ok ? 'success' : 'error');
                
                if (!response.ok) {
                    throw new Error(`HTTP hatası: ${response.status} ${response.statusText}`);
                }
                
                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let fullText = '';
                let chunkCount = 0;
                
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    
                    chunkCount++;
                    const chunk = decoder.decode(value);
                    log(`Chunk ${chunkCount} alındı: ${chunk.length} karakter`, 'info');
                    
                    // Parse SSE format
                    const lines = chunk.split('\\n');
                    for (const line of lines) {
                        if (line.startsWith('data: ')) {
                            const data = line.substring(6);
                            
                            if (data === '[DONE]') {
                                log('Stream tamamlandı!', 'success');
                                output.innerHTML = fullText || 'Yorum alındı ancak boş görünüyor.';
                                return;
                            }
                            
                            try {
                                const parsed = JSON.parse(data);
                                if (parsed.content) {
                                    fullText += parsed.content;
                                    output.innerHTML = fullText.replace(/\\n/g, '<br>');
                                } else if (parsed.error) {
                                    throw new Error(parsed.error);
                                }
                            } catch (e) {
                                log(`JSON parse hatası: ${e.message}`, 'error');
                            }
                        }
                    }
                }
                
                log('Stream tamamlandı.', 'success');
                output.innerHTML = fullText || 'Yorum alındı ancak boş görünüyor.';
                
            } catch (error) {
                log(`Hata: ${error.message}`, 'error');
                output.innerHTML = `<div style='color: #ff6b6b;'>❌ Hata: ${error.message}</div>`;
            }
        }
    </script>
</body>
</html>";
?>
