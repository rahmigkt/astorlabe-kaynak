<?php
// Advanced PDF and Email Setup
// Run this file to install enhanced PDF and email libraries

echo "<h2>🚀 Astrolabe AI - Gelişmiş Özellikler Kurulumu</h2>";

// Check if composer is available
$composerCommand = 'composer --version 2>/dev/null';
exec($composerCommand, $output, $return_var);

if ($return_var === 0) {
    echo "<p>✅ Composer bulundu. Gerekli kütüphaneler yükleniyor...</p>";
    
    // Install dependencies
    $installCommand = 'cd ' . __DIR__ . ' && composer install';
    echo "<p>Çalıştırılıyor: <code>{$installCommand}</code></p>";
    
    exec($installCommand, $installOutput, $installReturn);
    
    if ($installReturn === 0) {
        echo "<p>✅ Kütüphaneler başarıyla yüklendi!</p>";
        
        // Create enhanced email sender
        $enhancedEmailContent = '<?php
require_once \'vendor/autoload.php\';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use Mpdf\Mpdf;

function sendEnhancedHoroscopeEmail($horoscopeText, $date, $latitude) {
    // Load settings
    $settings = [];
    if (file_exists(\'ai_settings.json\')) {
        $settings = json_decode(file_get_contents(\'ai_settings.json\'), true);
    }
    
    if (!$settings || !$settings[\'email_from\'] || !$settings[\'email_to\']) {
        throw new Exception(\'Email ayarları yapılandırılmamış.\');
    }
    
    // Generate PDF with mPDF
    $mpdf = new Mpdf([
        \'mode\' => \'utf-8\',
        \'format\' => \'A4\',
        \'margin_left\' => 15,
        \'margin_right\' => 15,
        \'margin_top\' => 16,
        \'margin_bottom\' => 16,
        \'margin_header\' => 9,
        \'margin_footer\' => 9
    ]);
    
    $htmlContent = \'<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: DejaVu Sans, sans-serif; line-height: 1.6; }
            .header { text-align: center; margin-bottom: 30px; }
            .content { margin: 20px 0; }
            .footer { margin-top: 30px; text-align: center; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🌟 Günlük Burç Yorumu</h1>
            <p>Tarih: \' . htmlspecialchars($date) . \'</p>
            <p>Enlem: \' . htmlspecialchars($latitude) . \'°</p>
        </div>
        
        <div class="content">
            \' . nl2br(htmlspecialchars($horoscopeText)) . \'
        </div>
        
        <div class="footer">
            <p>Bu yorum Astrolabe AI tarafından oluşturulmuştur.</p>
            <p>\' . date(\'d.m.Y H:i:s\') . \'</p>
        </div>
    </body>
    </html>\';
    
    $mpdf->WriteHTML($htmlContent);
    $pdfContent = $mpdf->Output(\'\', \'S\');
    
    // Send email with PHPMailer
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        if (!empty($settings[\'email_password\'])) {
            $mail->isSMTP();
            $mail->Host       = \'smtp.gmail.com\'; // Change as needed
            $mail->SMTPAuth   = true;
            $mail->Username   = $settings[\'email_from\'];
            $mail->Password   = $settings[\'email_password\'];
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;
        }
        
        // Recipients
        $mail->setFrom($settings[\'email_from\'], \'Astrolabe AI\');
        $mail->addAddress($settings[\'email_to\']);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = \'🌟 Günlük Burç Yorumunuz - \' . date(\'d.m.Y\');
        $mail->Body    = \'<p>Merhaba,</p>
                         <p>Günlük burç yorumunuz hazır!</p>
                         <p><strong>Tarih:</strong> \' . htmlspecialchars($date) . \'</p>
                         <p><strong>Enlem:</strong> \' . htmlspecialchars($latitude) . \'°</p>
                         <p>Detaylı yorumunuz ekte yer almaktadır.</p>
                         <p>İyi günler dileriz! 🌟</p>\';
        
        // Add PDF attachment
        $mail->addStringAttachment($pdfContent, \'burc_yorumu_\' . date(\'Y-m-d\') . \'.pdf\');
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        throw new Exception(\'Email gönderilemedi: \' . $mail->ErrorInfo);
    }
}
?>';
        
        file_put_contents('enhanced_email.php', $enhancedEmailContent);
        
        echo "<p>✅ Gelişmiş email sistemi oluşturuldu: <code>enhanced_email.php</code></p>";
        echo "<p>🎉 Kurulum tamamlandı! Artık gelişmiş PDF ve email özelliklerini kullanabilirsiniz.</p>";
        
    } else {
        echo "<p>❌ Kütüphaneler yüklenemedi. Hata:</p>";
        echo "<pre>" . implode("\n", $installOutput) . "</pre>";
    }
    
} else {
    echo "<p>❌ Composer bulunamadı.</p>";
    echo "<p>Gelişmiş özellikler için Composer kurmanız gerekiyor:</p>";
    echo "<ol>";
    echo "<li><a href='https://getcomposer.org/download/' target='_blank'>Composer\'ı indirin ve kurun</a></li>";
    echo "<li>Bu dosyayı tekrar çalıştırın</li>";
    echo "</ol>";
    echo "<p>💡 <strong>Not:</strong> Şu anda basit özellikler çalışmaktadır. Composer kurulumu isteğe bağlıdır.</p>";
}
?>