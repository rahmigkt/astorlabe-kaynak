<?php
// Test SQLite Database Connection and Operations

echo "<h2>SQLite Database Test</h2>";
echo "<pre>";

// Include database class
require_once 'includes/db.php';

try {
    echo "1. Testing database connection...\n";
    $db = Database::getInstance();
    echo "✓ Database connected successfully\n\n";
    
    echo "2. Testing session creation...\n";
    $session = $db->getSession();
    echo "✓ Session created: " . substr($session['session_key'], 0, 20) . "...\n";
    echo "  Session ID: " . $session['id'] . "\n\n";
    
    echo "3. Testing control state retrieval...\n";
    $state = $db->getControlState($session['id']);
    if ($state) {
        echo "✓ Control state found:\n";
        echo "  Latitude: " . $state['latitude'] . "\n";
        echo "  Longitude: " . $state['longitude'] . "\n";
        echo "  Year: " . $state['local_year'] . "\n\n";
    }
    
    echo "4. Testing control state update...\n";
    $updateData = [
        'latitude' => 41.0082,
        'longitude' => 28.9784,
        'star_chart_visible' => true
    ];
    $result = $db->updateControlState($session['id'], $updateData);
    if ($result) {
        echo "✓ State updated successfully\n";
        $newState = $db->getControlState($session['id']);
        echo "  New Latitude: " . $newState['latitude'] . "\n";
        echo "  New Longitude: " . $newState['longitude'] . "\n";
        echo "  Star Chart Visible: " . ($newState['star_chart_visible'] ? 'Yes' : 'No') . "\n\n";
    }
    
    echo "5. Testing location presets...\n";
    $presets = $db->getLocationPresets();
    echo "✓ Found " . count($presets) . " location presets:\n";
    foreach ($presets as $preset) {
        echo "  - " . $preset['name'] . " (" . $preset['latitude'] . ", " . $preset['longitude'] . ")\n";
    }
    
    echo "\n6. Database file location:\n";
    echo "  " . realpath(DB_FILE) . "\n";
    echo "  Size: " . filesize(DB_FILE) . " bytes\n";
    
    echo "\n✅ All tests passed successfully!\n";
    echo "\nYou can now access:\n";
    echo "- Control Panel: <a href='control.php'>control.php</a>\n";
    echo "- Display: <a href='display.php'>display.php</a>\n";
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}

echo "</pre>";
?>