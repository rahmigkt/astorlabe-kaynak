@echo off
echo.
echo ===============================
echo   🔄 XAMPP SERVICES RESTART
echo ===============================
echo.

echo Stopping Apache...
net stop Apache2.4 2>nul
taskkill /f /im httpd.exe 2>nul

echo.
echo Starting Apache...
net start Apache2.4

echo.
echo ✅ Services restarted!
echo.
echo Press any key to test socket extension...
pause >nul

echo.
echo 🔍 Testing socket extension...
cd /d "C:\Users\PC\Desktop\Workplace\astrolabe\control_system"
php check_php_config.php

echo.
pause