<?php
// List all files in downloads directory
header('Content-Type: text/html; charset=UTF-8');

$downloadsDir = __DIR__ . '/downloads/';

echo "<h2>Downloads Klasörü İçeriği</h2>";
echo "<p><strong>Klasör Yolu:</strong> " . $downloadsDir . "</p>";

if (!file_exists($downloadsDir)) {
    echo "<p style='color: red;'>❌ Downloads klasörü bulunamadı!</p>";
    exit;
}

$files = scandir($downloadsDir);
$fileCount = 0;

echo "<table border='1' cellpadding='5' cellspacing='0'>";
echo "<tr><th>Dosya Adı</th><th>Boyut</th><th>Oluşturulma</th><th>İşlem</th></tr>";

foreach ($files as $file) {
    if ($file != '.' && $file != '..') {
        $filepath = $downloadsDir . $file;
        $filesize = filesize($filepath);
        $filetime = date('Y-m-d H:i:s', filemtime($filepath));
        $fileCount++;
        
        echo "<tr>";
        echo "<td>$file</td>";
        echo "<td>$filesize bytes</td>";
        echo "<td>$filetime</td>";
        echo "<td>";
        echo "<a href='downloads/$file' target='_blank'>📄 Görüntüle</a> | ";
        echo "<a href='downloads/$file' download>⬇️ İndir</a>";
        echo "</td>";
        echo "</tr>";
    }
}

echo "</table>";
echo "<p><strong>Toplam dosya sayısı:</strong> $fileCount</p>";

// Test write
echo "<hr>";
echo "<h3>Test Yazma</h3>";
$testFile = $downloadsDir . 'test_' . time() . '.txt';
$writeResult = file_put_contents($testFile, 'Test yazma: ' . date('Y-m-d H:i:s'));
if ($writeResult !== false) {
    echo "<p style='color: green;'>✅ Test dosyası başarıyla oluşturuldu: " . basename($testFile) . "</p>";
} else {
    echo "<p style='color: red;'>❌ Test dosyası oluşturulamadı!</p>";
}
?>