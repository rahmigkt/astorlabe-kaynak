<?php
// Custom error handler to suppress all errors
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    // Ignore all errors
    return true;
});

// Completely disable error display
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);

header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Completely disable output buffering and compression
@ini_set('output_buffering', 'off');
@ini_set('zlib.output_compression', false);
@ini_set('implicit_flush', true);
@ini_set('max_execution_time', 0);
set_time_limit(0);

// Clean all existing output buffers
while (ob_get_level() > 0) {
    ob_end_clean();
}

// Ensure no output buffering at all
if (function_exists('apache_setenv')) {
    @apache_setenv('no-gzip', 1);
}
@ini_set('zlib.output_compression', 'Off');

require_once 'env_loader.php';

// Load settings - prioritize JSON over .env
$settings = [];
if (file_exists('ai_settings.json')) {
    $settings = json_decode(file_get_contents('ai_settings.json'), true);
}

// Use .env values only as fallback if not set in JSON
$envDefaults = [
    'openrouter_key' => env('OPENROUTER_API_KEY', ''),
    'model_name' => env('AI_MODEL', 'anthropic/claude-3-sonnet'),
    'system_prompt' => env('SYSTEM_PROMPT', 'Sen bir astroloji uzmanısın. Verilen ephemeris verilerine ve tarihe göre kişiselleştirilmiş günlük burç yorumu yaz. Türkçe ve pozitif bir dille yaz.'),
    'temperature' => floatval(env('AI_TEMPERATURE', 0.7))
];

// JSON settings take priority over .env
$settings = array_merge($envDefaults, $settings);

// Trim API key
if (isset($settings['openrouter_key'])) {
    $settings['openrouter_key'] = trim($settings['openrouter_key']);
}

// Debug log the key (first 10 chars only for security)
error_log("Using API Key: " . substr($settings['openrouter_key'], 0, 10) . "...");

if (!$settings['openrouter_key']) {
    echo "data: " . json_encode(['error' => 'OpenRouter API key yapılandırılmamış. .env dosyasını kontrol edin veya admin panelinden ayarları yapın.']) . "\n\n";
    echo "data: [DONE]\n\n";
    flush();
    exit;
}

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo "data: " . json_encode(['error' => 'Geçersiz veri.']) . "\n\n";
    echo "data: [DONE]\n\n";
    flush();
    exit;
}

// Test mode - uncomment to test streaming
// echo "data: " . json_encode(['content' => 'Test mesajı: Stream çalışıyor! ']) . "\n\n";
// flush();
// sleep(1);
// echo "data: " . json_encode(['content' => 'API anahtarınız: ' . substr($settings['openrouter_key'], 0, 10) . '...']) . "\n\n";
// flush();
// echo "data: [DONE]\n\n";
// flush();
// exit;

// Create ephemeris summary for AI
$ephemerisSummary = sprintf(
    "Tarih: %s\nEnlem: %s°\nYıl: %s, Ay: %s, Gün: %s\nSaat: %s:%02d",
    $input['date'],
    $input['latitude'],
    $input['year'],
    $input['month'],
    $input['day'],
    $input['hour'],
    $input['minute']
);

// Determine zodiac sign based on date
function getZodiacSign($month, $day) {
    $signs = [
        ['name' => 'Oğlak', 'start_month' => 12, 'start_day' => 22, 'end_month' => 1, 'end_day' => 19],
        ['name' => 'Kova', 'start_month' => 1, 'start_day' => 20, 'end_month' => 2, 'end_day' => 18],
        ['name' => 'Balık', 'start_month' => 2, 'start_day' => 19, 'end_month' => 3, 'end_day' => 20],
        ['name' => 'Koç', 'start_month' => 3, 'start_day' => 21, 'end_month' => 4, 'end_day' => 19],
        ['name' => 'Boğa', 'start_month' => 4, 'start_day' => 20, 'end_month' => 5, 'end_day' => 20],
        ['name' => 'İkizler', 'start_month' => 5, 'start_day' => 21, 'end_month' => 6, 'end_day' => 20],
        ['name' => 'Yengeç', 'start_month' => 6, 'start_day' => 21, 'end_month' => 7, 'end_day' => 22],
        ['name' => 'Aslan', 'start_month' => 7, 'start_day' => 23, 'end_month' => 8, 'end_day' => 22],
        ['name' => 'Başak', 'start_month' => 8, 'start_day' => 23, 'end_month' => 9, 'end_day' => 22],
        ['name' => 'Terazi', 'start_month' => 9, 'start_day' => 23, 'end_month' => 10, 'end_day' => 22],
        ['name' => 'Akrep', 'start_month' => 10, 'start_day' => 23, 'end_month' => 11, 'end_day' => 21],
        ['name' => 'Yay', 'start_month' => 11, 'start_day' => 22, 'end_month' => 12, 'end_day' => 21]
    ];
    
    foreach ($signs as $sign) {
        if (($month == $sign['start_month'] && $day >= $sign['start_day']) ||
            ($month == $sign['end_month'] && $day <= $sign['end_day'])) {
            return $sign['name'];
        }
    }
    return 'Oğlak'; // Default
}

$zodiacSign = getZodiacSign($input['month'], $input['day']);

// Create the prompt
$prompt = sprintf(
    "%s

Aşağıdaki bilgilere göre günlük burç yorumu hazırla:

%s

Burç: %s

Lütfen şu konuları içeren, pozitif ve kişiselleştirilmiş bir günlük burç yorumu yaz:
1. Genel enerji ve ruh hali
2. Aşk ve ilişkiler
3. Kariyer ve iş hayatı  
4. Sağlık ve refah
5. Günün özel tavsiyesi

Yorumu Türkçe yazın ve yaklaşık 200-300 kelime olsun.",
    $settings['system_prompt'],
    $ephemerisSummary,
    $zodiacSign
);

// OpenRouter API request
$data = [
    'model' => $settings['model_name'],
    'messages' => [
        [
            'role' => 'user',
            'content' => $prompt
        ]
    ],
    'temperature' => floatval($settings['temperature']),
    'stream' => true
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://openrouter.ai/api/v1/chat/completions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $settings['openrouter_key'],
    'HTTP-Referer: http://localhost:8081', // Required for OpenRouter
    'X-Title: Astrolabe Horoscope App'
]);

// Disable SSL verification for local development
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

// Set stream to true for reading
curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) {
    $lines = explode("\n", $data);
    
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        
        if (strpos($line, 'data: ') === 0) {
            $jsonData = substr($line, 6); // Remove "data: " prefix
            
            if ($jsonData === '[DONE]') {
                echo "data: [DONE]\n\n";
                flush();
                continue;
            }
            
            try {
                $decoded = json_decode($jsonData, true);
                
                if (isset($decoded['choices'][0]['delta']['content'])) {
                    $content = $decoded['choices'][0]['delta']['content'];
                    
                    // Send content to client
                    echo "data: " . json_encode(['content' => $content]) . "\n\n";
                    flush();
                }
                
                if (isset($decoded['choices'][0]['finish_reason']) && $decoded['choices'][0]['finish_reason'] === 'stop') {
                    echo "data: [DONE]\n\n";
                    flush();
                }
            } catch (Exception $e) {
                error_log("JSON parse error in stream: " . $e->getMessage());
            }
        }
    }
    
    return strlen($data);
});

$result = curl_exec($ch);

if (curl_error($ch)) {
    $error_msg = curl_error($ch);
    error_log("CURL Error: " . $error_msg);
    echo "data: " . json_encode(['error' => 'API isteği başarısız: ' . $error_msg]) . "\n\n";
    echo "data: [DONE]\n\n";
    flush();
} else {
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if ($http_code !== 200) {
        error_log("HTTP Error Code: " . $http_code);
    }
}

curl_close($ch);
flush();
?>
