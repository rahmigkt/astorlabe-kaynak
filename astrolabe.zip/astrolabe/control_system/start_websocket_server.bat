@echo off
echo.
echo =================================
echo   🚀 ASTROLABE WEBSOCKET SERVER
echo =================================
echo.
echo Starting WebSocket server on localhost:8080...
echo Press Ctrl+C to stop the server
echo.

cd /d "C:\Users\PC\Desktop\Workplace\astrolabe\control_system"
php websocket_server.php

echo.
echo Server stopped.
pause