<?php
// Direct test for email PDF creation
header('Content-Type: application/json');

// Create downloads directory if not exists
$downloadsDir = __DIR__ . '/downloads/';
if (!file_exists($downloadsDir)) {
    mkdir($downloadsDir, 0755, true);
}

// Test data
$testData = [
    'horoscope_text' => 'Bu bir test metnidir. Burç yorumu burada olacak.',
    'date' => date('Y-m-d'),
    'latitude' => 41
];

// Create HTML content
$htmlContent = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Günlük Burç Yorumu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #4a5568;
            margin-bottom: 30px;
            padding-bottom: 20px;
        }
        .header h1 {
            color: #2d3748;
            margin: 0;
        }
        .date-info {
            background: #f7fafc;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #4299e1;
        }
        .horoscope-content {
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .footer {
            text-align: center;
            color: #718096;
            font-size: 12px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🌟 Günlük Burç Yorumu</h1>
        <p>Kişiselleştirilmiş Astrolojik Analiz</p>
    </div>
    
    <div class="date-info">
        <h3>📅 Tarih Bilgileri</h3>
        <p><strong>Tarih:</strong> ' . $testData['date'] . '</p>
        <p><strong>Enlem:</strong> ' . $testData['latitude'] . '°</p>
    </div>
    
    <div class="horoscope-content">
        <h3>🔮 AI Burç Yorumu</h3>
        <p>' . $testData['horoscope_text'] . '</p>
    </div>
    
    <div class="footer">
        <p>Bu yorum Astrolabe AI tarafından oluşturulmuştur.</p>
        <p>Tarih: ' . date('d.m.Y H:i:s') . '</p>
    </div>
</body>
</html>
';

// Create file
$filename = 'test_burc_' . date('Y-m-d_H-i-s') . '.html';
$filepath = $downloadsDir . $filename;

$result = file_put_contents($filepath, $htmlContent);

$response = [
    'success' => $result !== false,
    'filename' => $filename,
    'filepath' => $filepath,
    'bytes_written' => $result,
    'file_exists' => file_exists($filepath),
    'file_size' => file_exists($filepath) ? filesize($filepath) : 0,
    'download_url' => 'downloads/' . $filename,
    'error' => $result === false ? error_get_last() : null
];

echo json_encode($response, JSON_PRETTY_PRINT);
?>