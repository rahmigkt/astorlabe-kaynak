<!-- Main Astrolabe Structure -->
<div class="main-container">
    <div class="charts-wrapper">
        <!-- Astrolabe Container -->
        <div class="astrolabe-container">
            <svg id="astrolabe_svg" width="1000" height="1000" viewBox="-500 -500 1000 1000">
                <defs>
                    <!-- Define filters and gradients here -->
                    <filter id="starGlow">
                        <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                        <feMerge>
                            <feMergeNode in="coloredBlur"/>
                            <feMergeNode in="SourceGraphic"/>
                        </feMerge>
                    </filter>
                </defs>
                
                <!-- Astrolabe layers will be added dynamically -->
                <g id="mater"></g>
                <g id="tympanum"></g>
                <g id="rete"></g>
                <g id="rule"></g>
            </svg>
        </div>
        
        <!-- Star Chart Container -->
        <div class="star-chart-container" style="display: none;">
            <!-- Star chart content from star_chart.js -->
        </div>
        
        <!-- World Map Container -->
        <div class="world-map-container" style="display: none;">
            <!-- World map content from world_map.js -->
        </div>
    </div>
    
    <?php if (!isset($includeControlsOnly) || $includeControlsOnly !== false): ?>
    <!-- Control panels - only shown in control mode -->
    <div class="controls">
        <!-- Control elements here -->
    </div>
    <?php endif; ?>
</div>