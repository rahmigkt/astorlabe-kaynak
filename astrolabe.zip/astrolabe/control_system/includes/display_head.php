<!-- Common head elements for display -->
<link rel="stylesheet" href="../../style.css">

<!-- jQuery and jQuery UI -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

<!-- D3.js for visualizations -->
<script src="../../d3-selection.v1.min.js"></script>
<script src="../../d3-dispatch.v1.min.js"></script>
<script src="../../d3-drag.v1.min.js"></script>

<!-- Astrolabe core scripts -->
<script src="../../astronomy.js"></script>
<script src="../../constellation_data.js"></script>
<script src="../../stars.js"></script>
<script src="../../revolve.js"></script>
<script src="../../infrastructure.js"></script>
<script src="../../astrolabe_controls.js"></script>
<script src="../../timewheels.js"></script>
<script src="../../star_chart.js"></script>
<script src="../../world_map.js"></script>
<script src="../../world_map_data.js"></script>
<script src="../../world_map_enhanced.js"></script>
<script src="../../nav_buttons.js"></script>
<script src="../../panel_buttons.js"></script>
<script src="../../geolocation.js"></script>
<script src="../../multi_calendar.js"></script>
<script src="../../star_animations.js"></script>
<script src="../../iphone_sliders.js"></script>
<script src="../../head_svg_new.js"></script>