// Common JavaScript functions for control panel and projection

const AstrolabeCommon = {
    // API endpoints
    API: {
        getState: 'api/get_state.php',
        updateState: 'api/update_state.php',
        getPresets: 'api/get_presets.php'
    },
    
    // Update interval in milliseconds
    UPDATE_INTERVAL: 500,
    
    // Get session key from localStorage or generate new one
    getSessionKey: function() {
        let sessionKey = localStorage.getItem('astrolabe_session');
        if (!sessionKey) {
            sessionKey = this.generateSessionKey();
            localStorage.setItem('astrolabe_session', sessionKey);
        }
        return sessionKey;
    },
    
    // Generate random session key
    generateSessionKey: function() {
        return 'xxxx-xxxx-4xxx-yxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    },
    
    // Fetch current state from database
    fetchState: async function(sessionKey) {
        try {
            const response = await fetch(this.API.getState + '?session=' + sessionKey);
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
        } catch (error) {
            console.error('Error fetching state:', error);
            return null;
        }
    },
    
    // Update state in database
    updateState: async function(sessionKey, data) {
        try {
            const response = await fetch(this.API.updateState, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    session: sessionKey,
                    ...data
                })
            });
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
        } catch (error) {
            console.error('Error updating state:', error);
            return null;
        }
    },
    
    // Apply state to UI elements
    applyStateToUI: function(state) {
        if (!state) return;
        
        // Update latitude/longitude
        if (state.latitude !== undefined) {
            const latSlider = document.getElementById('latitudeSlider');
            if (latSlider) {
                latSlider.value = state.latitude;
                $(latSlider).trigger('change');
            }
        }
        
        if (state.longitude !== undefined) {
            const lonSlider = document.getElementById('longitudeSlider');
            if (lonSlider) {
                lonSlider.value = state.longitude;
                $(lonSlider).trigger('change');
            }
        }
        
        // Update date/time
        if (state.local_year) {
            this.updateDateTime(state);
        }
        
        // Update visibility toggles
        if (state.star_chart_visible !== undefined) {
            this.toggleStarChart(state.star_chart_visible);
        }
        
        if (state.world_map_visible !== undefined) {
            this.toggleWorldMap(state.world_map_visible);
        }
        
        if (state.astrolabe_visible !== undefined) {
            this.toggleAstrolabe(state.astrolabe_visible);
        }
        
        // Update display options
        if (state.sky_coloration !== undefined) {
            this.toggleSkyColoration(state.sky_coloration);
        }
        
        if (state.star_names_visible !== undefined && window.StarChart) {
            window.StarChart.toggleStarNames(state.star_names_visible);
        }
    },
    
    // Update date/time elements
    updateDateTime: function(state) {
        const elements = {
            'local_year': state.local_year,
            'local_month': state.local_month,
            'local_day': state.local_day,
            'local_hour': state.local_hour,
            'local_minutes': state.local_minute,
            'local_seconds': state.local_second
        };
        
        for (const [id, value] of Object.entries(elements)) {
            const elem = document.getElementById(id);
            if (elem) {
                elem.textContent = value;
            }
        }
        
        // Update Julian Day
        if (state.julian_day) {
            const jdElem = document.getElementById('julian_day_local');
            if (jdElem) {
                jdElem.textContent = state.julian_day;
            }
        }
    },
    
    // Toggle star chart visibility
    toggleStarChart: function(visible) {
        const container = document.querySelector('.star-chart-container');
        if (container) {
            container.style.display = visible ? 'block' : 'none';
        }
    },
    
    // Toggle world map visibility
    toggleWorldMap: function(visible) {
        const container = document.querySelector('.world-map-container');
        if (container) {
            container.style.display = visible ? 'block' : 'none';
        }
    },
    
    // Toggle astrolabe visibility
    toggleAstrolabe: function(visible) {
        const container = document.querySelector('.astrolabe-container');
        if (container) {
            container.style.display = visible ? 'block' : 'none';
        }
    },
    
    // Toggle sky coloration
    toggleSkyColoration: function(enabled) {
        const skyFlag = document.getElementById('sky_flag');
        if (skyFlag) {
            skyFlag.innerHTML = enabled ? '1' : '0';
            if (enabled && typeof sky_coloration === 'function') {
                sky_coloration();
            }
        }
    },
    
    // Format location display
    formatLocation: function(lat, lon) {
        const latDir = lat >= 0 ? 'N' : 'S';
        const lonDir = lon >= 0 ? 'E' : 'W';
        return `${Math.abs(lat).toFixed(2)}°${latDir}, ${Math.abs(lon).toFixed(2)}°${lonDir}`;
    },
    
    // Calculate Julian Day
    calculateJulianDay: function(year, month, day, hour, minute, second) {
        const a = Math.floor((14 - month) / 12);
        const y = year + 4800 - a;
        const m = month + 12 * a - 3;
        
        const jdn = day + Math.floor((153 * m + 2) / 5) + 365 * y + 
                   Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
        
        const jd = jdn + (hour - 12) / 24 + minute / 1440 + second / 86400;
        
        return jd;
    },
    
    // Initialize based on mode (control or display)
    init: function(mode) {
        console.log('Initializing Astrolabe Common in', mode, 'mode');
        
        const sessionKey = this.getSessionKey();
        console.log('Session key:', sessionKey);
        
        if (mode === 'display') {
            // Start polling for updates
            this.startPolling(sessionKey);
        } else if (mode === 'control') {
            // Setup control event listeners
            this.setupControlListeners(sessionKey);
        }
    },
    
    // Start polling for state updates (display mode)
    startPolling: function(sessionKey) {
        const poll = async () => {
            const state = await this.fetchState(sessionKey);
            if (state) {
                this.applyStateToUI(state);
            }
        };
        
        // Initial poll
        poll();
        
        // Set up recurring poll
        setInterval(poll, this.UPDATE_INTERVAL);
    },
    
    // Setup control listeners (control mode)
    setupControlListeners: function(sessionKey) {
        // Latitude slider
        const latSlider = document.getElementById('latitudeSlider');
        if (latSlider) {
            latSlider.addEventListener('change', () => {
                this.updateState(sessionKey, { latitude: parseFloat(latSlider.value) });
            });
        }
        
        // Longitude slider
        const lonSlider = document.getElementById('longitudeSlider');
        if (lonSlider) {
            lonSlider.addEventListener('change', () => {
                this.updateState(sessionKey, { longitude: parseFloat(lonSlider.value) });
            });
        }
        
        // Add more control listeners as needed
        console.log('Control listeners setup complete');
    }
};