<?php
require_once 'config.php';

class Database {
    private static $instance = null;
    private $conn;
    
    private function __construct() {
        try {
            // SQLite connection
            $this->conn = new PDO(
                "sqlite:" . DB_FILE,
                null,
                null,
                array(
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                )
            );
            
            // Enable foreign keys for SQLite
            $this->conn->exec("PRAGMA foreign_keys = ON");
            
            // Initialize database if needed
            $this->initializeDatabase();
            
        } catch(PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }
    
    // Initialize database tables if they don't exist
    private function initializeDatabase() {
        // Create tables (this will create any missing tables)
        $this->createTables();
        
        // Check if we need to insert default data
        $result = $this->conn->query("SELECT COUNT(*) FROM location_presets");
        if ($result->fetchColumn() == 0) {
            // Insert default data only if tables are empty
            $this->insertDefaultData();
        }
        
        // Always try to create default admin user
        $this->createDefaultAdmin();
    }
    
    // Create database tables
    private function createTables() {
        // Sessions table
        $this->conn->exec("
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_key TEXT UNIQUE NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                is_active INTEGER DEFAULT 1
            )
        ");
        
        // Control states table
        $this->conn->exec("
            CREATE TABLE IF NOT EXISTS control_states (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                latitude REAL DEFAULT 40.0,
                longitude REAL DEFAULT 0.0,
                julian_day REAL,
                local_year INTEGER,
                local_month INTEGER,
                local_day INTEGER,
                local_hour INTEGER,
                local_minute INTEGER,
                local_second INTEGER,
                star_chart_visible INTEGER DEFAULT 0,
                world_map_visible INTEGER DEFAULT 0,
                astrolabe_visible INTEGER DEFAULT 1,
                sky_coloration INTEGER DEFAULT 0,
                star_names_visible INTEGER DEFAULT 1,
                constellation_lines_visible INTEGER DEFAULT 1,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
            )
        ");
        
        // Location presets table
        $this->conn->exec("
            CREATE TABLE IF NOT EXISTS location_presets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                timezone TEXT
            )
        ");
        
        // Credentials table for authentication
        $this->conn->exec("
            CREATE TABLE IF NOT EXISTS credentials (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_login DATETIME,
                is_active INTEGER DEFAULT 1
            )
        ");
        
        // Create index for performance
        $this->conn->exec("CREATE INDEX IF NOT EXISTS idx_session_updated ON control_states(session_id, updated_at)");
        $this->conn->exec("CREATE INDEX IF NOT EXISTS idx_credentials_username ON credentials(username)");
    }
    
    // Insert default location presets
    private function insertDefaultData() {
        $presets = [
            ['Istanbul', 41.0082, 28.9784, 'Europe/Istanbul'],
            ['New York', 40.7128, -74.0060, 'America/New_York'],
            ['London', 51.5074, -0.1278, 'Europe/London'],
            ['Tokyo', 35.6762, 139.6503, 'Asia/Tokyo'],
            ['Sydney', -33.8688, 151.2093, 'Australia/Sydney'],
            ['Cairo', 30.0444, 31.2357, 'Africa/Cairo'],
            ['Moscow', 55.7558, 37.6173, 'Europe/Moscow'],
            ['Dubai', 25.2048, 55.2708, 'Asia/Dubai']
        ];
        
        $stmt = $this->conn->prepare("INSERT INTO location_presets (name, latitude, longitude, timezone) VALUES (?, ?, ?, ?)");
        foreach ($presets as $preset) {
            $stmt->execute($preset);
        }
    }
    
    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new Database();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->conn;
    }
    
    // Get or create session
    public function getSession($sessionKey = null) {
        if (!$sessionKey) {
            $sessionKey = $this->generateSessionKey();
        }
        
        $stmt = $this->conn->prepare("SELECT * FROM sessions WHERE session_key = ?");
        $stmt->execute([$sessionKey]);
        $session = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$session) {
            $stmt = $this->conn->prepare("INSERT INTO sessions (session_key) VALUES (?)");
            $stmt->execute([$sessionKey]);
            $sessionId = $this->conn->lastInsertId();
            
            // Initialize control state for new session
            $this->initializeControlState($sessionId);
            
            return [
                'id' => $sessionId,
                'session_key' => $sessionKey,
                'is_new' => true
            ];
        }
        
        // Update last activity
        $stmt = $this->conn->prepare("UPDATE sessions SET updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$session['id']]);
        
        return [
            'id' => $session['id'],
            'session_key' => $session['session_key'],
            'is_new' => false
        ];
    }
    
    // Initialize control state for new session
    private function initializeControlState($sessionId) {
        $now = new DateTime();
        
        $stmt = $this->conn->prepare("
            INSERT INTO control_states (
                session_id, latitude, longitude, 
                local_year, local_month, local_day,
                local_hour, local_minute, local_second,
                julian_day
            ) VALUES (
                ?, 40.0, 0.0, ?, ?, ?, ?, ?, ?, ?
            )
        ");
        
        $jd = $this->calculateJulianDay();
        $stmt->execute([
            $sessionId,
            $now->format('Y'),
            $now->format('n'),
            $now->format('j'),
            $now->format('G'),
            $now->format('i'),
            $now->format('s'),
            $jd
        ]);
    }
    
    // Get current control state
    public function getControlState($sessionId) {
        $stmt = $this->conn->prepare("
            SELECT * FROM control_states 
            WHERE session_id = ? 
            ORDER BY updated_at DESC 
            LIMIT 1
        ");
        $stmt->execute([$sessionId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // Update control state
    public function updateControlState($sessionId, $data) {
        $allowedFields = [
            'latitude', 'longitude', 'julian_day',
            'local_year', 'local_month', 'local_day',
            'local_hour', 'local_minute', 'local_second',
            'star_chart_visible', 'world_map_visible', 'astrolabe_visible',
            'sky_coloration', 'star_names_visible', 'constellation_lines_visible'
        ];
        
        $updates = [];
        $values = [];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowedFields)) {
                $updates[] = "$key = ?";
                // Convert boolean to integer for SQLite
                if (is_bool($value)) {
                    $value = $value ? 1 : 0;
                }
                $values[] = $value;
            }
        }
        
        if (empty($updates)) {
            return false;
        }
        
        // Add updated_at
        $updates[] = "updated_at = CURRENT_TIMESTAMP";
        $values[] = $sessionId;
        
        $sql = "UPDATE control_states SET " . implode(', ', $updates) . 
               " WHERE session_id = ?";
        
        $stmt = $this->conn->prepare($sql);
        return $stmt->execute($values);
    }
    
    // Get location presets
    public function getLocationPresets() {
        $stmt = $this->conn->prepare("SELECT * FROM location_presets ORDER BY name");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Generate unique session key
    private function generateSessionKey() {
        return bin2hex(random_bytes(32));
    }
    
    // Calculate Julian Day
    private function calculateJulianDay($year = null, $month = null, $day = null, 
                                       $hour = null, $minute = null, $second = null) {
        if (!$year) {
            $year = date('Y');
            $month = date('n');
            $day = date('j');
            $hour = date('G');
            $minute = date('i');
            $second = date('s');
        }
        
        $a = floor((14 - $month) / 12);
        $y = $year + 4800 - $a;
        $m = $month + 12 * $a - 3;
        
        $jdn = $day + floor((153 * $m + 2) / 5) + 365 * $y + 
               floor($y / 4) - floor($y / 100) + floor($y / 400) - 32045;
        
        $jd = $jdn + ($hour - 12) / 24 + $minute / 1440 + $second / 86400;
        
        return $jd;
    }
    
    // Authentication methods
    
    // Create default admin user
    public function createDefaultAdmin() {
        $stmt = $this->conn->prepare("SELECT COUNT(*) FROM credentials WHERE username = 'admin'");
        $stmt->execute();
        $count = $stmt->fetchColumn();
        
        if ($count == 0) {
            // Create default admin user with password 'admin123'
            $passwordHash = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $this->conn->prepare("INSERT INTO credentials (username, password_hash) VALUES (?, ?)");
            $stmt->execute(['admin', $passwordHash]);
            return true;
        }
        return false;
    }
    
    // Authenticate user
    public function authenticateUser($username, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM credentials WHERE username = ? AND is_active = 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password_hash'])) {
            // Update last login
            $stmt = $this->conn->prepare("UPDATE credentials SET last_login = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$user['id']]);
            
            return [
                'id' => $user['id'],
                'username' => $user['username'],
                'authenticated' => true
            ];
        }
        
        return ['authenticated' => false];
    }
    
    // Check if user is authenticated (session-based)
    public function isAuthenticated() {
        return isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true;
    }
    
    // Require authentication
    public function requireAuth() {
        if (!$this->isAuthenticated()) {
            header('Location: login.php');
            exit();
        }
    }
    
    // Logout user
    public function logout() {
        session_start();
        session_destroy();
        header('Location: login.php');
        exit();
    }
}
?>
