<?php
// Database configuration - SQLite
define('DB_FILE', __DIR__ . '/../../data/astrolabe.db');
define('DB_DIR', __DIR__ . '/../../data');

// Application settings
define('UPDATE_INTERVAL', 500); // milliseconds
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds

// Timezone
date_default_timezone_set('UTC');

// Error reporting (development mode)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// CORS headers for AJAX requests
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

// Create data directory if not exists
if (!file_exists(DB_DIR)) {
    mkdir(DB_DIR, 0777, true);
}
?>