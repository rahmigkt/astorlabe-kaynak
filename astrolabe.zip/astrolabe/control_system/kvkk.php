<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KVKK Aydınlatma Metni - Astrolabe</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Play:wght@400;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: radial-gradient(ellipse at bottom, #1b2735 0%, #090a0f 100%);
            color: #e5e7eb;
            min-height: 100vh;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 2rem;
        }
        h1, h2 {
            font-family: 'Play', sans-serif;
            color: #ffd700;
        }
        .content-box {
            background: rgba(10, 10, 20, 0.5);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 1rem;
            padding: 2rem;
            margin-top: 2rem;
        }
        p, li {
            line-height: 1.8;
            margin-bottom: 1rem;
        }
        h2 {
            margin-top: 2rem;
            margin-bottom: 1rem;
            font-size: 1.5rem;
            color: #ffa500;
        }
        .back-button {
            display: inline-block;
            margin-top: 2rem;
            padding: 0.75rem 1.5rem;
            background: linear-gradient(135deg, #ef4444 0%, #f97316 100%);
            color: white;
            text-decoration: none;
            border-radius: 0.5rem;
            font-family: 'Play', sans-serif;
            transition: all 0.3s;
        }
        .back-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(239, 68, 68, 0.3);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="content-box">
            <h1 class="text-3xl font-bold mb-6">KVKK Aydınlatma Metni</h1>
            
            <p>İşbu aydınlatma metni, 6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") uyarınca, Astrolabe Burç Analizi Sistemi ("Sistem") tarafından kişisel verilerinizin nasıl işlendiği hakkında sizi bilgilendirmek amacıyla hazırlanmıştır.</p>
            
            <h2>1. Veri Sorumlusu</h2>
            <p>Kişisel verileriniz, veri sorumlusu sıfatıyla Astrolabe Sistemi tarafından aşağıda açıklanan kapsamda işlenebilecektir.</p>
            
            <h2>2. İşlenen Kişisel Veriler</h2>
            <p>Sistem üzerinden paylaştığınız aşağıdaki kişisel verileriniz işlenmektedir:</p>
            <ul class="list-disc list-inside ml-4">
                <li>E-posta adresi (burç analizi raporunun gönderilmesi için)</li>
                <li>Doğum tarihi ve saat bilgisi (burç analizi hesaplaması için)</li>
                <li>Konum bilgisi (enlem/boylam - astronomik hesaplamalar için)</li>
            </ul>
            
            <h2>3. Kişisel Verilerin İşlenme Amaçları</h2>
            <p>Toplanan kişisel verileriniz aşağıdaki amaçlarla işlenmektedir:</p>
            <ul class="list-disc list-inside ml-4">
                <li>Kişiye özel burç analizi raporunun hazırlanması</li>
                <li>Hazırlanan raporun e-posta yoluyla iletilmesi</li>
                <li>Sistemin iyileştirilmesi ve hizmet kalitesinin artırılması</li>
            </ul>
            
            <h2>4. Kişisel Verilerin İşlenme Hukuki Sebepleri</h2>
            <p>Kişisel verileriniz, KVKK'nın 5. maddesinde belirtilen;</p>
            <ul class="list-disc list-inside ml-4">
                <li>Açık rızanızın bulunması</li>
                <li>Bir hizmetin ifası için zorunlu olması</li>
            </ul>
            <p>hukuki sebeplerine dayanarak işlenmektedir.</p>
            
            <h2>5. Kişisel Verilerin Aktarılması</h2>
            <p>Kişisel verileriniz, yasal yükümlülükler ve düzenleyici otoritelerin talepleri doğrultusunda, yetkili kamu kurum ve kuruluşlarıyla paylaşılabilir. Bunun dışında, kişisel verileriniz üçüncü kişilerle paylaşılmamaktadır.</p>
            
            <h2>6. Kişisel Verilerin Saklanma Süresi</h2>
            <p>E-posta adresiniz, sadece rapor gönderimi için geçici olarak işlenir ve gönderim tamamlandıktan sonra sistemden silinir. Diğer verileriniz, hizmetin sunulması için gerekli süre boyunca ve yasal saklama süreleri gözetilerek saklanır.</p>
            
            <h2>7. Kişisel Veri Sahibinin Hakları</h2>
            <p>KVKK'nın 11. maddesi uyarınca sahip olduğunuz haklar:</p>
            <ul class="list-disc list-inside ml-4">
                <li>Kişisel verilerinizin işlenip işlenmediğini öğrenme</li>
                <li>İşlenmişse buna ilişkin bilgi talep etme</li>
                <li>İşlenme amacını ve amacına uygun kullanılıp kullanılmadığını öğrenme</li>
                <li>Yurt içinde veya yurt dışında aktarıldığı üçüncü kişileri bilme</li>
                <li>Eksik veya yanlış işlenmişse düzeltilmesini isteme</li>
                <li>KVKK'nın 7. maddesinde öngörülen şartlar çerçevesinde silinmesini veya yok edilmesini isteme</li>
                <li>Düzeltme veya silme işlemlerinin, aktarıldığı üçüncü kişilere bildirilmesini isteme</li>
                <li>Münhasıran otomatik sistemler vasıtasıyla analiz edilmesi suretiyle aleyhinize bir sonucun ortaya çıkmasına itiraz etme</li>
                <li>Kanuna aykırı olarak işlenmesi sebebiyle zarara uğramanız halinde zararın giderilmesini talep etme</li>
            </ul>
            
            <h2>8. İletişim</h2>
            <p>Yukarıda belirtilen haklarınızı kullanmak için talebinizi, kimliğinizi tespit edici gerekli bilgiler ile birlikte sistem üzerinden iletebilirsiniz.</p>
            
            <div class="mt-8 p-4 bg-orange-900/20 border border-orange-400/30 rounded-lg">
                <p class="text-sm text-orange-300">
                    <strong>Not:</strong> Bu aydınlatma metni, son güncelleme tarihi itibarıyla geçerlidir ve yasal değişiklikler doğrultusunda güncellenebilir.
                </p>
                <p class="text-xs text-gray-400 mt-2">Son güncelleme: <?php echo date('d.m.Y'); ?></p>
            </div>
            
            <a href="javascript:window.close();" class="back-button">Kapat</a>
        </div>
    </div>
</body>
</html>