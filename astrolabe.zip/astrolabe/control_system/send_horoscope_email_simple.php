<?php
// ULTRA SIMPLE VERSION - Just create file and return link

header('Content-Type: application/json');

// Get input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['horoscope_text'])) {
    echo json_encode(['success' => false, 'error' => 'No data']);
    exit;
}

// Create HTML content
$htmlContent = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Burç Yorumu</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .header { text-align: center; color: #333; }
        .content { background: #f5f5f5; padding: 20px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🌟 Günlük Burç Yorumu</h1>
        <p>Tarih: ' . htmlspecialchars($input['date'] ?? date('Y-m-d')) . '</p>
        <p>Enlem: ' . htmlspecialchars($input['latitude'] ?? '41') . '°</p>
    </div>
    <div class="content">
        <h3>AI Burç Yorumu</h3>
        <p>' . nl2br(htmlspecialchars($input['horoscope_text'])) . '</p>
    </div>
    <div style="text-align: center; color: #999; font-size: 12px;">
        <p>Astrolabe AI - ' . date('d.m.Y H:i:s') . '</p>
    </div>
</body>
</html>';

// Create file
$filename = 'burc_yorumu_' . date('Y-m-d_H-i-s') . '.html';
$filepath = __DIR__ . '/downloads/' . $filename;

// Ensure downloads directory exists
if (!file_exists(__DIR__ . '/downloads/')) {
    mkdir(__DIR__ . '/downloads/', 0755, true);
}

// Write file
$result = file_put_contents($filepath, $htmlContent);

// Return response
if ($result !== false) {
    echo json_encode([
        'success' => true,
        'message' => 'Burç yorumu başarıyla gönderildi!',
        'download_link' => $filename
    ]);
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Dosya oluşturulamadı'
    ]);
}
?>