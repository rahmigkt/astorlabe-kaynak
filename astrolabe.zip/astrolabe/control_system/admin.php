<?php
session_start();
require_once 'env_loader.php';

// Authentication using .env
$admin_password = env('ADMIN_PASSWORD', 'admin123');

if (isset($_POST['action']) && $_POST['action'] == 'login' && isset($_POST['password']) && $_POST['password'] == $admin_password) {
    $_SESSION['admin'] = true;
}

if (isset($_POST['action']) && $_POST['action'] == 'logout') {
    session_destroy();
    header('Location: admin.php');
    exit;
}

// Initialize message variable
$message = null;

// Save settings
if (isset($_SESSION['admin']) && $_SESSION['admin'] && isset($_POST['action']) && $_POST['action'] == 'save_settings') {
    $newSettings = [
        'openrouter_key' => $_POST['openrouter_key'],
        'model_name' => $_POST['model_name'],
        'system_prompt' => $_POST['system_prompt'],
        'temperature' => floatval($_POST['temperature']),
        'email_to' => $_POST['email_to'],
        'smtp_host' => $_POST['smtp_host'],
        'smtp_port' => intval($_POST['smtp_port']),
        'smtp_encryption' => $_POST['smtp_encryption'],
        'smtp_username' => $_POST['smtp_username'],
        'smtp_password' => $_POST['smtp_password'],
        'smtp_from_name' => $_POST['smtp_from_name']
    ];
    
    file_put_contents('ai_settings.json', json_encode($newSettings, JSON_PRETTY_PRINT));
    $message = "Ayarlar kaydedildi! (.env dosyasından gelen varsayılanlar JSON ile geçersiz kılındı)";
}

// Load settings from .env and JSON (JSON overrides .env)
$envDefaults = [
    'openrouter_key' => env('OPENROUTER_API_KEY', ''),
    'model_name' => env('AI_MODEL', 'anthropic/claude-3-sonnet'),
    'system_prompt' => env('SYSTEM_PROMPT', 'Sen bir astroloji uzmanısın. Verilen ephemeris verilerine ve tarihe göre kişiselleştirilmiş günlük burç yorumu yaz. Türkçe ve pozitif bir dille yaz.'),
    'temperature' => floatval(env('AI_TEMPERATURE', 0.7)),
    'email_to' => env('EMAIL_TO', ''),
    'smtp_host' => env('SMTP_HOST', 'smtp.gmail.com'),
    'smtp_port' => intval(env('SMTP_PORT', 587)),
    'smtp_encryption' => env('SMTP_ENCRYPTION', 'tls'),
    'smtp_username' => env('SMTP_USERNAME', ''),
    'smtp_password' => env('SMTP_PASSWORD', ''),
    'smtp_from_name' => env('SMTP_FROM_NAME', 'Astrolabe AI')
];

$settings = [];
if (file_exists('ai_settings.json')) {
    $settings = json_decode(file_get_contents('ai_settings.json'), true);
}
$settings = array_merge($envDefaults, $settings);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Astrolabe AI Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Play:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Play', sans-serif;
            background: radial-gradient(ellipse at bottom, #1b2735 0%, #090a0f 100%);
            min-height: 100vh;
        }
    </style>
</head>
<body class="text-white">
    <div class="container mx-auto p-8">
        <?php if (!$_SESSION['admin']): ?>
            <!-- Login Form -->
            <div class="max-w-md mx-auto mt-20">
                <div class="bg-slate-800/70 backdrop-blur-lg rounded-xl border border-slate-600/40 p-8">
                    <h1 class="text-2xl font-bold text-center mb-6">🔐 Admin Girişi</h1>
                    
                    <form method="POST">
                        <input type="hidden" name="action" value="login">
                        <div class="mb-4">
                            <label class="block text-sm font-medium mb-2">Şifre:</label>
                            <input type="password" name="password" 
                                   class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                   required>
                        </div>
                        <button type="submit" 
                                class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                            Giriş Yap
                        </button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <!-- Admin Panel -->
            <div class="max-w-4xl mx-auto">
                <div class="flex justify-between items-center mb-8">
                    <h1 class="text-3xl font-bold">🤖 Astrolabe AI Admin Panel</h1>
                    <form method="POST" class="inline">
                        <input type="hidden" name="action" value="logout">
                        <button type="submit" class="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg">
                            Çıkış
                        </button>
                    </form>
                </div>

                <?php if ($message): ?>
                    <div class="bg-green-600/20 border border-green-600/40 rounded-lg p-4 mb-6">
                        ✅ <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" class="space-y-6">
                    <input type="hidden" name="action" value="save_settings">
                    
                    <!-- OpenRouter Settings -->
                    <div class="bg-slate-800/70 backdrop-blur-lg rounded-xl border border-slate-600/40 p-6">
                        <h2 class="text-xl font-bold mb-4">🔑 OpenRouter API Ayarları</h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium mb-2">API Key:</label>
                                <input type="password" name="openrouter_key" 
                                       value="<?= htmlspecialchars($settings['openrouter_key']) ?>"
                                       class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
                                       placeholder="sk-or-v1-...">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium mb-2">Model:</label>
                                <input type="text" name="model_name" 
                                       value="<?= htmlspecialchars($settings['model_name']) ?>"
                                       class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
                                       placeholder="anthropic/claude-3-sonnet">
                                <div class="mt-1 text-xs text-gray-400">
                                    Örnekler: anthropic/claude-3-sonnet, openai/gpt-4o, google/gemini-pro-1.5
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <label class="block text-sm font-medium mb-2">Temperature (0.0 - 1.0):</label>
                            <input type="range" name="temperature" 
                                   min="0" max="1" step="0.1" 
                                   value="<?= $settings['temperature'] ?>"
                                   class="w-full" 
                                   oninput="this.nextElementSibling.value = this.value">
                            <output class="text-blue-400 font-mono"><?= $settings['temperature'] ?></output>
                        </div>
                    </div>

                    <!-- System Prompt -->
                    <div class="bg-slate-800/70 backdrop-blur-lg rounded-xl border border-slate-600/40 p-6">
                        <h2 class="text-xl font-bold mb-4">📝 System Prompt</h2>
                        <textarea name="system_prompt" rows="6" 
                                  class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500"
                                  placeholder="AI'nin nasıl davranacağını tanımlayın..."><?= htmlspecialchars($settings['system_prompt']) ?></textarea>
                    </div>

                    <!-- SMTP Email Settings -->
                    <div class="bg-slate-800/70 backdrop-blur-lg rounded-xl border border-slate-600/40 p-6">
                        <h2 class="text-xl font-bold mb-4">📧 SMTP Email Ayarları</h2>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label class="block text-sm font-medium mb-2">SMTP Host:</label>
                                <input type="text" name="smtp_host" 
                                       value="<?= htmlspecialchars($settings['smtp_host'] ?? 'smtp.gmail.com') ?>"
                                       class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium mb-2">Port:</label>
                                <input type="number" name="smtp_port" 
                                       value="<?= htmlspecialchars($settings['smtp_port'] ?? 587) ?>"
                                       class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <div>
                                <label class="block text-sm font-medium mb-2">Şifreleme:</label>
                                <select name="smtp_encryption" 
                                        class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500">
                                    <option value="tls" <?= ($settings['smtp_encryption'] ?? 'tls') == 'tls' ? 'selected' : '' ?>>TLS</option>
                                    <option value="ssl" <?= ($settings['smtp_encryption'] ?? 'tls') == 'ssl' ? 'selected' : '' ?>>SSL</option>
                                    <option value="" <?= ($settings['smtp_encryption'] ?? 'tls') == '' ? 'selected' : '' ?>>None</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium mb-2">Kullanıcı Adı:</label>
                                <input type="email" name="smtp_username" 
                                       value="<?= htmlspecialchars($settings['smtp_username'] ?? '') ?>"
                                       class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium mb-2">Şifre/App Password:</label>
                                <input type="password" name="smtp_password" 
                                       value="<?= htmlspecialchars($settings['smtp_password'] ?? '') ?>"
                                       class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium mb-2">Gönderici İsmi:</label>
                                <input type="text" name="smtp_from_name" 
                                       value="<?= htmlspecialchars($settings['smtp_from_name'] ?? 'Astrolabe AI') ?>"
                                       class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium mb-2">Alıcı Email:</label>
                                <input type="email" name="email_to" 
                                       value="<?= htmlspecialchars($settings['email_to']) ?>"
                                       class="w-full px-3 py-2 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>
                        
                        <div class="mt-4 p-3 bg-blue-900/30 border border-blue-600/40 rounded-lg">
                            <p class="text-sm text-blue-200">💡 <strong>Not:</strong> Gmail kullanıyorsanız, normal şifre yerine "App Password" oluşturun ve kullanın.</p>
                        </div>
                    </div>

                    <div class="text-center">
                        <button type="submit" 
                                class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-lg transition-colors">
                            💾 Ayarları Kaydet
                        </button>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>