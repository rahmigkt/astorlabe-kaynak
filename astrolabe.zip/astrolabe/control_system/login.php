<?php
session_start();
require_once 'includes/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (!empty($username) && !empty($password)) {
        $db = Database::getInstance();
        $result = $db->authenticateUser($username, $password);
        
        if ($result['authenticated']) {
            $_SESSION['authenticated'] = true;
            $_SESSION['username'] = $result['username'];
            $_SESSION['user_id'] = $result['id'];
            header('Location: control.php');
            exit();
        } else {
            $error = 'Invalid username or password';
        }
    } else {
        $error = 'Please enter both username and password';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Astrolabe Control Panel - Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Reem+Kufi:wght@400..700&display=swap">
    <style>
        body {
            background: #333333 !important;
            color: #e0e0e0;
            font-family: 'Reem Kufi', sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .login-container {
            background: #2a2a2a;
            border: 1px solid #444;
            border-radius: 10px;
            padding: 30px;
            width: 90%;
            max-width: 400px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-header h1 {
            color: #c1b158;
            font-size: 24px;
            margin: 0 0 10px 0;
        }
        
        .login-header p {
            color: #999;
            font-size: 14px;
            margin: 0;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            color: #e0e0e0;
            font-size: 14px;
            margin-bottom: 5px;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px;
            background: #1a1a1a;
            border: 1px solid #555;
            border-radius: 5px;
            color: #e0e0e0;
            font-size: 14px;
            box-sizing: border-box;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #c1b158;
            box-shadow: 0 0 5px rgba(193, 177, 88, 0.3);
        }
        
        .error-message {
            background: #4a1a1a;
            border: 1px solid #8a2a2a;
            color: #ffaaaa;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .login-button {
            width: 100%;
            padding: 12px;
            background: #c1b158;
            color: #1a1a1a;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        
        .login-button:hover {
            background: #d1c168;
        }
        
        .login-button:active {
            background: #b1a148;
        }
        
        .default-credentials {
            margin-top: 20px;
            padding: 15px;
            background: #1a1a1a;
            border: 1px solid #444;
            border-radius: 5px;
            font-size: 12px;
            color: #999;
        }
        
        .default-credentials strong {
            color: #c1b158;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>Astrolabe Control Panel</h1>
            <p>Please login to access the control system</p>
        </div>
        
        <?php if (!empty($error)): ?>
        <div class="error-message">
            <?php echo htmlspecialchars($error); ?>
        </div>
        <?php endif; ?>
        
        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required autofocus>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="login-button">Login</button>
        </form>
        

    </div>
</body>
</html>
