<?php
// Simulate the exact email sending process
header('Content-Type: application/json');

// Simulate input data
$input = [
    'horoscope_text' => 'Test burç yorumu. Bu bir deneme metnidir. ' . str_repeat('Lorem ipsum dolor sit amet. ', 50),
    'date' => 'Wed Sep 10 2025',
    'latitude' => 41,
    'recipient_email' => 'test@example.com',
    'screenshots' => null
];

// Generate PDF filename - save directly to downloads directory
$filename = 'burc_yorumu_' . date('Y-m-d_H-i-s') . '.html';
$downloadsDir = __DIR__ . '/downloads/';

// Ensure downloads directory exists
if (!file_exists($downloadsDir)) {
    mkdir($downloadsDir, 0755, true);
}

$pdfPath = $downloadsDir . $filename;

// Create PDF content (simple HTML)
$pdfContent = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Günlük Burç Yorumu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #4a5568;
            margin-bottom: 30px;
            padding-bottom: 20px;
        }
        .header h1 {
            color: #2d3748;
            margin: 0;
        }
        .date-info {
            background: #f7fafc;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #4299e1;
        }
        .horoscope-content {
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .footer {
            text-align: center;
            color: #718096;
            font-size: 12px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🌟 Günlük Burç Yorumu</h1>
        <p>Kişiselleştirilmiş Astrolojik Analiz</p>
    </div>
    
    <div class="date-info">
        <h3>📅 Tarih Bilgileri</h3>
        <p><strong>Tarih:</strong> ' . htmlspecialchars($input['date']) . '</p>
        <p><strong>Enlem:</strong> ' . htmlspecialchars($input['latitude']) . '°</p>
    </div>
    
    <div class="horoscope-content">
        <h3>🔮 AI Burç Yorumu</h3>
        ' . nl2br(htmlspecialchars($input['horoscope_text'])) . '
    </div>
    
    <div class="footer">
        <p>Bu yorum Astrolabe AI tarafından oluşturulmuştur.</p>
        <p>Tarih: ' . date('d.m.Y H:i:s') . '</p>
    </div>
</body>
</html>
';

// Write file
$writeResult = file_put_contents($pdfPath, $pdfContent);

// Prepare response
$downloadLink = null;
if ($writeResult !== false && file_exists($pdfPath)) {
    $downloadLink = $filename;
}

$response = [
    'success' => true,
    'message' => 'Burç yorumu başarıyla gönderildi!',
    'download_link' => $downloadLink,
    'debug' => [
        'filename' => $filename,
        'filepath' => $pdfPath,
        'bytes_written' => $writeResult,
        'file_exists' => file_exists($pdfPath),
        'file_size' => file_exists($pdfPath) ? filesize($pdfPath) : 0
    ]
];

echo json_encode($response, JSON_PRETTY_PRINT);
?>