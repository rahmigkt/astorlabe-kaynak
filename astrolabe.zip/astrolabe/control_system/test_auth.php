<?php
require_once 'includes/db.php';

echo "<h1>Authentication System Test</h1>";

try {
    $db = Database::getInstance();
    echo "<p>✅ Database connection successful</p>";
    
    // Test creating default admin
    $adminCreated = $db->createDefaultAdmin();
    if ($adminCreated) {
        echo "<p>✅ Default admin user created</p>";
    } else {
        echo "<p>ℹ️ Default admin user already exists</p>";
    }
    
    // Test authentication
    echo "<h2>Testing Authentication</h2>";
    
    // Test with correct credentials
    $result = $db->authenticateUser('admin', 'admin123');
    if ($result['authenticated']) {
        echo "<p>✅ Authentication with correct credentials: SUCCESS</p>";
        echo "<p>Username: " . htmlspecialchars($result['username']) . "</p>";
    } else {
        echo "<p>❌ Authentication with correct credentials: FAILED</p>";
    }
    
    // Test with incorrect credentials
    $result = $db->authenticateUser('admin', 'wrongpassword');
    if (!$result['authenticated']) {
        echo "<p>✅ Authentication with incorrect credentials: CORRECTLY REJECTED</p>";
    } else {
        echo "<p>❌ Authentication with incorrect credentials: INCORRECTLY ACCEPTED</p>";
    }
    
    // Test with non-existent user
    $result = $db->authenticateUser('nonexistent', 'password');
    if (!$result['authenticated']) {
        echo "<p>✅ Authentication with non-existent user: CORRECTLY REJECTED</p>";
    } else {
        echo "<p>❌ Authentication with non-existent user: INCORRECTLY ACCEPTED</p>";
    }
    
    echo "<h2>Database Tables</h2>";
    $conn = $db->getConnection();
    $tables = $conn->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);
    echo "<p>Available tables:</p><ul>";
    foreach ($tables as $table) {
        echo "<li>" . htmlspecialchars($table) . "</li>";
    }
    echo "</ul>";
    
    // Show credentials table contents
    if (in_array('credentials', $tables)) {
        echo "<h2>Credentials Table</h2>";
        $users = $conn->query("SELECT id, username, created_at, last_login, is_active FROM credentials")->fetchAll(PDO::FETCH_ASSOC);
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Username</th><th>Created</th><th>Last Login</th><th>Active</th></tr>";
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($user['id']) . "</td>";
            echo "<td>" . htmlspecialchars($user['username']) . "</td>";
            echo "<td>" . htmlspecialchars($user['created_at']) . "</td>";
            echo "<td>" . htmlspecialchars($user['last_login'] ?? 'Never') . "</td>";
            echo "<td>" . ($user['is_active'] ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "<hr>";
echo "<p><a href='login.php'>Go to Login Page</a> | <a href='control.php'>Go to Control Panel</a></p>";
?>
