<?php
// Fix database to work with API endpoints

$db = new PDO("sqlite:astrolabe.db");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Create the states table that API expects
echo "Creating states table...\n";
$db->exec("
    CREATE TABLE IF NOT EXISTS states (
        session_key TEXT PRIMARY KEY,
        state TEXT NOT NULL,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

echo "Table created successfully!\n";

// Insert test data
$testSession = 'default';
$testState = json_encode([
    'latitude' => 40,
    'longitude' => 0,
    'astrolabe_visible' => true,
    'star_chart_visible' => false,
    'local_year' => date('Y'),
    'local_month' => date('n'),
    'local_day' => date('j'),
    'local_hour' => date('G'),
    'local_minute' => date('i'),
    'local_second' => date('s'),
    'julian_day' => 2460563.5
]);

$stmt = $db->prepare("INSERT OR REPLACE INTO states (session_key, state, updated_at) VALUES (?, ?, datetime('now'))");
$stmt->execute([$testSession, $testState]);

echo "Test data inserted!\n";

// Verify
$verify = $db->query("SELECT * FROM states")->fetchAll(PDO::FETCH_ASSOC);
echo "Current states:\n";
foreach($verify as $state) {
    echo "Session: " . $state['session_key'] . "\n";
    $stateData = json_decode($state['state'], true);
    echo "Latitude: " . $stateData['latitude'] . "\n";
    echo "Longitude: " . $stateData['longitude'] . "\n";
    echo "Updated: " . $state['updated_at'] . "\n\n";
}
?>