<?php
// Simple test for PDF creation
$testContent = '<html><body><h1>Test PDF</h1><p>Bu bir test dosyasıdır.</p></body></html>';
$testFile = __DIR__ . '/downloads/test.html';

// Create downloads directory
if (!file_exists(__DIR__ . '/downloads/')) {
    mkdir(__DIR__ . '/downloads/', 0755, true);
}

// Write test file
$result = file_put_contents($testFile, $testContent);

if ($result) {
    echo json_encode([
        'success' => true,
        'message' => 'Test file created',
        'file_size' => $result,
        'file_path' => $testFile,
        'download_link' => 'test.html'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'error' => 'Failed to create test file'
    ]);
}
?>