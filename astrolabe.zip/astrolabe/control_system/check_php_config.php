<?php
echo "🔍 PHP Configuration Check\n";
echo "========================\n\n";

echo "📁 PHP.ini Location: " . php_ini_loaded_file() . "\n";
echo "🔧 PHP Version: " . phpversion() . "\n";
echo "💾 PHP SAPI: " . php_sapi_name() . "\n\n";

echo "🔌 Socket Extension Status:\n";
if (extension_loaded('sockets')) {
    echo "✅ Socket extension is LOADED\n";
} else {
    echo "❌ Socket extension is NOT LOADED\n";
}

echo "\n📋 All Loaded Extensions:\n";
$extensions = get_loaded_extensions();
sort($extensions);
foreach ($extensions as $ext) {
    if (strpos(strtolower($ext), 'socket') !== false) {
        echo "✅ $ext\n";
    }
}

echo "\n🔍 Looking for socket-related extensions:\n";
foreach ($extensions as $ext) {
    if (stripos($ext, 'socket') !== false || stripos($ext, 'stream') !== false) {
        echo "🔌 $ext\n";
    }
}

echo "\n📄 Additional PHP.ini files:\n";
$additional = php_ini_scanned_files();
if ($additional) {
    echo $additional . "\n";
} else {
    echo "None found.\n";
}
?>