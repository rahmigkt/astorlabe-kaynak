# 🔐 Astrolabe AI - Environment Setup

## 📋 Kurulum Adımları

### 1. Environment Dosyası Oluştur

```bash
cp .env.example .env
```

### 2. `.env` Dosyasını Düzenle

```env
# Astrolabe AI Configuration

# OpenRouter AI Settings
OPENROUTER_API_KEY=sk-or-v1-your-actual-api-key-here
AI_MODEL=anthropic/claude-3-sonnet
AI_TEMPERATURE=0.7
SYSTEM_PROMPT="Sen bir astroloji uzmanısın. Verilen ephemeris verilerine ve tarihe göre kişiselleştirilmiş günlük burç yorumu yaz. Türkçe ve pozitif bir dille yaz."

# SMTP Email Settings
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_ENCRYPTION=tls
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=your-gmail-app-password
SMTP_FROM_NAME="Astrolabe AI"

# Email Recipients
EMAIL_TO=recipient@example.com

# Admin Settings
ADMIN_PASSWORD=your-secure-admin-password

# Security
SECRET_KEY=your-random-secret-key-here
```

### 3. OpenRouter API Key Alma

1. [OpenRouter.ai](https://openrouter.ai) hesabı oluştur
2. API Keys bölümünden yeni key oluştur
3. Key'i `.env` dosyasındaki `OPENROUTER_API_KEY` alanına yapıştır

### 4. Gmail App Password Oluşturma

1. Gmail hesabınızda 2-Factor Authentication'ı aktif edin
2. Google Account → Security → App Passwords
3. "Mail" için yeni app password oluştur
4. Oluşan şifreyi `.env` dosyasındaki `SMTP_PASSWORD` alanına yazın

### 5. Test Et

1. `localhost:8081/admin.php` - Admin paneli açılacak
2. Şifre: `.env` dosyasındaki `ADMIN_PASSWORD`
3. Ayarları kontrol et ve kaydet
4. `localhost:8081/control.php` - AI burç yorumu butonunu test et

## 🔧 Yapılandırma Seçenekleri

### Desteklenen AI Modelleri
- `anthropic/claude-3-sonnet` (Önerilen)
- `anthropic/claude-3-haiku` (Daha hızlı)
- `openai/gpt-4o` 
- `openai/gpt-3.5-turbo`

### SMTP Providers
- **Gmail**: `smtp.gmail.com:587` (TLS)
- **Outlook**: `smtp-mail.outlook.com:587` (TLS)
- **Yahoo**: `smtp.mail.yahoo.com:587` (TLS)

### Temperature Ayarı
- `0.0` - Deterministik, tutarlı
- `0.7` - Dengeli (Önerilen)
- `1.0` - Yaratıcı, değişken

## 🔄 Ayar Yönetimi

### Öncelik Sırası
1. **Admin Panel** - JSON dosyası (.env'i geçersiz kılar)
2. **`.env` Dosyası** - Varsayılan ayarlar
3. **Kod İçi** - Son çare varsayılanlar

### Ayarları Sıfırlama
```bash
rm ai_settings.json  # Admin panelindeki ayarları sil
# .env dosyası varsayılan olarak kullanılır
```

## 🛡️ Güvenlik

### Önemli Notlar
- `.env` dosyası git'e eklenmez (`.gitignore`'da)
- API key'leri ve şifreleri asla paylaşmayın
- `ADMIN_PASSWORD`'ı güçlü yapın
- `SECRET_KEY`'i rastgele oluşturun

### .gitignore Kontrolü
```bash
# Bu dosyalar asla git'e eklenmesin:
.env
ai_settings.json
vendor/
```

## 🚀 Production Deployment

1. **SSL/HTTPS** kullanın
2. **Güçlü şifreler** belirleyin
3. **API key'leri** düzenli olarak yenileyin
4. **Log dosyalarını** izleyin

## 🐛 Troubleshooting

### "API key yapılandırılmamış" Hatası
- `.env` dosyası var mı?
- `OPENROUTER_API_KEY` doğru mu?
- Dosya izinleri OK mi?

### "SMTP ayarları yapılandırılmamış" Hatası
- Gmail app password oluşturdunuz mu?
- SMTP ayarları doğru mu?
- 2FA aktif mi?

### Email Gönderilmiyor
- Gmail: App password kullanın
- Firewall: 587 portunu kontrol edin
- Test: Basit SMTP client ile deneyin

## 📞 Destek

1. `.env.example`'ı referans alın
2. Admin panelinde ayarları kontrol edin
3. Hata loglarını inceleyin
4. SMTP test araçlarını kullanın