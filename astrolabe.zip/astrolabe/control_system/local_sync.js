/**
 * 🚀 Ultra-Fast Local P2P Sync System
 * Direct browser-to-browser communication for same-device instances
 */

class LocalAstrolabeSync {
    constructor(clientType = 'unknown') {
        this.clientType = clientType;
        this.peers = new Map();
        this.isHost = false;
        this.hostChannel = null;
        this.broadcastChannel = null;
        this.webrtcConnections = new Map();
        this.callbacks = new Map();
        
        this.initLocalSync();
    }
    
    initLocalSync() {
        console.log(`🔗 Initializing Local P2P Sync as ${this.clientType}`);
        
        // Only use BroadcastChannel - fastest method
        this.initBroadcastChannel();
    }
    
    // 🚀 Method 1: BroadcastChannel (FASTEST - same-origin only)
    initBroadcastChannel() {
        if (!window.BroadcastChannel) {
            console.log('❌ BroadcastChannel not supported');
            return;
        }
        
        this.broadcastChannel = new BroadcastChannel('astrolabe-sync');
        
        this.broadcastChannel.onmessage = (event) => {
            const { type, data, from, timestamp } = event.data;
            
            // Ignore own messages
            if (from === this.clientType) return;
            
            console.log(`📨 BroadcastChannel received from ${from}:`, type);
            
            switch (type) {
                case 'peer_discovery':
                    this.handlePeerDiscovery(data, from);
                    break;
                case 'astrolabe_sync':
                    this.handleAstrolabeSync(data, from);
                    break;
                case 'ping':
                    this.sendBroadcast('pong', { timestamp: Date.now() }, from);
                    break;
                case 'request_screenshot':
                    // Trigger screenshot request callback
                    if (this.callbacks.has('request_screenshot')) {
                        this.callbacks.get('request_screenshot')(data);
                    }
                    break;
                case 'screenshot_capture':
                    // Handle received screenshots
                    if (this.callbacks.has('screenshot_capture')) {
                        this.callbacks.get('screenshot_capture')(data);
                    }
                    break;
            }
        };
        
        // Announce presence
        this.sendBroadcast('peer_discovery', {
            clientType: this.clientType,
            timestamp: Date.now()
        });
        
        console.log('✅ BroadcastChannel initialized');
    }
    
    sendBroadcast(type, data, target = null) {
        if (!this.broadcastChannel) return;
        
        const message = {
            type,
            data,
            from: this.clientType,
            target,
            timestamp: Date.now()
        };
        
        this.broadcastChannel.postMessage(message);
        console.log(`📤 BroadcastChannel sent: ${type}`);
    }
    
    // 🔍 Method 2: Local peer detection
    detectLocalPeers() {
        // Try to connect to different ports/endpoints
        const possiblePorts = [8080, 8081, 3000, 9090];
        
        possiblePorts.forEach(port => {
            if (port === window.location.port) return; // Skip own port
            
            try {
                const ws = new WebSocket(`ws://localhost:${port}`);
                
                ws.onopen = () => {
                    console.log(`🔗 Found peer WebSocket on port ${port}`);
                    this.peers.set(port, ws);
                    
                    ws.send(JSON.stringify({
                        type: 'peer_handshake',
                        from: this.clientType,
                        timestamp: Date.now()
                    }));
                };
                
                ws.onmessage = (event) => {
                    const message = JSON.parse(event.data);
                    this.handlePeerMessage(message, port);
                };
                
                ws.onclose = () => {
                    this.peers.delete(port);
                };
                
            } catch (error) {
                console.log(`❌ Port ${port} not available`);
            }
        });
    }
    
    // 🔄 Method 3: LocalStorage sync (fallback)
    initLocalStorageSync() {
        const STORAGE_KEY = 'astrolabe-sync-data';
        const LAST_UPDATE_KEY = 'astrolabe-last-update';
        
        // Listen for storage changes from other tabs/windows
        window.addEventListener('storage', (event) => {
            if (event.key === STORAGE_KEY && event.newValue) {
                const data = JSON.parse(event.newValue);
                const lastUpdate = localStorage.getItem(LAST_UPDATE_KEY);
                
                // Only process if it's newer than our last update
                if (!lastUpdate || data.timestamp > parseInt(lastUpdate)) {
                    console.log('📨 LocalStorage sync received:', data);
                    this.handleAstrolabeSync(data.payload, data.from);
                }
            }
        });
        
        console.log('✅ LocalStorage sync initialized');
    }
    
    // 📤 Send sync data (tries all methods)
    syncData(data) {
        const syncPayload = {
            ...data,
            timestamp: Date.now(),
            from: this.clientType
        };
        
        console.log('⚡ Ultra-fast P2P sync via BroadcastChannel:', syncPayload);
        
        // Ultra-fast BroadcastChannel sync (< 1ms latency)
        this.sendBroadcast('astrolabe_sync', syncPayload);
    }
    
    // 📨 Handle incoming sync data
    handleAstrolabeSync(data, from) {
        console.log(`⚡ Local sync received from ${from}:`, data);
        
        // Call registered callbacks
        this.callbacks.forEach((callback, eventType) => {
            if (eventType === 'astrolabe_update') {
                callback(data);
            }
        });
    }
    
    handlePeerDiscovery(data, from) {
        console.log(`👋 Peer discovered: ${from}`, data);
        // Could implement peer list UI here
    }
    
    handlePeerMessage(message, port) {
        console.log(`📨 Peer message from port ${port}:`, message);
        
        switch (message.type) {
            case 'peer_handshake':
                console.log(`🤝 Handshake from ${message.from} on port ${port}`);
                break;
            case 'astrolabe_sync':
                this.handleAstrolabeSync(message.data, message.from);
                break;
        }
    }
    
    
    // 🎯 Event registration
    on(eventType, callback) {
        this.callbacks.set(eventType, callback);
    }
    
    off(eventType) {
        this.callbacks.delete(eventType);
    }
    
    // 🔌 Connection status
    getConnectionStatus() {
        return {
            broadcastChannel: !!this.broadcastChannel,
            ultraFastMode: true,
            latency: '< 1ms',
            method: 'BroadcastChannel P2P'
        };
    }
    
    // Event listener registration
    on(eventName, callback) {
        this.callbacks.set(eventName, callback);
        console.log(`📢 Registered listener for: ${eventName}`);
    }
    
    // Remove event listener
    off(eventName) {
        this.callbacks.delete(eventName);
        console.log(`🔕 Removed listener for: ${eventName}`);
    }
    
    // 🧹 Cleanup
    destroy() {
        if (this.broadcastChannel) {
            this.broadcastChannel.close();
        }
        this.callbacks.clear();
    }
}

// 🌟 Global instance
window.LocalAstrolabeSync = LocalAstrolabeSync;