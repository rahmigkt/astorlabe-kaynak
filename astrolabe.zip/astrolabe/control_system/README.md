# Astrolabe Control Panel System

## Overview
Two-screen synchronized system for controlling the astrolabe projection:
- **Control Panel** (control.php) - Tablet interface for controlling settings
- **Projection Display** (display.php) - TV/projector display showing the astrolabe
- **SQLite Database** - No installation required, automatic setup!

## 🚀 Quick Start

**No database server required!** Uses SQLite (file-based database).

1. **Test the system:**
   ```
   http://localhost/astrolabe/control_system/test_sqlite.php
   ```

2. **Open Control Panel (tablet):**
   ```
   http://localhost/astrolabe/control_system/control.php
   ```

3. **Open Display (TV/projector):**
   ```
   http://localhost/astrolabe/control_system/display.php
   ```

That's it! The database will be created automatically on first run.

## System Architecture

```
┌─────────────┐     SQLite DB     ┌──────────────┐
│   Control   │ ──────────────>   │  Projection  │
│    Panel    │     (writes)       │   Display    │
│ control.php │   astrolabe.db     │ display.php  │
└─────────────┘     <──────────    └──────────────┘
                     (reads)
```

## File Structure

```
/astrolabe/
├── control_system/           # Control panel system (isolated)
│   ├── api/                  # API endpoints
│   │   ├── get_state.php     # Read current state
│   │   ├── update_state.php  # Update state
│   │   └── get_presets.php   # Get location presets
│   ├── includes/             # Shared modules
│   │   ├── config.php        # Configuration
│   │   ├── db.php           # Database class (SQLite)
│   │   ├── common.js        # Shared JavaScript
│   │   ├── display_head.php # Display head includes
│   │   └── astrolabe_structure.php # HTML structure
│   ├── control.php          # Control panel interface
│   ├── display.php         # Projection display
│   ├── test_sqlite.php     # Database test script
│   └── README.md           # This file
├── data/                    # Database directory (auto-created)
│   └── astrolabe.db        # SQLite database file
├── index.html              # Original astrolabe interface
├── star_chart.js           # Enhanced with draggable horizon mask
└── ...                     # Other original astrolabe files
```

## Features

### Control Panel
- **Location Control**: Latitude/longitude sliders with presets
- **Date/Time Control**: Full date and time adjustment
- **Display Settings**: Toggle components and visual options
- **Real-time Sync**: Automatic database synchronization
- **Location Presets**: Istanbul, New York, London, Tokyo, and more

### Projection Display
- **Auto-sync**: Polls for updates every 500ms
- **Fullscreen Mode**: Press F11 for fullscreen
- **Connection Status**: Visual indicator for sync status
- **Clean Display**: No controls visible, only projection

### Horizon Mask Feature
- **Draggable Mask**: Drag the horizon mask in star chart to change latitude/longitude
- **Real-time Update**: Changes reflect immediately in both control panel and display
- **Touch Support**: Works on tablets and touch devices

## Technical Details

### SQLite Database Benefits
✅ **No Installation**: Works out of the box  
✅ **Portable**: Single file database  
✅ **Fast**: Perfect for single/few users  
✅ **Lightweight**: Minimal resource usage  
✅ **Self-contained**: No server processes  

### Database Tables
- `sessions`: Multi-user session support
- `control_states`: Current state for each session
- `location_presets`: Pre-defined locations (auto-populated)

### Synchronization
- Control panel writes to SQLite database
- Display polls database for changes
- 500ms update interval (configurable)
- Session-based isolation
- Automatic database creation on first use

### Isolation Benefits
✅ **Clean Separation**: Control system isolated from main project  
✅ **No Interference**: Original index.html remains unchanged  
✅ **Modular**: Can be deployed separately  
✅ **Maintainable**: Easy to update without affecting original code  

## Customization

### Change Update Interval
Edit `includes/config.php`:
```php
define('UPDATE_INTERVAL', 500); // milliseconds
```

### Database Location
Edit `includes/config.php`:
```php
define('DB_FILE', __DIR__ . '/../../data/astrolabe.db');
```

### Add Location Presets
Edit `includes/db.php` in the `insertDefaultData()` function:
```php
$presets = [
    ['City Name', latitude, longitude, 'Timezone'],
    // Add more...
];
```

### Modify Controls
1. Edit `control.php` to add new controls
2. Update `api/update_state.php` to handle new fields
3. Add fields to database schema in `db.php`

## Troubleshooting

### Database Issues
- **Location**: Database file is at `../data/astrolabe.db`
- **Permissions**: Ensure `data/` directory is writable
- **Reset**: Delete `data/astrolabe.db` to reset everything

### Sync Not Working
- Check browser console for errors
- Verify same session key in localStorage
- Check network tab for API calls
- Run `test_sqlite.php` to verify database

### Path Issues
- All paths are relative to control_system directory
- Original astrolabe files accessed via `../` prefix
- CSS/JS files: `../../filename.js`

## Browser Support
- Chrome/Edge: Full support
- Firefox: Full support
- Safari: Full support
- Mobile browsers: Touch support included

## Requirements
- PHP 7.0+ with SQLite3 extension (usually included)
- Web server (Apache, Nginx, or PHP built-in server)
- Modern web browser

## Development Tips
- Database viewer: Use [DB Browser for SQLite](https://sqlitebrowser.org/)
- Session testing: Use different browsers for control/display
- Debug mode: Check PHP error logs for issues
- File paths: All relative to control_system/ directory

## Security Notes
- Session keys are randomly generated
- No sensitive data stored
- For production: Add authentication if needed
- Consider HTTPS for network deployments