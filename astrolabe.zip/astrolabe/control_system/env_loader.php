<?php
/**
 * Simple .env file loader
 * Loads environment variables from .env file
 */
class EnvLoader {
    private static $loaded = false;
    private static $vars = [];
    
    public static function load($path = null) {
        if (self::$loaded) {
            return;
        }
        
        if ($path === null) {
            $path = __DIR__ . '/.env';
        }
        
        if (!file_exists($path)) {
            // Try to create .env from .env.example if it doesn't exist
            $examplePath = __DIR__ . '/.env.example';
            if (file_exists($examplePath)) {
                copy($examplePath, $path);
                error_log("Created .env file from .env.example. Please update it with your actual values.");
            }
            return;
        }
        
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        foreach ($lines as $line) {
            // Skip comments
            if (strpos(trim($line), '#') === 0) {
                continue;
            }
            
            // Parse key=value pairs
            if (strpos($line, '=') !== false) {
                list($key, $value) = explode('=', $line, 2);
                $key = trim($key);
                $value = trim($value);
                
                // Remove quotes if present
                if (preg_match('/^"(.*)"$/', $value, $matches)) {
                    $value = $matches[1];
                } elseif (preg_match("/^'(.*)'$/", $value, $matches)) {
                    $value = $matches[1];
                }
                
                // Set environment variable
                $_ENV[$key] = $value;
                putenv("$key=$value");
                self::$vars[$key] = $value;
            }
        }
        
        self::$loaded = true;
    }
    
    public static function get($key, $default = null) {
        self::load();
        
        // Check $_ENV first, then our loaded vars, then default
        if (isset($_ENV[$key])) {
            return $_ENV[$key];
        }
        
        if (isset(self::$vars[$key])) {
            return self::$vars[$key];
        }
        
        return $default;
    }
    
    public static function getAll() {
        self::load();
        return self::$vars;
    }
    
    public static function isLoaded() {
        return self::$loaded;
    }
}

// Helper function
function env($key, $default = null) {
    return EnvLoader::get($key, $default);
}

// Auto-load on include
EnvLoader::load();
?>