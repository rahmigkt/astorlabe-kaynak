<?php
header('Content-Type: text/html; charset=UTF-8');
header('Access-Control-Allow-Origin: *');

// Get language parameter (default to Turkish)
$language = isset($_GET['lang']) ? $_GET['lang'] : 'turkish';

// Map language to folder
$languageFolder = '';
switch($language) {
    case 'arabic':
        $languageFolder = '../differences_output/arapca_farkli';
        break;
    case 'turkish':
        $languageFolder = '../differences_output/turkce_farkli';
        break;
    case 'latin':
        $languageFolder = '../differences_output/latince_farkli';
        break;
    default:
        $languageFolder = '../differences_output/turkce_farkli';
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            margin: 0;
            padding: 0;
            background: transparent;
            overflow: hidden;
        }
        
        /* Original index.html styles without Tailwind */
        #astrolabe-wrapper {
            width: 100%;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .svgx {
            max-width: 100%;
            max-height: 100%;
        }
        
        /* Text styles from index.html */
        svg text {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 4px;
            font-weight: normal;
            fill: rgb(95,85,75);
            stroke: none;
            text-anchor: middle;
            dominant-baseline: middle;
        }
        
        #wheel_textgroup text {
            font-family: monospace;
            font-size: 3px;
        }
        
        /* Rule/Index styling */
        #ruleGroup {
            stroke: rgb(105,85,60);
            stroke-width: 0.25;
            fill: rgb(240,220,115);
        }
        
        /* Hide visibility classes */
        .hidden { visibility: hidden; }
        .visible { visibility: visible; }
    </style>
    
    <!-- Load required scripts -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script>
        // Mock jQuery mobile functions if needed
        if (!$.fn.flipswitch) {
            $.fn.flipswitch = function() { return this; };
        }
        
        // Define required globals
        window.xmlns = "http://www.w3.org/2000/svg";
        window.obliquity = 23.4;
        window.e0 = 23.4;
        window.i0 = 23.4;
        window.Rcapricorn = 87;
        window.Recliptic = 87;
        window.obliquity = 23.4;
    </script>
</head>
<body>
    <div id="astrolabe-wrapper">
        <svg id="svg_astrolabe" class="svgx" viewBox="0 -30 210 240" style="z-index: 999; position: relative; overflow: visible;">
            <defs>
                <linearGradient id="brass"/>
                <radialGradient id="twilight"/>
            </defs>
            
            <!-- Head group -->
            <g id="headGroup" fill="none" stroke="none" transform="matrix(1,0,0,-1,105,105) rotate(0)">
                <!-- Head SVG content will be loaded here -->
            </g>
            
            <!-- Mater group -->
            <g id="mater_group" fill="none" stroke="none" transform="matrix(1,0,0,-1,105,105)">   
                <circle id="mater" cx="0" cy="0" r="0"/>
                <path id="limb" d=""/>
                <g id="limb_markings_group"/>
                <circle id="tropicOfCapricorn" cx="0" cy="0" r="0"/>
                <circle id="equator" cx="0" cy="0" r="0"/>
                <circle id="tropicOfCancer" cx="0" cy="0" r="0"/>
                <g id="azimuth_group"/>
                <g id="almucantars_group"/>
                <g id="nocturnalGroup" visibility="hidden"/>
            </g>
            
            <!-- Upper layer -->
            <g id="upperlayer" fill="none" stroke="none" transform="matrix(1,0,0,-1,105,105)">
                <g id="reteLayer" transform="rotate(0)">
                    <g id="reteGroup_default" class="rete_group active_rete">
                        <g id="retebrassGroup" class="rete">
                            <path id="capella" d=""/>
                            <path id="retePath"/>
                            <g id="reteMarks"/>
                            <g id="starnames_textgroup"/>
                            <g id="starpointer_group" transform="rotate(-270)" fill-rule="evenodd"/>
                        </g>
                        <g id="eclipticGroup" class="ecliptic">
                            <path id="ecliptic" d=""/>
                            <g id="eclipticMarks" class="ecliptic_marks"/>
                        </g>
                    </g>
                </g>
                
                <g id="ruleGroup"/>
                
                <g id="planetsGroup">
                    <g id="sunGroup"/>
                    <g id="moonGroup"/>
                </g>
            </g>
        </svg>
    </div>
    
    <!-- Load language-specific scripts -->
    <script src="<?php echo $languageFolder; ?>/tympanum.js"></script>
    <script src="<?php echo $languageFolder; ?>/rete.js"></script>
    
    <script>
        // Initialize astrolabe
        document.addEventListener('DOMContentLoaded', function() {
            // Call drawing functions if they exist
            if (typeof draw_tympanum === 'function') {
                draw_tympanum();
            } else if (typeof tympanum === 'function') {
                tympanum();
            }
            
            if (typeof draw_rete === 'function') {
                draw_rete();
            } else if (typeof rete === 'function') {
                rete();
            }
            
            if (typeof rule === 'function' && document.getElementById('ruleGroup')) {
                rule();
            }
            
            // Load head SVG
            loadHeadSvg('<?php echo $language; ?>');
        });
        
        // Function to load head SVG
        function loadHeadSvg(language) {
            const languageFolder = '<?php echo $languageFolder; ?>';
            const headSvgPath = languageFolder + '/head.svg';
            
            const headGroup = document.getElementById('headGroup');
            if (!headGroup) return;
            
            fetch(headSvgPath)
                .then(response => response.text())
                .then(svgContent => {
                    const parser = new DOMParser();
                    const svgDoc = parser.parseFromString(svgContent, 'image/svg+xml');
                    const svgElement = svgDoc.querySelector('svg');
                    
                    if (svgElement) {
                        const viewBox = svgElement.getAttribute('viewBox');
                        if (viewBox) {
                            const [minX, minY, width, height] = viewBox.split(' ').map(Number);
                            
                            const g = svgElement.querySelector('g') || svgElement;
                            const scaleFactor = language === 'arabic' ? 0.2 : 0.008;
                            const yOffset = language === 'arabic' ? 30 : 107;
                            
                            const clonedGroup = g.cloneNode(true);
                            const currentTransform = clonedGroup.getAttribute('transform') || '';
                            clonedGroup.setAttribute('transform', 
                                `translate(0, ${yOffset}) scale(${scaleFactor}) rotate(180) translate(${-width/2}, ${-height/2}) ${currentTransform}`);
                            
                            headGroup.appendChild(clonedGroup);
                        }
                    }
                })
                .catch(error => console.error('Error loading head SVG:', error));
        }
    </script>
</body>
</html>