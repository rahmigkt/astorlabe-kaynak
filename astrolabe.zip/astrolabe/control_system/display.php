<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İnteraktif Yıldız Haritası - Görüntü</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Play:wght@400;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Reem+Kufi:wght@400..700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=IM+Fell+English&display=swap" rel="stylesheet">
    <style>
        @keyframes backgroundPan { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        body {
            font-family: 'Roboto', sans-serif;
            background: radial-gradient(ellipse at bottom, #1b2735 0%, #090a0f 100%);
            color: #e5e7eb;
            overflow: hidden;
            background-size: 250% 250%;
            animation: backgroundPan 45s linear infinite;
            touch-action: none;
        }
        /* Maximum size circles */
        .planisphere-container { 
            width: calc(100vh - 120px); 
            height: calc(100vh - 120px); 
            max-width: calc(100vh - 120px); 
            max-height: calc(100vh - 120px); 
            position: relative; 
            flex-shrink: 0; 
        }
        
        /* Main container layout */
        .main-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100vw;
            height: 100vh;
        }
        
        /* Circle container */
        .circle-container {
            display: flex;
            align-items: center;
            justify-content: center;
            flex: 1;
            width: 100%;
            margin-bottom: 10px;
        }
        
        /* Ephemeris table styles */
        #ephemerisTableLeft, #ephemerisTableRight {
            display: table;
            margin: auto;
            font-size: 10px;
            color: #e0e0e0;
        }
        
        #ephemerisTableLeft td, #ephemerisTableRight td {
            border: none;
            color: #e0e0e0;
            padding: 2px 3px;
            vertical-align: middle;
            white-space: nowrap;
            font-size: 10px;
        }
        
        .graycell {
            background: rgba(50, 50, 60, 0.5);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .zsign_eph {
            text-align: right;
            width: .8em;
            color: #ffaaaa;
        }
        
        .housedigit {
            color: #ffd700;
            font-weight: bold;
        }
        
        /* Bottom sections layout */
        .bottom-sections {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            gap: 30px;
            padding: 5px 20px 10px 20px;
            width: 100%;
        }
        
        .ephemeris-left, .ephemeris-right {
            flex: 0 0 auto;
        }
        
        .calendar-center {
            flex: 0 0 auto;
            text-align: center;
            min-width: 200px;
            margin-top: 22px; /* Align with Saturn row (skip header) */
        }
        
        .date-row {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            color: #e0e0e0;
            font-size: 10px;
            height: 18px; /* Match ephemeris table row height */
            line-height: 18px;
            font-family: 'Play', sans-serif;
        }
        
        .date-group {
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .date-label {
            color: #999;
            font-size: 10px;
        }
        
        .date-value {
            color: #e0e0e0;
            font-size: 10px;
            font-weight: bold;
        }
        
        .divider {
            color: #666;
        }
        svg text { font-family: 'Play', sans-serif; fill: #d1d5db; font-size: 1.5vmin; text-anchor: middle; dominant-baseline: middle; }
        .constellation-line { stroke: #87CEFA; stroke-opacity: 0.8; stroke-width: 2; filter: drop-shadow(0 0 2px #87CEFA); }
        .constellation-name, .star-name-label, .planet-label, .dso-label { transition: opacity 0.3s; }
        .constellation-name { fill: #a7c7e7; font-size: 14px; font-weight: bold; opacity: 0.8; paint-order: stroke; stroke: #0a0a0a; stroke-width: 4px; }
        .star-name-label { font-size: 10px; fill: #9ca3af; }
        .dso-label { font-size: 12px; fill: #a7c7e7; font-style: italic; }
        .star-glow-strong { filter: drop-shadow(0 0 6px #ffffff) drop-shadow(0 0 3px #66ccff); }
        .star-glow-medium { filter: drop-shadow(0 0 3px #ffffff) drop-shadow(0 0 1.5px #66ccff); }
        #ecliptic-path { stroke: #ffcc00; stroke-width: 1.5; stroke-dasharray: 10 5; opacity: 0.5; fill: none; }
        .planet { filter: drop-shadow(0 0 8px currentColor) drop-shadow(0 0 4px currentColor); }
        .planet-label { font-size: 12px; font-weight: bold; fill: currentColor; text-shadow: 0 0 3px black, 0 0 5px black; }
        .month-text { font-family: 'Play', sans-serif; fill: rgba(252, 165, 165, 0.9); }
        .day-text { font-family: 'Play', sans-serif; fill: rgba(252, 165, 165, 0.8); }
        .day-tick { stroke: rgba(252, 165, 165, 0.7); }
        .time-text { fill: #d8b4fe; stroke: #d8b4fe; font-family: 'Play', sans-serif; }
        .direction-text { paint-order: stroke; stroke: #0a0a0a; stroke-width: 6px; font-weight: bold; }
        #horizon-group { transition: transform 0.5s ease-in-out; }
        
        /* Astrolabe styles - using same size as star chart */
        .astrolabe-container svg {
            width: 100%;
            height: 100%;
        }
        
        /* Override text styling within astrolabe SVGs */
        .astrolabe-container svg text {
            font-family: Arial, Helvetica, sans-serif !important;
            font-size: 4px !important;
            font-weight: normal !important;
            fill: rgb(95,85,75) !important;
            stroke: none !important;
            text-anchor: middle !important;
            dominant-baseline: middle !important;
        }
        
        /* Wheel text should be monospace */
        .astrolabe-container #wheel_textgroup text {
            font-family: monospace !important;
            font-size: 3px !important;
        }
        
        /* Hide star names in astrolabe - they look broken */
        .astrolabe-container #starnames_textgroup text {
            display: none !important;
        }
        
        /* Hide text on rule group (ruler/index) */
        .astrolabe-container #ruleGroup text {
            visibility: hidden !important;
        }
        
        /* Sky element - fill removed */
        .astrolabe-container #sky {
            /* fill removed */
        }
        
        /* Connection Status Icon */
        #connection-status {
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 1000;
            display: flex;
            align-items: center;
            padding: 6px 12px;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            font-family: 'Play', sans-serif;
            font-size: 11px;
            color: white;
        }
        
        #status-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 6px;
            transition: all 0.3s ease;
        }
        
        .status-p2p {
            background: #22c55e;
            box-shadow: 0 0 6px #22c55e;
            animation: pulse 2s infinite;
        }
        
        .status-http {
            background: #f59e0b;
            box-shadow: 0 0 6px #f59e0b;
            animation: pulse 2s infinite;
        }
        
        .status-disconnected {
            background: #ef4444;
            box-shadow: 0 0 6px #ef4444;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        /* Interaction datetime display */
        #interaction-datetime-display {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1000;
            background: rgba(10, 10, 20, 0.85);
            backdrop-filter: blur(10px);
            padding: 1.5rem 2rem;
            border-radius: 1rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            font-family: 'Play', sans-serif;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.4s ease-in-out;
            text-align: center;
            color: #ffffff;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
        }
        
        #interaction-datetime-display.active {
            opacity: 1;
        }
        
        #interaction-date {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        
        #interaction-time {
            font-size: 1.2rem;
            opacity: 0.9;
        }
        
    </style>
</head>
<body>
    <!-- Connection Status Indicator -->
    <div id="connection-status">
        <div id="status-indicator" class="status-disconnected"></div>
        <span id="status-text">Bağlantı Kuriliyor...</span>
    </div>
    
    <!-- Interaction DateTime Display -->
    <div id="interaction-datetime-display">
        <div id="interaction-date"></div>
        <div id="interaction-time"></div>
    </div>
    
    <!-- Main Container -->
    <div class="main-container">
        <!-- Circle Container -->
        <div class="circle-container">
            <!-- Star Chart Container -->
            <div class="star-chart-container planisphere-container flex items-center justify-center" style="display: block;">
            <div id="planisphere" class="flex items-center justify-center">
            <svg id="planisphere-svg" width="100%" height="100%" viewBox="0 0 1000 1000">
                <g id="rings-group"></g>
                <g id="star-map-group">
                    <defs> 
                        <clipPath id="starClip"><circle cx="500" cy="500" r="400" /></clipPath> 
                        <radialGradient id="galaxy-gradient">
                            <stop offset="0%" stop-color="white" stop-opacity="0.3"/>
                            <stop offset="60%" stop-color="white" stop-opacity="0.1"/>
                            <stop offset="100%" stop-color="white" stop-opacity="0.0"/>
                        </radialGradient>
                    </defs>
                    <g clip-path="url(#starClip)">
                        <g id="background-stars-container"></g>
                        <g id="deep-sky-objects-container"></g>
                        <g id="ecliptic-container"></g>
                        <g id="constellation-lines-container"></g>
                        <g id="constellations-stars-and-names-container"></g>
                        <g id="planets-container"></g>
                    </g>
                </g>
                <g id="horizon-group">
                     <g id="time-ring-container"></g>
                     <path id="occluder" fill="#0a0a0a" fill-opacity="0.9" />
                     <text class="direction-text" x="500" y="120" font-size="20" fill="#ef4444">KUZEY</text>
                     <text class="direction-text" x="500" y="880" font-size="16" fill="#f97316">GÜNEY</text>
                     <text class="direction-text" x="120" y="500" font-size="16" fill="#f97316" transform="rotate(-90 120 500)">DOĞU</text>
                     <text class="direction-text" x="880" y="500" font-size="16" fill="#f97316" transform="rotate(90 880 500)">BATI</text>
                </g>
            </svg>
            </div>
        </div>
        
        <!-- Astrolabe Container -->
        <div class="astrolabe-container planisphere-container flex items-center justify-center" style="display: none;">
            <svg id="svg_astrolabe" class="svgx" viewBox="0 -30 210 240" width="100%" height="100%" style="z-index: 999; position: relative; overflow: visible;">
              <defs>
                <linearGradient id="brass"/>
                <radialGradient id="twilight"/>
                <radialGradient id="starglow"/>
                <radialGradient id="sunGrad"/>
                <radialGradient id="moonGrad"/>
                <radialGradient id="mercuryGrad"/>
                <radialGradient id="venusGrad"/>
                <radialGradient id="marsGrad"/>
                <radialGradient id="jupiterGrad"/>
                <radialGradient id="saturnGrad"/>
                <clipPath id="skyClip">
                  <path id="skyClipPath" d=""/>
                </clipPath>
                <clipPath id="belowHorizonClip">
                  <path id="belowHorizonClipPath" d=""/>
                </clipPath>
                <clipPath id="CapricornClip">
                  <circle id = "CapricornClipCircle" cx = "0" cy = "0" r = "0"/>
                </clipPath>
              </defs>
              
              <!-- Head group -->
              <g id="headGroup" fill="none" stroke="none" transform="matrix(1,0,0,-1,105,105) rotate(0)">
                <!-- Head SVG content will be loaded here -->
              </g>
              
              <!-- Mater group with ALL required sub-elements -->
              <g id="mater_group" fill="none" stroke="none" transform="matrix(1,0,0,-1,105,105)">   
                <circle id = "mater" cx = "0" cy = "0" r = "0"/>
                <path id = "limb" d = ""/>
                <g id="limb_markings_group"/>
                <circle id = "tropicOfCapricorn" cx = "0" cy = "0" r = "0"/>
                <path id = "south_out" d = ""/>
                <path id = "north_out" d = ""/>
                <path id = "east_out" d = ""/>
                <path id = "west_out" d = ""/>
                <path id = "eq_out" d = ""/>
                <path id = "cancer_out" d = ""/>
                <path id = "sky" d = "" />
                <circle id = "halo" cx = "0" cy = "0" r = "0"/>
                
                <g id = "skyGroup">
                  <path id = "east_in" d = ""/>
                  <path id = "west_in" d = ""/>
                  <path id = "eq_in1" d = ""/>
                  <path id = "eq_in2" d = ""/>
                  <path id = "cancer_in1" d = ""/>
                  <path id = "cancer_in2" d = ""/>
                  <g id = "altitudeGroup" /> 
                  <g id = "azimuthGroup">  
                    <path id = "south_in" d = ""/>
                    <path id = "north_in" d = ""/>
                    <path id = "east_in90" d = ""/>
                    <path id = "west_in90" d = ""/>
                    <path id = "eq_in0_1" d = ""/>
                    <path id = "eq_in0_2" d = ""/>
                  </g>
                  <g id = "cusps_above_horizon">  
                    <path id = "cusp8" d = ""/>
                    <path id = "cusp9" d = ""/>
                    <path id = "cusp11" d = ""/>
                    <path id = "cusp12" d = ""/>
                    <g id = "uppercusps_textgroup">
                      <g id = "uppercusps_textgroup_inner">
                        <text id = "cusp7text" x="0" y="0">7</text>
                        <text id = "cusp8text" x="0" y="0">8</text>
                        <text id = "cusp9text" x="0" y="0">9</text>
                        <text id = "cusp10text" x="0" y="0">10</text>
                        <text id = "cusp11text" x="0" y="0">11</text>
                        <text id = "cusp12text" x="0" y="0">12</text>
                      </g>
                    </g>
                  </g>
                  <g style="clip-path:url(#skyClip);">
                    <g id="starGroup" stroke="none" transform="rotate(0)" style="visibility: hidden;"/>
                  </g>
                </g> <!--/skyGroup-->
                <path id = "sky_outline" d = ""/>
                <g id = "cusps_below_horizon">  
                  <path id = "cusp2" d = ""/>
                  <path id = "cusp2a" d = ""/>
                  <path id = "cusp3" d = ""/>
                  <path id = "cusp3a" d = ""/>
                  <path id = "cusp5" d = ""/>
                  <path id = "cusp5a" d = ""/>
                  <path id = "cusp6" d = ""/>
                  <path id = "cusp6a" d = ""/>
                  <g id = "lowercusps_textgroup">
                    <text id = "cusp1text" x="0" y="0">1</text>
                    <text id = "cusp2text" x="0" y="0">2</text>
                    <text id = "cusp3text" x="0" y="0">3</text>
                    <text id = "cusp4text" x="0" y="0">4</text>
                    <text id = "cusp5text" x="0" y="0">5</text>
                    <text id = "cusp6text" x="0" y="0">6</text>
                  </g>
                </g>
                <g id="nocturnalGroup" visibility="hidden"/>
              </g> <!--/mater_group-->
              
              <!-- Upper layer with correct transform -->
              <g id="upperlayer" fill="none" stroke="none" transform="matrix(1,0,0,-1,105,105)">
                <!-- Rete Layer with star patterns -->
                <g id="reteLayer" transform="rotate(0)">
                  <g id="reteGroup_default" class="rete_group active_rete">
                    <g id="retebrassGroup" class="rete">
                      <path id="capella" d=""/>
                      <path id="retePath"/>
                      <g id="reteMarks"/>
                      <g id="starnames_textgroup"/>
                      <g id="starpointer_group" transform="rotate(-270)" fill-rule="evenodd"/>
                      <path id="vega" d=""/>
                      <path id="altair" d=""/>
                      <path id="deneb" d=""/>
                      <path id="spica" d=""/>
                      <path id="arcturus" d=""/>
                      <path id="regulus" d=""/>
                      <path id="aldebaran" d=""/>
                      <path id="betelgeuse" d=""/>
                      <path id="sirius" d=""/>
                      <path id="procyon" d=""/>
                      <path id="pollux" d=""/>
                      <path id="castor" d=""/>
                      <path id="antares" d=""/>
                      <path id="fomalhaut" d=""/>
                    </g>
                    <g id="eclipticGroup" class="ecliptic">
                      <path id="ecliptic" d=""/>
                      <g id="eclipticMarks" class="ecliptic_marks"/>
                    </g>
                  </g>
                  <g id="reteGroup_51459" class="rete_group inactive_rete"/>
                </g>
                
                <!-- Rule Group -->
                <g id="ruleGroup"/>
                
                <!-- Planets Group -->
                <g id="planetsGroup">
                  <g id="saturnGroup">
                    <circle id="saturnplanet" cx="0" cy="0" r="0" fill="url(#saturnGrad)"/>
                    <text id="saturntext" x="0" y="0">♄</text>
                  </g>
                  <g id="jupiterGroup">
                    <circle id="jupiterplanet" cx="0" cy="0" r="0" fill="url(#jupiterGrad)"/>
                    <text id="jupitertext" x="0" y="0">♃</text>
                  </g>
                  <g id="marsGroup">
                    <circle id="marsplanet" cx="0" cy="0" r="0" fill="url(#marsGrad)"/>
                    <text id="marstext" x="0" y="0">♂</text>
                  </g>
                  <g id="venusGroup">
                    <circle id="venusplanet" cx="0" cy="0" r="0" fill="url(#venusGrad)"/>
                    <text id="venustext" x="0" y="0">♀</text>
                  </g>
                  <g id="mercuryGroup">
                    <circle id="mercuryplanet" cx="0" cy="0" r="0" fill="url(#mercuryGrad)"/>
                    <text id="mercurytext" x="0" y="0">☿</text>
                  </g>
                  <g id="sunGroup">
                    <circle id="sunplanet" cx="0" cy="0" r="0" fill="url(#sunGrad)"/>
                    <text id="suntext" x="0" y="0">☉</text>
                  </g>
                  <g id="moonGroup">
                    <circle id="moonplanet" cx="0" cy="0" r="0" fill="url(#moonGrad)"/>
                    <text id="moontext" x="0" y="0">☽</text>
                  </g>
                </g> <!--/planetsGroup-->
              </g> <!--/upperlayer-->
              
              <g id="highlightGroup" fill="none" stroke="none" stroke-width="1">
                <circle id="capricorn_highlight" cx="0" cy="0" r="0" />
                <circle id="equator_highlight" cx="0" cy="0" r="0" />
                <circle id="cancer_highlight" cx="0" cy="0" r="0" />
                <g id = "regiomontanus_group" />
                <g id = "alchabitius_group" stroke-width="1"/>
                <g id = "prayerline_group" />
              </g> <!--/highlightGroup-->
            </svg>
            
            <!-- Astrolabe Control Buttons -->
            <svg id="svg_buttons" width="100%" viewBox="0 0 100 16" style="margin-top: 10px;">
              <defs>
                <radialGradient id="buttonglow"/>
              </defs>
              <g id="buttonpanel_group" transform="matrix(1,0,0,-1,50,8)">
                <g id="now_button_group" class="panel_button"/>
                <g id="stop_button_group" class="panel_button"/>
                <g id="ff_button_group" class="panel_button"/>
                <g id="rr_button_group" class="panel_button"/>
              </g> 
            </svg>
            
            <!-- Time Wheels Container -->
            <svg id="svg_wheels" class="svgx" width="100%" viewBox="0 0 90 20" style="background: transparent; border-radius: 8px; margin-top: 2px; margin-bottom: 2px;">
              <defs>
                <linearGradient id="silver"/>
              </defs>
              <g transform="matrix(1,0,0,-1,45,10)">
                <g id="wheelgroup" stroke="none">
                  <rect id="yearwheel" x="0" y="0" width="0" height="0"/>
                  <rect id="monthwheel" x="0" y="0" width="0" height="0"/>
                  <rect id="daywheel" x="0" y="0" width="0" height="0" />
                  <rect id="hourwheel" x="0" y="0" width="0" height="0"/>
                  <rect id="minutewheel" x="0" y="0" width="0" height="0"/>
                </g>
                <g id="wheel_textgroup" transform="matrix(1,0,0,-1,0,0)" font-size="5" font-family="monospace" stroke="none" text-anchor="middle">
                  <g id="centuryblock_group"/>
                  <g id="monthwheel_textgroup" transform="translate(0,1.5)"/>
                  <g id="daywheel_textgroup_365" transform="translate(0,1.5)" visibility="visible"/>
                  <g id="daywheel_textgroup_366" transform="translate(0,1.5)" visibility="hidden"/>
                  <g id="daywheel_textgroup_355" transform="translate(0,1.5)" visibility="hidden"/>
                  <g id="hourwheel_textgroup" transform="translate(0,1.5)"/>
                  <g id="minutewheel_textgroup" transform="translate(0,1.5)"/>
                </g>
                <g id="wheelbox" stroke="none" fill="rgba(0,0,0,0)">
                  <rect id="yearbox" x="0" y="0" width="0" height="0"/>
                  <rect id="monthbox" x="0" y="0" width="0" height="0"/>
                  <rect id="daybox" x="0" y="0" width="0" height="0"/>
                  <rect id="hourbox" x="0" y="0" width="0" height="0"/>
                  <rect id="minutebox" x="0" y="0" width="0" height="0"/>
                </g>
                <rect id="topshield" x="-50" y="0" width="100" height="50" fill="transparent" opacity="0"/>
                <rect id="bottomshield" x="-50" y="0" width="100" height="50" fill="transparent" opacity="0" transform="matrix(1,0,0,-1,0,0)"/>
              </g>
              <!-- Hidden status elements -->
              <foreignObject x="-1000" y="-1000" width="1" height="1">
                <div xmlns="http://www.w3.org/1999/xhtml">
                  <p><span>value: </span><span id="yearwheel_val">0</span></p>
                  <p><span>position: </span><span id="yearwheel_y">1.500</span></p>
                  <p><span>dy: </span><span id="yearwheel_dy"></span></p>
                  <p><span>value: </span><span id="monthwheel_val">0</span></p>
                  <p><span>position: </span><span id="monthwheel_y">1.500</span></p>
                  <p><span>dy: </span><span id="monthwheel_dy"></span></p>
                  <p><span>value: </span><span id="daywheel_val">0</span><span> of </span><span id="daysinyear">0</span></p>
                  <p><span>position: </span><span id="daywheel_y">1.500</span></p>
                  <p><span>dy: </span><span id="daywheel_dy"></span></p>
                  <p><span>value: </span><span id="hourwheel_val">0</span></p>
                  <p><span>position: </span><span id="hourwheel_y">1.500</span></p>
                  <p><span>dy: </span><span id="hourwheel_dy"></span></p>
                  <p><span>value: </span><span id="minutewheel_val">0</span></p>
                  <p><span>position: </span><span id="minutewheel_y">1.500</span></p>
                  <p><span>dy: </span><span id="minutewheel_dy"></span></p>
                </div>
              </foreignObject>
            </svg>
            
            <!-- Radio Button Elements for settings -->
            <div style="display: none;">
              <svg id="svg_radio1" class="svgx" width="100%" viewBox="0 0 36 10"/>
              <svg id="svg_radio2" class="svgx" width="100%" viewBox="0 0 36 10"/>
              <input type="hidden" name="latitudeSlider" id="latitudeSlider" class="latitude-slider" min="0" max="90" value="40">
              <input type="number" name="year_numberinput" id="year_numberinput" value="2024">
              <select name="month_select" id="month_select"></select>
              
              <!-- Hidden spans for astrolabe calculations -->
              <span id="lmst_span">0</span>
              <span id="dayname_span"></span>
              <span id="monthname_span"></span>
              <span id="daynum_span"></span>
              <span id="yearspan"></span>
              <span id="hourspan"></span>
              <span id="minutesspan"></span>
              <span id="ampm_span"></span>
              <span id="utcoffset_sign"></span>
              <span id="utcoffset_span"></span>
              <span id="juliandate_span"></span>
              <!-- Date/Time Elements for Astrolabe -->
              <span id="local_year">2024</span>
              <span id="local_month">1</span>
              <span id="local_day">1</span>
              <span id="local_hour">12</span>
              <span id="local_minutes">0</span>
              <span id="local_seconds">0</span>
              <span id="latitude">41</span>
              <span id="longitude">35</span>
              <span id="julian_day">0</span>
              <span id="julian_day_local">0</span>
              <span id="lonspan">35°E</span>
              <span id="gmst_span">0</span>
              <span id="lmst_span">0</span>
              <span id="dst_radiospan" style="display:none">0</span>
              
              <!-- Ephemeris elements for planets -->
              <span id="moonAlpha">0</span><span id="moonDelta">0</span><span id="moonLambdaSign">♈</span><span id="moonLambda">0</span><span id="moonBeta">0</span><span id="moonAZ">0</span><span id="moonAL">0</span><span id="moonHouse">0</span><span id="moonHouseVal">0</span>
              <span id="sunAlpha">0</span><span id="sunDelta">0</span><span id="sunLambdaSign">♈</span><span id="sunLambda">0</span><span id="sunBeta">0</span><span id="sunAZ">0</span><span id="sunAL">0</span><span id="sunHouse">0</span><span id="sunHouseVal">0</span>
              <span id="mercuryAlpha">0</span><span id="mercuryDelta">0</span><span id="mercuryLambdaSign">♈</span><span id="mercuryLambda">0</span><span id="mercuryBeta">0</span><span id="mercuryAZ">0</span><span id="mercuryAL">0</span><span id="mercuryHouse">0</span><span id="mercuryHouseVal">0</span>
              <span id="venusAlpha">0</span><span id="venusDelta">0</span><span id="venusLambdaSign">♈</span><span id="venusLambda">0</span><span id="venusBeta">0</span><span id="venusAZ">0</span><span id="venusAL">0</span><span id="venusHouse">0</span><span id="venusHouseVal">0</span>
              <span id="marsAlpha">0</span><span id="marsDelta">0</span><span id="marsLambdaSign">♈</span><span id="marsLambda">0</span><span id="marsBeta">0</span><span id="marsAZ">0</span><span id="marsAL">0</span><span id="marsHouse">0</span><span id="marsHouseVal">0</span>
              <span id="jupiterAlpha">0</span><span id="jupiterDelta">0</span><span id="jupiterLambdaSign">♈</span><span id="jupiterLambda">0</span><span id="jupiterBeta">0</span><span id="jupiterAZ">0</span><span id="jupiterAL">0</span><span id="jupiterHouse">0</span><span id="jupiterHouseVal">0</span>
              <span id="saturnAlpha">0</span><span id="saturnDelta">0</span><span id="saturnLambdaSign">♈</span><span id="saturnLambda">0</span><span id="saturnBeta">0</span><span id="saturnAZ">0</span><span id="saturnAL">0</span><span id="saturnHouse">0</span><span id="saturnHouseVal">0</span>
              
              <!-- Astrological house calculations -->
              <span id="mc_span">0</span>
              <span id="asc_span">0</span>
              
              <!-- Ascendant ephemeris -->
              <span id="ascendantAlpha">0</span>
              <span id="ascendantDelta">0</span>
              <span id="ascendantLambdaSign">♈</span>
              <span id="ascendantLambda">0</span>
              <span id="ascendantAZ">0</span>
              
              <!-- Panel button status -->
              <span id="run_status">run</span>
              <span id="ff_speed">0</span>
              <span id="rr_speed">0</span>
            </div>
            </div>
        </div>
        
        <!-- Bottom Three Sections -->
        <div class="bottom-sections">
            <!-- Left table - Saturn, Jupiter, Mars, Sun -->
            <div class="ephemeris-left">
                <table id="ephemerisTableLeft">
                    <tr>
                        <td id="col0" colspan="2" style="text-align:center;"></td>
                        <td id="col1" colspan="2" style="text-align:center; font-weight:bold;">λ</td>
                        <td id="col2" style="width:4em; text-align:center; font-weight:bold;">β</td>
                        <td id="col3" style="width:4em; text-align:center; font-weight:bold;">RA</td>
                        <td id="col4" style="width:4em; text-align:center; font-weight:bold;">Dec</td>
                        <td id="col5" style="width:4em; text-align:center; font-weight:bold;">Az</td>
                        <td id="col6" style="width:4em; text-align:center; font-weight:bold;">El</td>
                        <td id="col7" colspan="2" style="text-align:center; font-weight:bold;">House</td>
                    </tr>
                    <tr id="saturnRow">
                        <td class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Satürn</td>
                        <td class="graycell" style="text-align:center;">♄</td>
                        <td class="zsign_eph eph-cell" data-eph="saturnLambdaSign"></td>
                        <td class="eph-cell" data-eph="saturnLambda" style="padding-left:0em;"></td>
                        <td class="graycell eph-cell" data-eph="saturnBeta"></td>
                        <td class="eph-cell" data-eph="saturnAlpha"></td>
                        <td class="graycell eph-cell" data-eph="saturnDelta"></td>
                        <td class="eph-cell" data-eph="saturnAZ"></td>
                        <td class="graycell eph-cell" data-eph="saturnAL"></td>
                        <td class="housedigit eph-cell" data-eph="saturnHouse" style="text-align:center;"></td>
                        <td class="eph-cell" data-eph="saturnHouseVal" style="padding-left:0em;"></td>
                    </tr>
                    <tr id="jupiterRow">
                        <td class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Jüpiter</td>
                        <td class="graycell">♃</td>
                        <td class="zsign_eph eph-cell" data-eph="jupiterLambdaSign"></td>
                        <td class="eph-cell" data-eph="jupiterLambda" style="padding-left:0em;"></td>
                        <td class="graycell eph-cell" data-eph="jupiterBeta"></td>
                        <td class="eph-cell" data-eph="jupiterAlpha"></td>
                        <td class="graycell eph-cell" data-eph="jupiterDelta"></td>
                        <td class="eph-cell" data-eph="jupiterAZ"></td>
                        <td class="graycell eph-cell" data-eph="jupiterAL"></td>
                        <td class="housedigit eph-cell" data-eph="jupiterHouse" style="text-align:center;"></td>
                        <td class="eph-cell" data-eph="jupiterHouseVal" style="padding-left:0em;"></td>
                    </tr>
                    <tr id="marsRow">
                        <td class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Mars</td>
                        <td class="graycell">♂</td>
                        <td class="zsign_eph eph-cell" data-eph="marsLambdaSign"></td>
                        <td class="eph-cell" data-eph="marsLambda" style="padding-left:0em;"></td>
                        <td class="graycell eph-cell" data-eph="marsBeta"></td>
                        <td class="eph-cell" data-eph="marsAlpha"></td>
                        <td class="graycell eph-cell" data-eph="marsDelta"></td>
                        <td class="eph-cell" data-eph="marsAZ"></td>
                        <td class="graycell eph-cell" data-eph="marsAL"></td>
                        <td class="housedigit eph-cell" data-eph="marsHouse" style="text-align:center;"></td>
                        <td class="eph-cell" data-eph="marsHouseVal" style="padding-left:0em;"></td>
                    </tr>
                    <tr>
                        <td class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Güneş</td>
                        <td class="graycell">☉</td>
                        <td class="zsign_eph eph-cell" data-eph="sunLambdaSign"></td>
                        <td class="eph-cell" data-eph="sunLambda" style="padding-left:0em;"></td>
                        <td class="graycell eph-cell" data-eph="sunBeta">0.0°</td>
                        <td class="eph-cell" data-eph="sunAlpha"></td>
                        <td class="graycell eph-cell" data-eph="sunDelta"></td>
                        <td class="eph-cell" data-eph="sunAZ"></td>
                        <td class="graycell eph-cell" data-eph="sunAL"></td>
                        <td class="housedigit eph-cell" data-eph="sunHouse" style="text-align:center;"></td>
                        <td class="eph-cell" data-eph="sunHouseVal" style="padding-left:0em;"></td>
                    </tr>
                </table>
            </div>
            
            <!-- Center calendar display -->
            <div class="calendar-center">
                <div class="date-row">
                    <div class="date-group">
                        <span class="date-label">Julian:</span>
                        <span class="date-value" id="julian-display"></span>
                    </div>
                </div>
                <div class="date-row">
                    <div class="date-group">
                        <span class="date-label">Gregoryan:</span>
                        <span class="date-value" id="gregorian-display"></span>
                    </div>
                </div>
                <div class="date-row">
                    <div class="date-group">
                        <span class="date-label">Rumi:</span>
                        <span class="date-value" id="rumi-display"></span>
                    </div>
                </div>
                <div class="date-row">
                    <div class="date-group">
                        <span class="date-label">Hicri:</span>
                        <span class="date-value" id="hijri-display"></span>
                    </div>
                </div>
            </div>
            
            <!-- Right table - Venus, Mercury, Moon, Ascendant -->
            <div class="ephemeris-right">
                <table id="ephemerisTableRight">
                    <tr>
                        <td id="col0" colspan="2" style="text-align:center;"></td>
                        <td id="col1" colspan="2" style="text-align:center; font-weight:bold;">λ</td>
                        <td id="col2" style="width:4em; text-align:center; font-weight:bold;">β</td>
                        <td id="col3" style="width:4em; text-align:center; font-weight:bold;">RA</td>
                        <td id="col4" style="width:4em; text-align:center; font-weight:bold;">Dec</td>
                        <td id="col5" style="width:4em; text-align:center; font-weight:bold;">Az</td>
                        <td id="col6" style="width:4em; text-align:center; font-weight:bold;">El</td>
                        <td id="col7" colspan="2" style="text-align:center; font-weight:bold;">House</td>
                    </tr>
                    <tr id="venusRow">
                        <td class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Venüs</td>
                        <td class="graycell">♀</td>
                        <td class="zsign_eph eph-cell" data-eph="venusLambdaSign"></td>
                        <td class="eph-cell" data-eph="venusLambda" style="padding-left:0em;"></td>
                        <td class="graycell eph-cell" data-eph="venusBeta"></td>
                        <td class="eph-cell" data-eph="venusAlpha"></td>
                        <td class="graycell eph-cell" data-eph="venusDelta"></td>
                        <td class="eph-cell" data-eph="venusAZ"></td>
                        <td class="graycell eph-cell" data-eph="venusAL"></td>
                        <td class="housedigit eph-cell" data-eph="venusHouse" style="text-align:center;"></td>
                        <td class="eph-cell" data-eph="venusHouseVal" style="padding-left:0em;"></td>
                    </tr>
                    <tr id="mercuryRow">
                        <td class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Merkür</td>
                        <td class="graycell">☿</td>
                        <td class="zsign_eph eph-cell" data-eph="mercuryLambdaSign"></td>
                        <td class="eph-cell" data-eph="mercuryLambda" style="padding-left:0em;"></td>
                        <td class="graycell eph-cell" data-eph="mercuryBeta"></td>
                        <td class="eph-cell" data-eph="mercuryAlpha"></td>
                        <td class="graycell eph-cell" data-eph="mercuryDelta"></td>
                        <td class="eph-cell" data-eph="mercuryAZ"></td>
                        <td class="graycell eph-cell" data-eph="mercuryAL"></td>
                        <td class="housedigit eph-cell" data-eph="mercuryHouse" style="text-align:center;"></td>
                        <td class="eph-cell" data-eph="mercuryHouseVal" style="padding-left:0em;"></td>
                    </tr>      
                    <tr id="moonRow">
                        <td class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Ay</td>
                        <td class="graycell">☽</td>
                        <td class="zsign_eph eph-cell" data-eph="moonLambdaSign"></td>
                        <td class="eph-cell" data-eph="moonLambda" style="padding-left:0em;"></td>
                        <td class="graycell eph-cell" data-eph="moonBeta"></td>
                        <td class="eph-cell" data-eph="moonAlpha"></td>
                        <td class="graycell eph-cell" data-eph="moonDelta"></td>
                        <td class="eph-cell" data-eph="moonAZ"></td>
                        <td class="graycell eph-cell" data-eph="moonAL"></td>
                        <td class="housedigit eph-cell" data-eph="moonHouse" style="text-align:center;"></td>
                        <td class="eph-cell" data-eph="moonHouseVal" style="padding-left:0em;"></td>
                    </tr>
                    <tr id="ascendantRow">
                        <td class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Yükselen</td>
                        <td class="graycell">H</td>
                        <td class="zsign_eph eph-cell" data-eph="ascendantLambdaSign"></td>
                        <td class="eph-cell" data-eph="ascendantLambda" style="padding-left:0em;"></td>
                        <td class="graycell eph-cell" data-eph="ascendantBeta">0.0°</td>
                        <td class="eph-cell" data-eph="ascendantAlpha"></td>
                        <td class="graycell eph-cell" data-eph="ascendantDelta"></td>
                        <td class="eph-cell" data-eph="ascendantAZ"></td>
                        <td class="graycell eph-cell" data-eph="ascendantAL">0.0°</td>
                        <td class="housedigit eph-cell" data-eph="ascendantHouse" style="text-align:center; width:1em;">①</td>
                        <td class="eph-cell" data-eph="ascendantHouseVal" style="padding-left:0em; width:3.7em;">0°00'</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <script src="includes/common.js"></script>
    <script src="local_sync.js"></script>
    
    <!-- jQuery and jQuery Mobile (required for astrolabe scripts) -->
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
    
    <!-- Astrolabe scripts from original index.html -->
    <script src="../d3-dispatch.v1.min.js"></script>
    <script src="../d3-selection.v1.min.js"></script>
    <script src="../d3-drag.v1.min.js"></script>
    <script src="../astronomy.js"></script>
    <script src="../infrastructure.js"></script>
    <script src="../timewheels.js"></script>
    
    <script>
        // Language support (default to Turkish)
        var savedLanguage = 'turkish';
        var languageFolder = '../differences_output/turkce_farkli';
        
        // Define required globals before loading scripts
        window.latitude = 40;
        window.longitude = 35;
        window.defaultLatitude = 40;
        window.defaultLongitude = 35;
        
        // Initialize latitudeSlider value and astrolabe globals
        function initializeAstrolabe() {
            if (document.getElementById('latitudeSlider')) {
                document.getElementById('latitudeSlider').value = 40;
            }
            
            // Set default date if year input exists
            if (document.getElementById('year_numberinput')) {
                document.getElementById('year_numberinput').value = new Date().getFullYear();
            }
        }
        
        // Call initialization when DOM is ready
        $(document).ready(function() {
            initializeAstrolabe();
            
            // Add a delay to ensure all scripts are loaded
            setTimeout(function() {
                if (typeof applySidebarState === 'function') {
                    applySidebarState();
                }
                if (typeof initializeDrag === 'function') {
                    initializeDrag();
                }
            }, 100);
        });
        
        document.write('<script src="' + languageFolder + '/tympanum.js" id="tympanum-script"><\/script>');
        document.write('<script src="' + languageFolder + '/rete.js" id="rete-script"><\/script>');
        document.write('<script src="' + languageFolder + '/rete_51459.js" id="rete51459-script"><\/script>');
    </script>
    
    <script src="../revolve.js"></script>
    <script src="../stars.js"></script>
    <script src="../constellation_data.js"></script>
    <script src="../nav_buttons.js"></script>
    <script src="../panel_buttons.js"></script>
    <script src="../multi_calendar.js"></script>
    <script src="../iphone_sliders.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            let state = { date: new Date(), latitude: 41, showStarNames: true, showAstrolabe: false };
            const svgNS = "http://www.w3.org/2000/svg";
            const ringsGroup = document.getElementById('rings-group');
            const timeRingContainer = document.getElementById('time-ring-container');
            const constellationLinesContainer = document.getElementById('constellation-lines-container');
            const constellationStarsAndNamesContainer = document.getElementById('constellations-stars-and-names-container');
            const eclipticContainer = document.getElementById('ecliptic-container');
            const planetsContainer = document.getElementById('planets-container');
            const backgroundStarsContainer = document.getElementById('background-stars-container');
            const deepSkyObjectsContainer = document.getElementById('deep-sky-objects-container');
            const horizonGroup = document.getElementById('horizon-group');
            // These elements were removed - keeping references as null checks
            const fullDateTimeDisplay = document.getElementById('full-datetime-display');
            const otherCalendarsDisplay = document.getElementById('other-calendars-display');
            const starMapCenter = { x: 500, y: 500 };
            const starFieldRadius = 400;
            const constellationData = { "Andromeda": { stars: [ { name: "Alpheratz", x: -350, y: -200, mag: 2.06 }, { name: "Mirach", x: -300, y: -250, mag: 2.05 }, { name: "Almach", x: -250, y: -300, mag: 2.1 } ], lines: [ [0,1], [1,2] ] }, "Aquarius": { stars: [ { name: "Sadalmelik", x: -350, y: 280, mag: 2.9 }, { name: "Sadalsuud", x: -380, y: 300, mag: 2.9 } ], lines: [ [0,1] ] }, "Aquila": { stars: [ { name: "Altair", x: 300, y: 180, mag: 0.77 }, { name: "Alshain", x: 320, y: 170, mag: 3.7 }, { name: "Tarazed", x: 280, y: 190, mag: 2.7 } ], lines: [ [1,0], [2,0] ] }, "Aries": { stars: [ { name: "Hamal", x: -200, y: -50, mag: 2.00 }, { name: "Sheratan", x: -220, y: -60, mag: 2.64 } ], lines: [ [0,1] ] }, "Auriga": { stars: [ { name: "Capella", x: 100, y: -100, mag: 0.08 }, { name: "Menkalinan", x: 120, y: -70, mag: 1.9 }, { name: "Mahasim", x: 80, y: -130, mag: 2.6 } ], lines: [ [0,1], [1,2], [2,0] ] }, "Boötes": { stars: [ { name: "Arcturus", x: 20, y: 250, mag: -0.04 }, { name: "Izar", x: 40, y: 200, mag: 2.35 }, { name: "Muphrid", x: 0, y: 220, mag: 2.68 } ], lines: [ [0,1], [0,2] ] }, "Camelopardalis": { stars: [ { name: "Alpha Cam", x: 20, y: -250, mag: 4.3 }, { name: "Beta Cam", x: -20, y: -320, mag: 4.0 }, { name: "Gamma Cam", x: 50, y: -350, mag: 4.6 } ], lines: [ [0,1], [1,2] ] }, "Cancer": { stars: [ { name: "Tarf", x: 50, y: 50, mag: 3.5 }, { name: "Asellus Australis", x: 30, y: 70, mag: 3.9 } ], lines: [ [0,1] ] }, "Canes Venatici": { stars: [ { name: "Cor Caroli", x: 100, y: 220, mag: 2.9 }, { name: "Chara", x: 80, y: 190, mag: 4.2 } ], lines: [ [0,1] ] }, "Canis Major": { stars: [ { name: "Sirius", x: 280, y: 250, mag: -1.46 }, { name: "Adhara", x: 320, y: 320, mag: 1.5 }, { name: "Wezen", x: 350, y: 290, mag: 1.8 } ], lines: [ [0,1], [0,2] ] }, "Canis Minor": { stars: [ { name: "Procyon", x: 190, y: 150, mag: 0.34 }, { name: "Gomeisa", x: 170, y: 130, mag: 2.8 } ], lines: [ [0,1] ] }, "Capricornus": { stars: [ { name: "Deneb Algedi", x: -280, y: 350, mag: 2.85 }, { name: "Nashira", x: -310, y: 330, mag: 3.6 } ], lines: [ [0,1] ] }, "Cassiopeia": { stars: [ { name: "Schedar", x: -250, y: -150, mag: 2.2 }, { name: "Caph", x: -280, y: -120, mag: 2.2 }, { name: "Tsih", x: -240, y: -100, mag: 2.1 }, { name: "Ruchbah", x: -210, y: -130, mag: 2.6 }, { name: "Segin", x: -190, y: -90, mag: 3.3 } ], lines: [ [1,0], [0,3], [3,2], [2,4] ] }, "Centaurus": { stars: [ { name: "Menkent", x: -50, y: 380, mag: 2.06 }, { name: "Theta Cen", x: -30, y: 350, mag: 2.06 } ], lines: [ [0,1] ] }, "Cepheus": { stars: [ { name: "Alderamin", x: -100, y: -250, mag: 2.5 }, { name: "Alfirk", x: -50, y: -300, mag: 3.2 }, { name: "Errai", x: -120, y: -350, mag: 3.2 }, { name: "Iota Cep", x: -80, y: -280, mag: 3.5 } ], lines: [ [0,3], [3,1], [1,2] ] }, "Cetus": { stars: [ { name: "Diphda", x: -350, y: 100, mag: 2.04 }, { name: "Mira", x: -250, y: 150, mag: 3.0 }, { name: "Kaffaljidhma", x: -280, y: 80, mag: 3.5 } ], lines: [ [0,2], [2,1] ] }, "Coma Berenices": { stars: [ { name: "Diadem", x: -80, y: 220, mag: 4.3 }, { name: "Beta Com", x: -100, y: 250, mag: 4.2 } ], lines: [ [0,1] ] }, "Corona Australis": { stars: [ { name: "Alfecca Meridiana", x: 280, y: 380, mag: 4.1 }, { name: "Beta CrA", x: 260, y: 370, mag: 4.1 } ], lines: [ [0,1] ] }, "Corona Borealis": { stars: [ { name: "Alphecca", x: 150, y: 210, mag: 2.2 }, { name: "Nusakan", x: 170, y: 200, mag: 3.6 }, { name: "Gamma CrB", x: 130, y: 200, mag: 3.8 } ], lines: [ [1,0], [2,0] ] }, "Corvus": { stars: [ { name: "Gienah Corvi", x: -200, y: 330, mag: 2.6 }, { name: "Kraz", x: -220, y: 310, mag: 2.6 }, { name: "Algorab", x: -210, y: 290, mag: 2.9 } ], lines: [ [0,1], [1,2] ] }, "Crater": { stars: [ { name: "Alkes", x: -160, y: 320, mag: 4.1 }, { name: "Delta Crt", x: -180, y: 300, mag: 3.5 } ], lines: [ [0,1] ] }, "Cygnus": { stars: [ { name: "Deneb", x: 150, y: -300, mag: 1.25 }, { name: "Albireo", x: 230, y: -180, mag: 3.0 }, { name: "Sadr", x: 140, y: -240, mag: 2.2 }, { name: "Gienah", x: 100, y: -250, mag: 2.5 }, { name: "Fawaris", x: 190, y: -270, mag: 4.4 } ], lines: [ [1,2], [2,0], [0,3], [0,4], [2,3], [2,4] ] }, "Delphinus": { stars: [ { name: "Sualocin", x: 280, y: -100, mag: 3.7 }, { name: "Rotanev", x: 290, y: -120, mag: 3.6 }, { name: "Deneb Dulfim", x: 310, y: -110, mag: 3.9 } ], lines: [ [0,1], [1,2] ] }, "Draco": { stars: [ { name: "Etanin", x: 50, y: -150, mag: 2.2 }, { name: "Rastaban", x: 30, y: -130, mag: 2.7 }, { name: "Thuban", x: -20, y: -100, mag: 3.6 }, { name: "Grumium", x: 80, y: -120, mag: 3.7}], lines: [ [0,1], [1,2], [0,3] ] }, "Equuleus": { stars: [ { name: "Kitalpha", x: -300, y: -50, mag: 3.9 }, { name: "Delta Equ", x: -310, y: -40, mag: 4.4 } ], lines: [ [0,1] ] }, "Eridanus": { stars: [ { name: "Cursa", x: 170, y: 220, mag: 2.8 }, { name: "Zaurak", x: 100, y: 280, mag: 3.0 }, { name: "Acamar", x: 50, y: 350, mag: 2.9 } ], lines: [ [0,1], [1,2] ] }, "Gemini": { stars: [ { name: "Castor", x: 150, y: -50, mag: 1.58 }, { name: "Pollux", x: 130, y: -30, mag: 1.14 }, { name: "Alhena", x: 180, y: 10, mag: 1.9 } ], lines: [ [0,1], [1,2] ] }, "Hercules": { stars: [ { name: "Kornephoros", x: 80, y: 150, mag: 2.7 }, { name: "Rasalgethi", x: 120, y: 180, mag: 2.8 }, { name: "Sarin", x: 60, y: 120, mag: 3.1 }, { name: "Zeta Her", x: 100, y: 130, mag: 2.8 } ], lines: [ [0,1], [0,2], [0,3], [2,3] ] }, "Hydra": { stars: [ { name: "Alphard", x: -50, y: 180, mag: 2.0 }, { name: "Gamma Hya", x: -100, y: 220, mag: 3.0 }, { name: "Zeta Hya", x: -30, y: 150, mag: 3.1 } ], lines: [ [2,0], [0,1] ] }, "Lacerta": { stars: [ { name: "Alpha Lac", x: 100, y: -350, mag: 3.7 }, { name: "Beta Lac", x: 80, y: -320, mag: 4.4 } ], lines: [ [0,1] ] }, "Leo": { stars: [ { name: "Regulus", x: -100, y: 150, mag: 1.35 }, { name: "Denebola", x: -220, y: 180, mag: 2.14 }, { name: "Algieba", x: -120, y: 120, mag: 2.01 } ], lines: [ [0,2], [2,1]] }, "Leo Minor": { stars: [ { name: "Praecipua", x: -30, y: 50, mag: 3.8 }, { name: "Beta LMi", x: -50, y: 80, mag: 4.2 } ], lines: [ [0,1] ] }, "Lepus": { stars: [ { name: "Arneb", x: 200, y: 280, mag: 2.58 }, { name: "Nihal", x: 220, y: 270, mag: 2.84 } ], lines: [ [0,1] ] }, "Libra": { stars: [ { name: "Zubeneschamali", x: -50, y: 300, mag: 2.6 }, { name: "Zubenelgenubi", x: -20, y: 320, mag: 2.7 } ], lines: [ [0,1] ] }, "Lupus": { stars: [ { name: "Alpha Lup", x: 20, y: 390, mag: 2.3 }, { name: "Beta Lup", x: 50, y: 380, mag: 2.6 } ], lines: [ [0,1] ] }, "Lynx": { stars: [ { name: "Alpha Lyn", x: 100, y: -20, mag: 3.1 }, { name: "38 Lyn", x: 130, y: -80, mag: 3.8 } ], lines: [ [0,1] ] }, "Lyra": { stars: [ { name: "Vega", x: 250, y: -280, mag: 0.03 }, { name: "Sulafat", x: 290, y: -240, mag: 3.2 }, { name: "Sheliak", x: 280, y: -235, mag: 3.5 }, { name: "Zeta Lyr", x: 260, y: -230, mag: 4.3 }, { name: "Delta Lyr", x: 270, y: -225, mag: 4.2 } ], lines: [ [0,3], [0,4], [3,2], [2,1], [1,4] ] }, "Monoceros": { stars: [ { name: "Beta Mon", x: 220, y: 200, mag: 4.5 }, { name: "Alpha Mon", x: 250, y: 180, mag: 3.9 } ], lines: [ [0,1] ] }, "Ophiuchus": { stars: [ { name: "Rasalhague", x: 180, y: 150, mag: 2.0 }, { name: "Sabik", x: 160, y: 250, mag: 2.4 }, { name: "Yed Prior", x: 140, y: 200, mag: 2.7 } ], lines: [ [0,2], [2,1] ] }, "Orion": { stars: [ { name: "Betelgeuse", x: 250, y: 100, mag: 0.5 }, { name: "Rigel", x: 180, y: 200, mag: 0.1 }, { name: "Bellatrix", x: 200, y: 80, mag: 1.6 }, { name: "Saiph", x: 260, y: 210, mag: 2.0 }, { name: "Alnitak", x: 225, y: 155, mag: 1.7 }, { name: "Alnilam", x: 220, y: 145, mag: 1.7 }, { name: "Mintaka", x: 215, y: 135, mag: 2.2 } ], lines: [ [0,2], [1,3], [2,6], [6,5], [5,4], [4,0], [3,1] ] }, "Pegasus": { stars: [ { name: "Markab", x: -360, y: 10, mag: 2.4 }, { name: "Scheat", x: -360, y: -60, mag: 2.4 }, { name: "Algenib", x: -290, y: -60, mag: 2.8 }, { name: "Enif", x: -230, y: 40, mag: 2.3 } ], lines: [ [0,1], [1,2], [0,3] ] }, "Perseus": { stars: [ { name: "Mirfak", x: -150, y: -280, mag: 1.8 }, { name: "Algol", x: -180, y: -240, mag: 2.1 }, { name: "Atik", x: -130, y: -320, mag: 3.7 } ], lines: [ [0,1], [0,2] ] }, "Pisces": { stars: [ { name: "Eta Piscium", x: -380, y: -150, mag: 3.6 }, { name: "Gamma Piscium", x: -350, y: -120, mag: 3.7 } ], lines: [ [0,1] ] }, "Piscis Austrinus": { stars: [ { name: "Fomalhaut", x: -380, y: 380, mag: 1.16 } ], lines: [] }, "Puppis": { stars: [ { name: "Naos", x: 380, y: 380, mag: 2.2 }, { name: "Tureis", x: 350, y: 350, mag: 2.8 } ], lines: [ [0,1] ] }, "Sagitta": { stars: [ { name: "Gamma Sge", x: 280, y: -150, mag: 3.5 }, { name: "Alpha Sge", x: 290, y: -140, mag: 4.3 }, { name: "Beta Sge", x: 285, y: -130, mag: 4.3 } ], lines: [ [1,0], [2,0] ] }, "Sagittarius": { stars: [ { name: "Kaus Australis", x: 200, y: 340, mag: 1.85 }, { name: "Nunki", x: 230, y: 310, mag: 2.05 } ], lines: [ [0,1] ] }, "Scorpius": { stars: [ { name: "Antares", x: 100, y: 280, mag: 1.09 }, { name: "Graffias", x: 80, y: 250, mag: 2.56 }, { name: "Dschubba", x: 90, y: 240, mag: 2.29 }, { name: "Shaula", x: 150, y: 350, mag: 1.62 } ], lines: [ [2,1], [1,0], [0,3] ] }, "Scutum": { stars: [ { name: "Alpha Sct", x: 250, y: 280, mag: 3.8 }, { name: "Beta Sct", x: 260, y: 270, mag: 4.2 } ], lines: [ [0,1] ] }, "Serpens": { stars: [ { name: "Unukalhai", x: 100, y: 200, mag: 2.6 }, { name: "Alya", x: 250, y: 220, mag: 4.5 } ], lines: [ [0,1] ] }, "Sextans": { stars: [ { name: "Alpha Sex", x: -120, y: 200, mag: 4.5 }, { name: "Gamma Sex", x: -130, y: 190, mag: 5.0 } ], lines: [ [0,1] ] }, "Taurus": { stars: [ { name: "Aldebaran", x: 200, y: 50, mag: 0.85 }, { name: "El Nath", x: 250, y: 0, mag: 1.65 }, { name: "Hyadum I", x: 180, y: 40, mag: 3.6 } ], lines: [ [2,0], [0,1] ] }, "Triangulum": { stars: [ { name: "Mothallah", x: -250, y: -80, mag: 3.0 }, { name: "Deltotum", x: -270, y: -70, mag: 3.4 } ], lines: [ [0,1] ] }, "Ursa Major": { stars: [ { name: "Dubhe", x: -50, y: -200, mag: 1.8 }, { name: "Merak", x: -10, y: -160, mag: 2.3 }, { name: "Phad", x: 40, y: -150, mag: 2.4 }, { name: "Megrez", x: 70, y: -180, mag: 3.3 }, { name: "Alioth", x: 120, y: -210, mag: 1.7 }, { name: "Mizar", x: 160, y: -240, mag: 2.2 }, { name: "Alkaid", x: 200, y: -280, mag: 1.8 } ], lines: [ [0,1], [1,2], [2,3], [3,4], [4,5], [5,6] ] }, "Ursa Minor": { stars: [ { name: "Polaris", x: 0, y: -15, mag: 2.0 }, { name: "Kochab", x: -30, y: -80, mag: 2.0 }, { name: "Pherkad", x: -10, y: -100, mag: 3.0 }, { name: "Yildun", x: 25, y: -40, mag: 4.3 } ], lines: [ [0,3], [3,2], [2,1] ] }, "Virgo": { stars: [ { name: "Spica", x: -150, y: 280, mag: 0.97 }, { name: "Porrima", x: -180, y: 250, mag: 2.74 } ], lines: [ [0,1] ] }, "Vulpecula": { stars: [ { name: "Anser", x: 240, y: -200, mag: 4.4 }, { name: "23 Vul", x: 260, y: -210, mag: 4.5 } ], lines: [ [0,1] ] } };
            const zodiacSigns = [ { name: "Koç", start: 0, symbol: '♈' }, { name: "Boğa", start: 30, symbol: '♉' }, { name: "İkizler", start: 60, symbol: '♊' }, { name: "Yengeç", start: 90, symbol: '♋' }, { name: "Aslan", start: 120, symbol: '♌' }, { name: "Başak", start: 150, symbol: '♍' }, { name: "Terazi", start: 180, symbol: '♎' }, { name: "Akrep", start: 210, symbol: '♏' }, { name: "Yay", start: 240, symbol: '♐' }, { name: "Oğlak", start: 270, symbol: '♑' }, { name: "Kova", start: 300, symbol: '♒' }, { name: "Balık", start: 330, symbol: '♓' } ];
            const movingBodiesData = { "Güneş": { symbol: '☉', color: "#FFD700", period: 365.25, baseAngle: 0 }, "Ay": { symbol: '☽', color: "#E0E0E0", period: 27.32, baseAngle: 45 }, "Merkür":  { symbol: '☿', color: "#A9A9A9", period: 88, baseAngle: 20 }, "Venüs":   { symbol: '♀', color: "#F8F8FF", period: 225, baseAngle: 150 }, "Mars":    { symbol: '♂', color: "#FF4500", period: 687, baseAngle: 300 }, "Jüpiter": { symbol: '♃', color: "#FFD700", period: 4333, baseAngle: 80 }, "Satürn":  { symbol: '♄', color: "#F0E68C", period: 10759, baseAngle: 220 } };
            
            // --- ASTROLABE TOGGLE FUNCTION ---
            function toggleAstrolabeView(showAstrolabe) {
                console.log('🔄 Toggle astrolabe view:', showAstrolabe);
                
                const astrolabeContainer = document.querySelector('.astrolabe-container');
                const starChartContainer = document.querySelector('.star-chart-container');
                
                if (astrolabeContainer && starChartContainer) {
                    if (showAstrolabe) {
                        // Show astrolabe, hide star chart
                        console.log('📍 Showing astrolabe, hiding star chart');
                        astrolabeContainer.style.display = 'block';
                        starChartContainer.style.display = 'none';
                        
                        // Initialize astrolabe if not already done
                        if (typeof draw_tympanum === 'function' && typeof draw_rete === 'function') {
                            try {
                                draw_tympanum();
                                draw_rete();
                                
                                // Add rule (index/alidade) if available
                                if (typeof rule === 'function' && document.getElementById('ruleGroup')) {
                                    rule();
                                    console.log('✅ Rule (index) added to astrolabe');
                                }
                                
                                // Load head SVG (crown/decorative top part)
                                loadHeadSvg('turkish');
                                
                                console.log('✅ Astrolabe initialized with original functions');
                            } catch (error) {
                                console.error('❌ Error initializing astrolabe:', error);
                            }
                        }
                    } else {
                        // Show star chart, hide astrolabe  
                        console.log('⭐ Showing star chart, hiding astrolabe');
                        astrolabeContainer.style.display = 'none';
                        starChartContainer.style.display = 'block';
                    }
                }
            }

            // --- MAIN UPDATE & DRAW FUNCTIONS ---
            function updateAllViews() {
                const optionsDate = { day: 'numeric', month: 'long', year: 'numeric' };
                const dateText = state.date.toLocaleDateString('tr-TR', optionsDate);
                const timeText = state.date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });

                // Only update star map if it's currently visible (not astrolabe)
                if (!state.showAstrolabe) {
                    updateStarMapData();
                    updateStarMapViewRotation();
                }
                
                // Update calendar displays
                updateCalendarDisplays();
                
                // Update ephemeris tables
                updateEphemerisTables();
                
                // Update astrolabe when showing it
                if (typeof tympanum === 'function') {
                    tympanum();
                }
                if (typeof planet_advance === 'function') {
                    planet_advance();
                }
            }
            
            function updateCalendarDisplays() {
                const date = state.date;
                
                // Update Julian date
                const julianDay = (date.getTime() / 86400000) + 2440587.5;
                const julianDisplay = document.getElementById('julian-display');
                if (julianDisplay) {
                    julianDisplay.textContent = julianDay.toFixed(6);
                }
                
                // Update Gregorian date
                const gregorianDisplay = document.getElementById('gregorian-display');
                if (gregorianDisplay) {
                    const day = date.getDate();
                    const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
                                   'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
                    const month = months[date.getMonth()];
                    const year = date.getFullYear();
                    gregorianDisplay.textContent = `${day} ${month} ${year}`;
                }
                
                // Update Rumi date
                const rumiDisplay = document.getElementById('rumi-display');
                if (rumiDisplay) {
                    let rumiYear = date.getFullYear() - 584;
                    const rumiMonths = ["Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", 
                                       "Eylül", "Ekim", "Kasım", "Aralık", "Ocak", "Şubat"];
                    let rumiMonthIndex = date.getMonth() - 2;
                    let rumiDay = date.getDate();
                    
                    if (rumiMonthIndex < 0) {
                        rumiMonthIndex += 12;
                    }
                    
                    // Adjust for old calendar difference (13 days)
                    if (date.getMonth() < 2 || (date.getMonth() === 2 && date.getDate() < 14)) {
                        rumiYear--;
                    }
                    
                    rumiDisplay.textContent = `${rumiDay} ${rumiMonths[rumiMonthIndex]} ${rumiYear}`;
                }
                
                // Update Hijri date
                const hijriDisplay = document.getElementById('hijri-display');
                if (hijriDisplay) {
                    try {
                        const hijriDate = new Intl.DateTimeFormat('tr-u-ca-islamic-umalqura', {
                            day: 'numeric', 
                            month: 'long', 
                            year: 'numeric'
                        }).format(date);
                        hijriDisplay.textContent = hijriDate;
                    } catch (e) {
                        hijriDisplay.textContent = 'N/A';
                    }
                }
            }
            function updateStarMapData() {
                const { date, latitude, showStarNames } = state;
                const startOfYear = new Date(date.getFullYear(), 0, 0);
                const dayOfYear = Math.floor((date - startOfYear) / (1000 * 60 * 60 * 24));

                const occluder = document.getElementById('occluder');
                // 0°'de 1° gibi davransın - ani geçişi önle
                const effectiveLatitude = latitude === 0 ? 1 : latitude;
                const h = starFieldRadius * effectiveLatitude / 90;
                if (latitude < 0 || h <= 0.01) { occluder.setAttribute('d', ''); }
                else { 
                    const chord = starFieldRadius * 2; 
                    const arcRadius = (h * h + (chord / 2) * (chord / 2)) / (2 * h); 
                    const d = `M ${500-starFieldRadius},500 A ${arcRadius},${arcRadius} 0 0 1 ${500+starFieldRadius},500 A ${starFieldRadius},${starFieldRadius} 0 0 0 ${500-starFieldRadius},500 Z`; 
                    occluder.setAttribute('d', d); 
                }

                // Calendar display elements were removed - skip these updates
                if (fullDateTimeDisplay) {
                    const formattedDateTime = `${date.getDate()} ${date.toLocaleString('tr-TR', { month: 'long' })} ${date.getFullYear()} - ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
                    const hijriDate = new Intl.DateTimeFormat('tr-u-ca-islamic-umalqura', {day: 'numeric', month: 'long', year: 'numeric'}).format(date);
                    fullDateTimeDisplay.textContent = `${formattedDateTime} / ${hijriDate}`;
                }
                
                if (otherCalendarsDisplay) {
                    const julianDay = (date.getTime() / 86400000) + 2440587.5;
                    let rumiYear = date.getFullYear() - 584;
                    const rumiMonths = ["Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Teşrin-i Evvel", "Teşrin-i Sani", "Kanun-ı Evvel", "Kanun-ı Sani", "Şubat"];
                    let rumiMonthIndex = date.getMonth() - 2;
                    if (rumiMonthIndex < 0) rumiMonthIndex += 12;
                    if (date.getMonth() < 2 || (date.getMonth() === 2 && date.getDate() < 14)) { rumiYear--; }
                    otherCalendarsDisplay.innerHTML = `<span>Jülyen Günü: ${julianDay.toFixed(4)}</span> <span class="mx-2">|</span> <span>Rumi: ${rumiMonths[rumiMonthIndex]} ${rumiYear}</span>`;
                }
                
                updateEphemerisAndPlanets(dayOfYear);
                updateEphemerisTables(); // Update the new ephemeris tables
                toggleUiElements(showStarNames);
            }
            
            // Update ephemeris tables - this is called after revolve.js updates the data
            function updateEphemerisTables() {
                // First trigger revolve to calculate all ephemeris data
                if (typeof revolve === 'function') {
                    try {
                        revolve();
                        console.log('Called revolve() to update ephemeris data');
                    } catch (e) {
                        console.error('Error calling revolve:', e);
                    }
                }
                
                // Then copy from hidden spans to table cells with a small delay
                setTimeout(() => {
                    // Get all cells with data-eph attribute
                    const ephCells = document.querySelectorAll('.eph-cell[data-eph]');
                    
                    ephCells.forEach(cell => {
                        const ephId = cell.getAttribute('data-eph');
                        const sourceSpan = document.getElementById(ephId);
                        
                        if (sourceSpan && sourceSpan.innerHTML) {
                            cell.innerHTML = sourceSpan.innerHTML;
                        }
                    });
                    
                    // Also update special fields for ascendant which have fixed values
                    const ascAL = document.querySelector('[data-eph="ascendantAL"]');
                    const ascBeta = document.querySelector('[data-eph="ascendantBeta"]');
                    const ascHouse = document.querySelector('[data-eph="ascendantHouse"]');
                    const ascHouseVal = document.querySelector('[data-eph="ascendantHouseVal"]');
                    
                    if (ascAL && (!ascAL.innerHTML || ascAL.innerHTML === '')) ascAL.innerHTML = '0.0°';
                    if (ascBeta && (!ascBeta.innerHTML || ascBeta.innerHTML === '')) ascBeta.innerHTML = '0.0°';
                    if (ascHouse && (!ascHouse.innerHTML || ascHouse.innerHTML === '')) ascHouse.innerHTML = '①';
                    if (ascHouseVal && (!ascHouseVal.innerHTML || ascHouseVal.innerHTML === '')) ascHouseVal.innerHTML = '0°00\'';
                    
                    console.log('Ephemeris tables updated');
                }, 300); // Wait 300ms for revolve to complete
            }
            function updateStarMapViewRotation() {
                const { date } = state;
                const totalMinutes = date.getHours() * 60 + date.getMinutes();
                const startOfYear = new Date(date.getFullYear(), 0, 0);
                const dayOfYear = Math.floor((date - startOfYear) / (1000 * 60 * 60 * 24));
                const dateAngle = (dayOfYear / 365.25) * 360 + 180;
                const timeAngle = (totalMinutes / 1440) * 360;
                const combinedAngle = dateAngle - timeAngle;
                horizonGroup.setAttribute('transform', `rotate(${combinedAngle} 500 500)`);
            }
            function createStar(cx, cy, r) { const star = document.createElementNS(svgNS, 'circle'); star.setAttribute('cx', cx); star.setAttribute('cy', cy); star.setAttribute('r', r); star.setAttribute('fill', 'white'); return star; }
            function drawBackgroundStars(count = 300) { for (let i = 0; i < count; i++) { const angle = Math.random() * 2 * Math.PI; const radius = Math.sqrt(Math.random()) * starFieldRadius; const x = starMapCenter.x + radius * Math.cos(angle); const y = starMapCenter.y + radius * Math.sin(angle); const size = Math.random() * 1.5 + 0.5; const opacity = Math.random() * 0.7 + 0.3; const star = document.createElementNS(svgNS, 'circle'); star.setAttribute('cx', x); star.setAttribute('cy', y); star.setAttribute('r', size); star.setAttribute('fill', 'white'); star.setAttribute('fill-opacity', opacity); backgroundStarsContainer.appendChild(star); } }
            function drawEcliptic() { const ecliptic = document.createElementNS(svgNS, 'circle'); ecliptic.setAttribute('cx', starMapCenter.x); ecliptic.setAttribute('cy', starMapCenter.y - 80); ecliptic.setAttribute('r', 405); ecliptic.id = 'ecliptic-path'; eclipticContainer.appendChild(ecliptic); }
            function polarToCartesian(centerX, centerY, radius, angleInDegrees) { const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0; return { x: centerX + (radius * Math.cos(angleInRadians)), y: centerY + (radius * Math.sin(angleInRadians)) }; }
            function drawConstellations() {
                constellationLinesContainer.innerHTML = '';
                constellationStarsAndNamesContainer.innerHTML = '';
                Object.keys(constellationData).forEach(name => {
                    const data = constellationData[name];
                    const starsAndNamesGroup = document.createElementNS(svgNS, 'g');
                    data.lines.forEach(line => {
                        const star1 = data.stars[line[0]];
                        const star2 = data.stars[line[1]];
                        const lineEl = document.createElementNS(svgNS, 'line');
                        lineEl.setAttribute('x1', starMapCenter.x + star1.x);
                        lineEl.setAttribute('y1', starMapCenter.y + star1.y);
                        lineEl.setAttribute('x2', starMapCenter.x + star2.x);
                        lineEl.setAttribute('y2', starMapCenter.y + star2.y);
                        lineEl.classList.add('constellation-line');
                        constellationLinesContainer.appendChild(lineEl);
                    });
                    data.stars.forEach(star => {
                        const size = (6 - star.mag) * 1.2;
                        const starEl = createStar(starMapCenter.x + star.x, starMapCenter.y + star.y, size > 1 ? size : 1);
                        if (star.mag < 1.0) starEl.classList.add('star-glow-strong');
                        else if (star.mag < 2.0) starEl.classList.add('star-glow-medium');
                        starsAndNamesGroup.appendChild(starEl);
                        const text = document.createElementNS(svgNS, 'text');
                        text.setAttribute('x', starMapCenter.x + star.x + 8);
                        text.setAttribute('y', starMapCenter.y + star.y - 8);
                        text.textContent = star.name;
                        text.classList.add('star-name-label');
                        starsAndNamesGroup.appendChild(text);
                    });
                    const avgX = data.stars.reduce((acc, s) => acc + s.x, 0) / data.stars.length;
                    const avgY = data.stars.reduce((acc, s) => acc + s.y, 0) / data.stars.length;
                    const nameText = document.createElementNS(svgNS, 'text');
                    nameText.setAttribute('x', starMapCenter.x + avgX);
                    nameText.setAttribute('y', starMapCenter.y + avgY);
                    nameText.textContent = name.toUpperCase();
                    nameText.classList.add('constellation-name');
                    starsAndNamesGroup.appendChild(nameText);
                    constellationStarsAndNamesContainer.appendChild(starsAndNamesGroup);
                });
            }
            function drawDeepSkyObjects() {
                const galaxyGroup = document.createElementNS(svgNS, 'g');
                const andromeda = document.createElementNS(svgNS, 'ellipse');
                andromeda.setAttribute('cx', starMapCenter.x - 320);
                andromeda.setAttribute('cy', starMapCenter.y - 280);
                andromeda.setAttribute('rx', 20);
                andromeda.setAttribute('ry', 8);
                andromeda.setAttribute('fill', 'url(#galaxy-gradient)');
                andromeda.setAttribute('transform', 'rotate(-35, 180, 220)');
                galaxyGroup.appendChild(andromeda);

                const text = document.createElementNS(svgNS, 'text');
                text.setAttribute('x', starMapCenter.x - 320);
                text.setAttribute('y', starMapCenter.y - 305);
                text.textContent = 'Andromeda Galaksisi';
                text.classList.add('dso-label');
                galaxyGroup.appendChild(text);
                deepSkyObjectsContainer.appendChild(galaxyGroup);
            }
            function drawStaticRings() { 
                ringsGroup.innerHTML = '';
                const center = {x: 500, y: 500};
                const monthOuterRadius = 495;
                const dayOuterRadius = 465;
                const timeOuterRadius = 435; 

                const ringClasses = ['ring-stroke-month', 'ring-stroke-day', 'ring-stroke-time'];
                [monthOuterRadius, dayOuterRadius, timeOuterRadius].forEach((r, i) => {
                    const circle = document.createElementNS(svgNS, 'circle');
                    circle.setAttribute('cx', center.x);
                    circle.setAttribute('cy', center.y);
                    circle.setAttribute('r', r);
                    circle.setAttribute('fill', 'none');
                    circle.setAttribute('stroke-width', '1.5');
                    circle.classList.add(ringClasses[i]);
                    ringsGroup.appendChild(circle);
                });

                const monthRadius = (monthOuterRadius + dayOuterRadius) / 2;
                const dayRadius = (dayOuterRadius + timeOuterRadius) / 2;
               
                const months = ["OCAK", "ŞUBAT", "MART", "NİSAN", "MAYIS", "HAZİRAN", "TEMMUZ", "AĞUSTOS", "EYLÜL", "EKİM", "KASIM", "ARALIK"];
                const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                
                const monthSegmentInnerRadius = dayOuterRadius;
                const monthSegmentOuterRadius = monthOuterRadius;
                let currentDay = 0;
                months.forEach((month, i) => {
                    const startAngle = (currentDay / 365.25) * 360;
                    const endAngle = ((currentDay + daysInMonth[i]) / 365.25) * 360;
                    const start = polarToCartesian(center.x, center.y, monthSegmentOuterRadius, endAngle);
                    const end = polarToCartesian(center.x, center.y, monthSegmentOuterRadius, startAngle);
                    const start2 = polarToCartesian(center.x, center.y, monthSegmentInnerRadius, endAngle);
                    const end2 = polarToCartesian(center.x, center.y, monthSegmentInnerRadius, startAngle);
                    const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
                    const d = [ "M", start.x, start.y, "A", monthSegmentOuterRadius, monthSegmentOuterRadius, 0, largeArcFlag, 0, end.x, end.y, "L", end2.x, end2.y, "A", monthSegmentInnerRadius, monthSegmentInnerRadius, 0, largeArcFlag, 1, start2.x, start2.y, "Z" ].join(" ");
                    const path = document.createElementNS(svgNS, 'path');
                    path.setAttribute("d", d);
                    path.setAttribute("fill", i % 2 === 0 ? "rgba(127, 29, 29, 0.2)" : "rgba(159, 18, 57, 0.2)");
                    ringsGroup.prepend(path);
                    currentDay += daysInMonth[i];
                });

                let dayOfYear = 0;
                months.forEach((month, i) => {
                    const angleDeg = ((dayOfYear + daysInMonth[i] / 2) / 365.25) * 360;
                    const x = center.x + monthRadius * Math.cos((angleDeg - 90) * Math.PI / 180);
                    const y = center.y + monthRadius * Math.sin((angleDeg - 90) * Math.PI / 180);
                    const text = document.createElementNS(svgNS, 'text');
                    text.setAttribute('x', x);
                    text.setAttribute('y', y);
                    text.setAttribute('transform', `rotate(${angleDeg} ${x} ${y})`);
                    text.setAttribute('font-size', '16');
                    text.classList.add('month-text');
                    text.textContent = month;
                    ringsGroup.appendChild(text);

                    for(let d = 1; d <= daysInMonth[i]; d++) {
                        const dayAngleRad = ((dayOfYear + d) / 365.25) * 2 * Math.PI - Math.PI / 2;
                        const isFive = d % 5 === 0;
                        const tickLength = isFive ? 10 : 5;
                        const x1 = center.x + (dayRadius - tickLength / 2) * Math.cos(dayAngleRad);
                        const y1 = center.y + (dayRadius - tickLength / 2) * Math.sin(dayAngleRad);
                        const x2 = center.x + (dayRadius + tickLength / 2) * Math.cos(dayAngleRad);
                        const y2 = center.y + (dayRadius + tickLength / 2) * Math.sin(dayAngleRad);
                        const tick = document.createElementNS(svgNS, 'line');
                        tick.setAttribute('x1', x1);
                        tick.setAttribute('y1', y1);
                        tick.setAttribute('x2', x2);
                        tick.setAttribute('y2', y2);
                        tick.setAttribute('stroke-width', isFive ? '1.5' : '1');
                        tick.classList.add('day-tick');
                        ringsGroup.appendChild(tick);
                        
                        if(isFive) {
                            const dayTextRadius = dayRadius - 14;
                            const textAngleDeg = dayAngleRad * 180 / Math.PI + 90;
                            const tx = center.x + (dayTextRadius) * Math.cos(dayAngleRad);
                            const ty = center.y + (dayTextRadius) * Math.sin(dayAngleRad);
                            const dayText = document.createElementNS(svgNS, 'text');
                            dayText.setAttribute('x', tx);
                            dayText.setAttribute('y', ty);
                            dayText.setAttribute('transform', `rotate(${textAngleDeg} ${tx} ${ty})`);
                            dayText.setAttribute('font-size', '11');
                            dayText.classList.add('day-text');
                            dayText.textContent = d;
                            ringsGroup.appendChild(dayText);
                        }
                    }
                    dayOfYear += daysInMonth[i];
                });
            }
            function drawTimeRing() { timeRingContainer.innerHTML = ''; const timeOuterRadius = 435; const starMapInnerRadius = 400; const ringMask = document.createElementNS(svgNS, 'path'); ringMask.id = "time-ring-mask-path"; ringMask.setAttribute('d', ` M ${starMapCenter.x - timeOuterRadius}, ${starMapCenter.y} A ${timeOuterRadius},${timeOuterRadius} 0 1,0 ${starMapCenter.x + timeOuterRadius},${starMapCenter.y} A ${timeOuterRadius},${timeOuterRadius} 0 1,0 ${starMapCenter.x - timeOuterRadius},${starMapCenter.y} Z M ${starMapCenter.x - starMapInnerRadius}, ${starMapCenter.y} A ${starMapInnerRadius},${starMapInnerRadius} 0 1,1 ${starMapCenter.x + starMapInnerRadius},${starMapCenter.y} A ${starMapInnerRadius},${starMapInnerRadius} 0 1,1 ${starMapCenter.x - starMapInnerRadius},${starMapCenter.y} Z `); ringMask.setAttribute('fill', '#0a0a0a'); ringMask.setAttribute('fill-opacity', '0.9'); ringMask.setAttribute('fill-rule', 'evenodd'); timeRingContainer.appendChild(ringMask); const timeRadius = (timeOuterRadius + starMapInnerRadius) / 2; for (let h = 0; h < 24; h++) { for (let m = 0; m < 60; m += 10) { const totalMinutes = h * 60 + m; const angleDeg = (totalMinutes / 1440) * 360; const angleRad = (angleDeg - 90) * Math.PI / 180; let tickLength; if (m === 0) { tickLength = 15; const x = starMapCenter.x + timeRadius * Math.cos(angleRad); const y = starMapCenter.y + timeRadius * Math.sin(angleRad); const text = document.createElementNS(svgNS, 'text'); text.setAttribute('x', x); text.setAttribute('y', y); text.setAttribute('transform', `rotate(${angleDeg} ${x} ${y})`); text.textContent = `${(24 - h) % 24}:00`; text.setAttribute('font-size', '14'); text.classList.add('time-text'); timeRingContainer.appendChild(text); } else if (m === 30) { tickLength = 10; } else { tickLength = 5; } const x1 = starMapCenter.x + starMapInnerRadius * Math.cos(angleRad); const y1 = starMapCenter.y + starMapInnerRadius * Math.sin(angleRad); const x2 = starMapCenter.x + (starMapInnerRadius + tickLength) * Math.cos(angleRad); const y2 = starMapCenter.y + (starMapInnerRadius + tickLength) * Math.sin(angleRad); const tick = document.createElementNS(svgNS, 'line'); tick.setAttribute('x1', x1); tick.setAttribute('y1', y1); tick.setAttribute('x2', x2); tick.setAttribute('y2', y2); tick.setAttribute('stroke-width', (m === 0) ? '2' : '1'); tick.classList.add('time-text'); timeRingContainer.appendChild(tick); } } }
            function toggleUiElements(show) {
                const displayValue = show ? '' : 'none';
                // Only toggle star-related elements, not calendars
                document.querySelectorAll('.star-name-label, .constellation-name, .planet-label, .dso-label, .direction-text').forEach(el => el.style.display = displayValue);
                document.getElementById('rings-group').style.display = displayValue;
                document.getElementById('ecliptic-container').style.display = displayValue;
                
                // Calendars should always be visible - don't toggle them
                // document.getElementById('full-datetime-display').style.display = displayValue;
                // document.getElementById('other-calendars-display').style.display = displayValue;
                // document.getElementById('ephemeris-container').style.display = displayValue;

                const timeRingChildren = document.getElementById('time-ring-container').children;
                for(let child of timeRingChildren) {
                    if (child.id !== 'time-ring-mask-path') {
                        child.style.display = displayValue;
                    }
                }
            }
            
            // Add function to handle astrolabe view
            function toggleAstrolabeView(showAstrolabe) {
                const starMapGroup = document.getElementById('star-map-group');
                const astrolabeContainer = document.querySelector('.astrolabe-container');
                const starChartContainer = document.querySelector('.star-chart-container');
                
                if (showAstrolabe) {
                    // Hide star map elements
                    if (starMapGroup) {
                        starMapGroup.style.display = 'none';
                    }
                    if (starChartContainer) {
                        starChartContainer.style.display = 'none';
                    }
                    // Show astrolabe elements (if they exist)
                    if (astrolabeContainer) {
                        astrolabeContainer.style.display = 'block';
                    }
                    
                    // Update astrolabe when switching to astrolabe view
                    if (typeof jd_from_array === 'function') {
                    jd_local = jd_from_array([
                        state.date.getUTCFullYear(), 
                        state.date.getUTCMonth() + 1, 
                        state.date.getUTCDate(), 
                        state.date.getUTCHours(), 
                        state.date.getUTCMinutes(), 
                        state.date.getUTCSeconds()
                    ]);
                        
                        // Update Julian Day and LMST first
                        const julianDayLocalElem = document.getElementById("julian_day_local");
                        const julianDayElem = document.getElementById("julian_day");
                        if (julianDayLocalElem) julianDayLocalElem.innerHTML = jd_local;
                        if (julianDayElem) julianDayElem.innerHTML = jd_local;
                        
                        // Use cosmic_update for complete astrolabe update
                        if (typeof cosmic_update === 'function') {
                            console.log('🌌 Updating astrolabe on view switch with cosmic_update');
                            
                            // Debug: check if rotate_rete function is available
                            console.log('🌌 rotate_rete function available:', typeof rotate_rete === 'function');
                            
                            try {
                                cosmic_update(jd_local);
                                
                                // Additional check: manually call rotate_rete if it exists but wasn't called
                                if (typeof rotate_rete === 'function') {
                                    // Debug LMST values before rotation
                                    const lmstElem = document.getElementById("lmst_span");
                                    const gmstElem = document.getElementById("gmst_span");
                                    console.log('🌌 LMST value (switch):', lmstElem ? lmstElem.innerHTML : 'not found');
                                    console.log('🌌 GMST value (switch):', gmstElem ? gmstElem.innerHTML : 'not found');
                                    
                                    console.log('🌌 Manually calling rotate_rete after view switch');
                                    rotate_rete();
                                }
                                
                                // Update ephemeris tables after cosmic_update
                                setTimeout(() => {
                                    updateEphemerisTables();
                                }, 100);
                            } catch (error) {
                                console.error('Error updating astrolabe on view switch:', error);
                            }
                        } else {
                            if (typeof update_text_from_local === 'function') {
                                console.log('🌌 Updating LMST on astrolabe view switch');
                                try {
                                    update_text_from_local(jd_local);
                                } catch (error) {
                                    console.error('Error updating LMST on view switch:', error);
                                }
                            }
                            
                            if (typeof planet_advance === 'function') {
                                console.log('🌌 Updating astrolabe on view switch');
                                try {
                                    planet_advance();
                                } catch (error) {
                                    console.error('Error updating astrolabe on view switch:', error);
                                }
                            }
                        }
                    }
                } else {
                    // Show star map elements
                    if (starMapGroup) {
                        starMapGroup.style.display = 'block';
                    }
                    if (starChartContainer) {
                        starChartContainer.style.display = 'block';
                    }
                    // Hide astrolabe elements (if they exist)
                    if (astrolabeContainer) {
                        astrolabeContainer.style.display = 'none';
                    }
                }
            }
            function updateEphemerisAndPlanets(dayOfYear) { 
                const getZodiacInfo = (angle) => { 
                    const normalizedAngle = (angle + 360) % 360; 
                    let signInfo = {}; 
                    for (let i = zodiacSigns.length - 1; i >= 0; i--) { 
                        if (normalizedAngle >= zodiacSigns[i].start) { 
                            signInfo = zodiacSigns[i]; 
                            break; 
                        } 
                    } 
                    const angleInSign = normalizedAngle - signInfo.start; 
                    return { 
                        signSymbol: signInfo.symbol, 
                        degrees: Math.floor(angleInSign), 
                        minutes: Math.floor((angleInSign - Math.floor(angleInSign)) * 60) 
                    }; 
                }; 
                
                const vernalEquinoxDay = 80; 
                const daysSinceEquinox = dayOfYear - vernalEquinoxDay; 
                planetsContainer.innerHTML = ''; 
                const eclipticCenter = { x: 500, y: 420 }; 
                const eclipticRadius = 405; 
                
                Object.keys(movingBodiesData).forEach(name => { 
                    const body = movingBodiesData[name]; 
                    let angleDeg = (body.baseAngle + daysSinceEquinox * (360 / body.period)) % 360; 
                    if (name === "Güneş") { 
                        angleDeg = (daysSinceEquinox / 365.25 * 360) % 360; 
                    } 
                    
                    const angleRad = (angleDeg - 90) * Math.PI / 180; 
                    const x = eclipticCenter.x + eclipticRadius * Math.cos(angleRad); 
                    const y = eclipticCenter.y + eclipticRadius * Math.sin(angleRad); 
                    
                    const bodyGroup = document.createElementNS(svgNS, 'g'); 
                    const bodyCircle = document.createElementNS(svgNS, 'circle'); 
                    bodyCircle.setAttribute('cx', x); 
                    bodyCircle.setAttribute('cy', y); 
                    bodyCircle.setAttribute('r', name === 'Güneş' ? 8 : (name === 'Ay' ? 7 : 6)); 
                    bodyCircle.setAttribute('fill', body.color); 
                    bodyCircle.classList.add('planet'); 
                    bodyCircle.style.color = body.color; 
                    
                    const bodyLabel = document.createElementNS(svgNS, 'text'); 
                    bodyLabel.setAttribute('x', x); 
                    bodyLabel.setAttribute('y', y - 15); 
                    bodyLabel.textContent = name; 
                    bodyLabel.classList.add('planet-label'); 
                    bodyLabel.style.color = body.color; 
                    
                    bodyGroup.appendChild(bodyCircle); 
                    bodyGroup.appendChild(bodyLabel); 
                    planetsContainer.appendChild(bodyGroup); 
                }); 
                
                // The ephemeris-content element was removed, so we don't try to update it
                // The ephemeris tables are now updated separately via updateEphemerisTables()
            }

            // Function to load head SVG (prevents loading indicator)
            function loadHeadSvg(language) {
                // Determine language folder
                let languageFolder = '';
                switch(language) {
                    case 'arabic':
                        languageFolder = '../differences_output/arapca_farkli';
                        break;
                    case 'turkish':
                        languageFolder = '../differences_output/turkce_farkli';
                        break;
                    case 'latin':
                        languageFolder = '../differences_output/latince_farkli';
                        break;
                    default:
                        languageFolder = '../differences_output/latince_farkli';
                }
                
                const headSvgPath = languageFolder + '/head.svg';
                console.log('Loading head SVG for language:', language, 'from:', headSvgPath);
                
                // Find head group element
                const headGroup = document.getElementById('headGroup');
                if (!headGroup) {
                    console.error('Head group not found');
                    return;
                }
                
                // Clear previous content
                headGroup.innerHTML = '';
                
                // Load SVG content directly
                fetch(headSvgPath)
                    .then(response => response.text())
                    .then(svgText => {
                        // Parse SVG
                        const parser = new DOMParser();
                        const svgDoc = parser.parseFromString(svgText, 'image/svg+xml');
                        const svgElement = svgDoc.documentElement;
                        
                        if (svgElement) {
                            // Get viewBox to calculate scaling  
                            const viewBox = svgElement.getAttribute('viewBox');
                            if (viewBox) {
                                const [minX, minY, width, height] = viewBox.split(' ').map(Number);
                                console.log('Head SVG viewBox:', {minX, minY, width, height});
                                
                                // Copy style information first
                                const styleElement = svgElement.querySelector('style');
                                if (styleElement) {
                                    const astrolabeSvg = document.getElementById('svg_astrolabe');
                                    const existingDefs = astrolabeSvg.querySelector('defs');
                                    if (existingDefs && !existingDefs.querySelector('style[data-head-styles]')) {
                                        const clonedStyle = styleElement.cloneNode(true);
                                        clonedStyle.setAttribute('data-head-styles', 'true');
                                        existingDefs.appendChild(clonedStyle);
                                    }
                                }
                                
                                // Get content group - original group or SVG itself
                                const g = svgElement.querySelector('g') || svgElement;
                                
                                // Scale factor - same as index.html now that viewBox is corrected
                                const scaleFactor = language === 'arabic' ? 0.2 : 0.008;
                                
                                // Y offset to place above limb - same as index.html
                                const yOffset = language === 'arabic' ? 30 : 107;
                                
                                console.log('Head transform params:', {scaleFactor, yOffset});
                                
                                // Clone the entire group (with classes)
                                const clonedGroup = g.cloneNode(true);
                                
                                // Apply group transform - rotate 180 degrees (because Y axis is flipped)
                                const currentTransform = clonedGroup.getAttribute('transform') || '';
                                clonedGroup.setAttribute('transform', 
                                    `translate(0, ${yOffset}) scale(${scaleFactor}) rotate(180) translate(${-width/2}, ${-height/2}) ${currentTransform}`);
                                
                                headGroup.appendChild(clonedGroup);
                                
                                console.log('Head SVG successfully loaded');
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Error loading head SVG:', error);
                        // Add a simple placeholder
                        headGroup.innerHTML = '<circle cx="0" cy="0" r="1" fill="none"/>';
                    });
            }

            // --- INITIALIZE ---
            function initialize() {
                // Always initialize star chart first
                drawBackgroundStars();
                drawEcliptic();
                
                drawConstellations();
                drawDeepSkyObjects();
                drawStaticRings();
                drawTimeRing();
                
                // Initialize astrolabe date/time elements with current state
                const localYearElem = document.getElementById("local_year");
                const localMonthElem = document.getElementById("local_month");
                const localDayElem = document.getElementById("local_day");
                const localHourElem = document.getElementById("local_hour");
                const localMinutesElem = document.getElementById("local_minutes");
                const localSecondsElem = document.getElementById("local_seconds");
                const latitudeElem = document.getElementById("latitude");
                const longitudeElem = document.getElementById("longitude");
                
                if (localYearElem) localYearElem.innerHTML = state.date.getFullYear();
                if (localMonthElem) localMonthElem.innerHTML = state.date.getMonth() + 1;
                if (localDayElem) localDayElem.innerHTML = state.date.getDate();
                if (localHourElem) localHourElem.innerHTML = state.date.getHours();
                if (localMinutesElem) localMinutesElem.innerHTML = state.date.getMinutes();
                if (localSecondsElem) localSecondsElem.innerHTML = state.date.getSeconds();
                if (latitudeElem) latitudeElem.innerHTML = state.latitude;
                if (longitudeElem) longitudeElem.innerHTML = 35; // Default longitude for Turkey
                
                // Global variable for Julian Day
                let jd_local = 0;
                
                    // Calculate initial Julian Day for astrolabe
                    if (typeof jd_from_array === 'function') {
                        jd_local = jd_from_array([
                            state.date.getUTCFullYear(), 
                            state.date.getUTCMonth() + 1, 
                            state.date.getUTCDate(), 
                            state.date.getUTCHours(), 
                            state.date.getUTCMinutes(), 
                            state.date.getUTCSeconds()
                        ]);
                        
                        const julianDayLocalElem = document.getElementById("julian_day_local");
                        const julianDayElem = document.getElementById("julian_day");
                        
                        if (julianDayLocalElem) julianDayLocalElem.innerHTML = jd_local;
                        if (julianDayElem) julianDayElem.innerHTML = jd_local;
                        
                        console.log('🌌 Initialized astrolabe Julian Day:', jd_local);
                        
                        // Initialize LMST and astrolabe using cosmic_update
                    if (typeof cosmic_update === 'function') {
                        console.log('🌌 Initializing astrolabe with cosmic_update');
                        
                        // Debug: check if rotate_rete function is available
                        console.log('🌌 rotate_rete function available:', typeof rotate_rete === 'function');
                        
                        try {
                            cosmic_update(jd_local);
                            
                            // Additional check: manually call rotate_rete if it exists but wasn't called
                            if (typeof rotate_rete === 'function') {
                                // Debug LMST values before rotation
                                const lmstElem = document.getElementById("lmst_span");
                                const gmstElem = document.getElementById("gmst_span");
                                console.log('🌌 LMST value (init):', lmstElem ? lmstElem.innerHTML : 'not found');
                                console.log('🌌 GMST value (init):', gmstElem ? gmstElem.innerHTML : 'not found');
                                
                                console.log('🌌 Manually calling rotate_rete after initialization');
                                rotate_rete();
                            }
                            
                            // Update ephemeris tables after cosmic_update
                            setTimeout(() => {
                                updateEphemerisTables();
                            }, 100);
                            
                            // Load head SVG to prevent loading indicator
                            loadHeadSvg('turkish');
                            
                            // Initialize astrolabe to current date/time like index.html
                            if (typeof now_button_pressed === 'function') {
                                console.log('🌌 Calling now_button_pressed() for proper initialization');
                                now_button_pressed();
                            }
                        } catch (error) {
                            console.error('Error initializing with cosmic_update:', error);
                        }
                    } else if (typeof update_text_from_local === 'function') {
                        console.log('🌌 Initializing LMST and time elements');
                        try {
                            update_text_from_local(jd_local);
                        } catch (error) {
                            console.error('Error initializing text from local:', error);
                        }
                    }
                }
                
                updateAllViews();
                
                // Start Ultra-Fast Local P2P sync first, then WebSocket as fallback
                if (typeof AstrolabeCommon !== 'undefined') {
                    const sessionKey = AstrolabeCommon.getSessionKey();
                    console.log('Display using session:', sessionKey);
                    
                    // Ultra-Fast Local P2P sync
                    let localSync = null;
                    let localSyncActive = false;
                    
                    // WebSocket connection for real-time updates (fallback)
                    let ws = null;
                    let wsConnected = false;
                    let reconnectInterval = null;
                    let heartbeatInterval = null;
                    
                    function updateDisplayConnectionStatus(status) {
                        const wsStatus = document.getElementById('ws-status-display');
                        const wsIndicator = document.getElementById('ws-indicator-display');
                        const wsText = document.getElementById('ws-text-display');
                        
                        if (!wsStatus || !wsIndicator || !wsText) return;
                        
                        switch (status) {
                            case 'local_p2p':
                                wsStatus.className = 'mt-2 px-2 py-1 rounded-md text-xs font-medium text-center transition-all duration-300 bg-purple-900/30 border border-purple-400/40';
                                wsIndicator.className = 'w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse';
                                wsText.textContent = '⚡ Ultra-Fast P2P';
                                break;
                            case 'connected':
                                wsStatus.className = 'mt-2 px-2 py-1 rounded-md text-xs font-medium text-center transition-all duration-300 bg-green-900/30 border border-green-600/40';
                                wsIndicator.className = 'w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse';
                                wsText.textContent = '🚀 Canlı Sync';
                                break;
                            case 'disconnected':
                                wsStatus.className = 'mt-2 px-2 py-1 rounded-md text-xs font-medium text-center transition-all duration-300 bg-red-900/30 border border-red-600/40';
                                wsIndicator.className = 'w-1.5 h-1.5 rounded-full bg-red-400';
                                wsText.textContent = '❌ Bağlantı Yok';
                                break;
                            case 'reconnecting':
                                wsStatus.className = 'mt-2 px-2 py-1 rounded-md text-xs font-medium text-center transition-all duration-300 bg-yellow-900/30 border border-yellow-600/40';
                                wsIndicator.className = 'w-1.5 h-1.5 rounded-full bg-yellow-400 animate-bounce';
                                wsText.textContent = '🔄 Bağlanıyor...';
                                break;
                            case 'http_fallback':
                                wsStatus.className = 'mt-2 px-2 py-1 rounded-md text-xs font-medium text-center transition-all duration-300 bg-orange-900/30 border border-orange-600/40';
                                wsIndicator.className = 'w-1.5 h-1.5 rounded-full bg-orange-400';
                                wsText.textContent = '⚠️ HTTP Sync';
                                break;
                            default:
                                wsStatus.className = 'mt-2 px-2 py-1 rounded-md text-xs font-medium text-center transition-all duration-300 bg-gray-900/30 border border-gray-600/40';
                                wsIndicator.className = 'w-1.5 h-1.5 rounded-full bg-gray-500 animate-pulse';
                                wsText.textContent = 'Bağlanıyor...';
                        }
                    }
                    
                    function initDisplayLocalSync() {
                        try {
                            console.log('🔍 Checking BroadcastChannel support:', !!window.BroadcastChannel);
                            console.log('🔍 LocalAstrolabeSync available:', typeof LocalAstrolabeSync);
                            
                            localSync = new LocalAstrolabeSync('display');
                            
                            // Listen for updates from control
                            localSync.on('astrolabe_update', (data) => {
                                console.log('⚡ Ultra-fast P2P update received:', data);
                                handleRealTimeUpdate(data);
                            });
                            
                            // Listen for screenshot requests from control panel
                            localSync.on('request_screenshot', async (data) => {
                                console.log('📷 Screenshot requested from control panel');
                                const screenshots = await window.captureAstrolabeScreenshot();
                                if (screenshots) {
                                    console.log('✅ Screenshots captured and sent');
                                }
                            });
                            
                            // Check connection status
                            const status = localSync.getConnectionStatus();
                            console.log('🚀 Display Local P2P Status:', status);
                            
                            if (status.broadcastChannel && status.ultraFastMode) {
                                localSyncActive = true;
                                updateConnectionStatus('p2p');
                                console.log('✅ Display Local P2P sync active - ultra-fast mode!');
                            } else {
                                console.log('⚠️ P2P not active. Status:', status);
                                localSyncActive = false;
                            }
                            
                        } catch (error) {
                            console.error('❌ Display Local P2P sync failed:', error);
                            localSyncActive = false;
                        }
                    }
                    
                    function updateConnectionStatus(status) {
                        const statusIndicator = document.getElementById('status-indicator');
                        const statusText = document.getElementById('status-text');
                        
                        if (!statusIndicator || !statusText) return;
                        
                        // Remove all status classes
                        statusIndicator.className = '';
                        statusIndicator.classList.add('status-indicator');
                        
                        switch (status) {
                            case 'p2p':
                                statusIndicator.classList.add('status-p2p');
                                statusText.textContent = 'P2P';
                                break;
                            case 'http':
                                statusIndicator.classList.add('status-http');
                                statusText.textContent = 'HTTP';
                                break;
                            case 'disconnected':
                            default:
                                statusIndicator.classList.add('status-disconnected');
                                statusText.textContent = 'OFFLINE';
                        }
                    }
                    
                    function initDisplayWebSocket() {
                        try {
                            ws = new WebSocket('ws://localhost:8080');
                            
                            ws.onopen = function() {
                                wsConnected = true;
                                console.log('🔗 Display WebSocket connected');
                                updateConnectionStatus('http');
                                
                                // Join session as display client
                                ws.send(JSON.stringify({
                                    type: 'join_session',
                                    sessionKey: sessionKey,
                                    clientType: 'display'
                                }));
                                
                                // Start heartbeat
                                startDisplayHeartbeat();
                                
                                // Clear reconnect interval if was trying to reconnect
                                if (reconnectInterval) {
                                    clearInterval(reconnectInterval);
                                    reconnectInterval = null;
                                }
                            };
                            
                            ws.onmessage = function(event) {
                                try {
                                    const message = JSON.parse(event.data);
                                    console.log('📨 Display WebSocket received:', message.type);
                                    
                                    switch (message.type) {
                                        case 'welcome':
                                        case 'session_joined':
                                            console.log('✅ Display joined session successfully');
                                            break;
                                        case 'pong':
                                            // Heartbeat response
                                            break;
                                        case 'astrolabe_update':
                                            // Real-time update from control client
                                            console.log('🚀 Real-time update received from control');
                                            handleRealTimeUpdate(message.data);
                                            break;
                                    }
                                } catch (e) {
                                    console.error('Failed to parse WebSocket message:', e);
                                }
                            };
                            
                            ws.onclose = function() {
                                wsConnected = false;
                                console.log('❌ Display WebSocket disconnected');
                                updateConnectionStatus('disconnected');
                                stopDisplayHeartbeat();
                                attemptDisplayReconnect();
                            };
                            
                            ws.onerror = function(error) {
                                console.error('❌ Display WebSocket error:', error);
                                updateDisplayConnectionStatus('disconnected');
                            };
                            
                        } catch (error) {
                            console.error('❌ Failed to create Display WebSocket:', error);
                            attemptDisplayReconnect();
                        }
                    }
                    
                    function attemptDisplayReconnect() {
                        if (!reconnectInterval) {
                            console.log('🔄 Display attempting to reconnect...');
                            updateDisplayConnectionStatus('reconnecting');
                            
                            reconnectInterval = setInterval(() => {
                                if (!wsConnected) {
                                    console.log('🔄 Display reconnecting to WebSocket...');
                                    initDisplayWebSocket();
                                }
                            }, 3000);
                        }
                    }
                    
                    function startDisplayHeartbeat() {
                        heartbeatInterval = setInterval(() => {
                            if (ws && ws.readyState === WebSocket.OPEN) {
                                ws.send(JSON.stringify({
                                    type: 'ping',
                                    timestamp: Date.now()
                                }));
                            }
                        }, 30000); // Every 30 seconds
                    }
                    
                    function stopDisplayHeartbeat() {
                        if (heartbeatInterval) {
                            clearInterval(heartbeatInterval);
                            heartbeatInterval = null;
                        }
                    }
                    
                    function handleRealTimeUpdate(data) {
                        console.log('🔄 Processing real-time update:', data);
                        
                        // Stop any running now() interval when control panel sends data
                        if (typeof interval1 !== 'undefined' && interval1) {
                            clearInterval(interval1);
                            interval1 = null;
                            console.log('🛑 Stopped now() auto-update interval');
                        }
                        
                        // Clear active state from now button
                        if (typeof $ !== 'undefined') {
                            $(".panel_button_inner").removeClass("button_active_background").addClass("button_inactive_background");
                            $(".panel_button_outer").removeClass("button_active_rim").addClass("button_inactive_rim");
                            $(".button_icon").removeClass("active");
                            // Activate stop button to show manual control
                            $("#stop_button_group > .panel_button_inner").removeClass("button_inactive_background").addClass("button_active_background");
                            $("#stop_button_group > .panel_button_outer").removeClass("button_inactive_rim").addClass("button_active_rim");
                            $("#stop_button_group > .button_icon").addClass("active");
                        }
                        
                        // Mark last update time
                        window.lastRealTimeUpdate = Date.now();
                        
                        // Note: Allow all dates - astrolabe works for historical and future dates
                        console.log('📅 Accepting date update for any time period');
                        
                        // Update interaction display with date/time
                        const interactionDateEl = document.getElementById('interaction-date');
                        const interactionTimeEl = document.getElementById('interaction-time');
                        const interactionDisplay = document.getElementById('interaction-datetime-display');
                        
                        // Update date/time from individual fields
                        if (data.local_year && data.local_month && data.local_day) {
                            // Parse hour properly - handle both number and string
                            const hour = typeof data.local_hour === 'string' ? parseInt(data.local_hour, 10) : (data.local_hour || 0);
                            const minute = typeof data.local_minute === 'string' ? parseInt(data.local_minute, 10) : (data.local_minute || 0);
                            const second = typeof data.local_second === 'string' ? parseInt(data.local_second, 10) : (data.local_second || 0);
                            
                            const newDate = new Date(
                                parseInt(data.local_year),
                                parseInt(data.local_month) - 1,
                                parseInt(data.local_day),
                                hour,
                                minute,
                                second
                            );
                            state.date = newDate;
                            console.log('📅 Real-time updated date:', newDate.toLocaleString('tr-TR'));
                            
                            // Show interaction display with updated date/time
                            if (interactionDateEl && interactionTimeEl && interactionDisplay) {
                                const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 
                                               'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
                                
                                const dateText = `${newDate.getDate()} ${months[newDate.getMonth()]} ${newDate.getFullYear()}`;
                                const timeText = `${String(newDate.getHours()).padStart(2, '0')}:${String(newDate.getMinutes()).padStart(2, '0')}:${String(newDate.getSeconds()).padStart(2, '0')}`;
                                
                                interactionDateEl.textContent = dateText;
                                interactionTimeEl.textContent = timeText;
                                
                                // Show the display briefly
                                interactionDisplay.classList.add('active');
                                
                                // Hide after 3 seconds
                                setTimeout(() => {
                                    interactionDisplay.classList.remove('active');
                                }, 3000);
                            }
                            
                            // Update astrolabe date elements if they exist
                            const localYearElem = document.getElementById("local_year");
                            const localMonthElem = document.getElementById("local_month");
                            const localDayElem = document.getElementById("local_day");
                            const localHourElem = document.getElementById("local_hour");
                            const localMinutesElem = document.getElementById("local_minutes");
                            const localSecondsElem = document.getElementById("local_seconds");
                            
                            if (localYearElem) localYearElem.innerHTML = parseInt(data.local_year);
                            if (localMonthElem) localMonthElem.innerHTML = parseInt(data.local_month);
                            if (localDayElem) localDayElem.innerHTML = parseInt(data.local_day);
                            if (localHourElem) localHourElem.innerHTML = hour;
                            if (localMinutesElem) localMinutesElem.innerHTML = minute;
                            if (localSecondsElem) localSecondsElem.innerHTML = second;
                            
                            // Calculate Julian Day for astrolabe
                            if (typeof jd_from_array === 'function') {
                                // Convert local time to UTC for correct astronomical calculations
                                const localDateTime = new Date(
                                    parseInt(data.local_year),
                                    parseInt(data.local_month) - 1,
                                    parseInt(data.local_day),
                                    hour,
                                    minute,
                                    second
                                );
                                const utcYear = localDateTime.getUTCFullYear();
                                const utcMonth = localDateTime.getUTCMonth() + 1;
                                const utcDay = localDateTime.getUTCDate();
                                const utcHour = localDateTime.getUTCHours();
                                const utcMin = localDateTime.getUTCMinutes();
                                const utcSec = localDateTime.getUTCSeconds();
                                jd_local = jd_from_array([
                                    utcYear,
                                    utcMonth,
                                    utcDay,
                                    utcHour,
                                    utcMin,
                                    utcSec
                                ]);

                                const julianDayLocalElem = document.getElementById("julian_day_local");
                                const julianDayElem = document.getElementById("julian_day");
                                
                                if (julianDayLocalElem) julianDayLocalElem.innerHTML = jd_local;
                                if (julianDayElem) julianDayElem.innerHTML = jd_local;
                                
                                console.log('🌌 Real-time Updated Julian Day:', jd_local);
                                
                                // Update LMST and astrolabe using cosmic_update - same as index.html
                                if (typeof cosmic_update === 'function') {
                                    console.log('🌌 Real-time updating astrolabe with cosmic_update');
                                    
                                    // Debug: check if rotate_rete function is available
                                    console.log('🌌 rotate_rete function available:', typeof rotate_rete === 'function');
                                    
                                    try {
                                        cosmic_update(jd_local);
                                        console.log('🌌 Real-time cosmic_update completed');
                                        
                                        // Additional check: manually call rotate_rete if it exists but wasn't called
                                        if (typeof rotate_rete === 'function') {
                                            // Debug LMST values before rotation
                                            const lmstElem = document.getElementById("lmst_span");
                                            const gmstElem = document.getElementById("gmst_span");
                                            console.log('🌌 LMST value:', lmstElem ? lmstElem.innerHTML : 'not found');
                                            console.log('🌌 GMST value:', gmstElem ? gmstElem.innerHTML : 'not found');
                                            
                                            // Also check latitude and longitude values
                                            const latElem = document.getElementById("latspan");
                                            const lonElem = document.getElementById("lonspan");
                                            console.log('🌌 Latitude:', latElem ? latElem.textContent : 'not found');
                                            console.log('🌌 Longitude:', lonElem ? lonElem.textContent : 'not found');
                                            
                                            console.log('🌌 Manually calling rotate_rete as backup');
                                            
                                            // Log rotation calculation
                                            const lmst = Number(document.getElementById("lmst_span").innerHTML);
                                            const rotation = ((270 - lmst) % 360);
                                            console.log('🌌 Calculating rotation: (270 -', lmst, ') % 360 =', rotation.toFixed(4));
                                            
                                            rotate_rete();
                                        }
                                        
                                        // Update ephemeris tables after cosmic_update
                                        setTimeout(() => {
                                            updateEphemerisTables();
                                        }, 100);
                                    } catch (error) {
                                        console.error('Error with real-time cosmic_update:', error);
                                    }
                                } else if (typeof update_text_from_local === 'function') {
                                    console.log('🌌 Real-time updating LMST and time elements');
                                    try {
                                        update_text_from_local(jd_local);
                                    } catch (error) {
                                        console.error('Error updating text from local:', error);
                                    }
                                }
                            }
                        }
                        
                        if (data.latitude !== undefined) {
                            state.latitude = parseInt(data.latitude);
                            // Update latitude element for astrolabe
                            const latitudeElem = document.getElementById("latitude");
                            if (latitudeElem) latitudeElem.innerHTML = state.latitude;
                            
                            // Update hidden slider for compatibility
                            const latitudeSlider = document.getElementById("latitudeSlider");
                            if (latitudeSlider) {
                                latitudeSlider.value = state.latitude;
                                
                                // Trigger astrolabe update like in index.html
                                if (typeof tympanum === 'function') {
                                    tympanum();
                                }
                                if (typeof planet_advance === 'function') {
                                    planet_advance();
                                }
                            }
                        }
                        
                        if (data.show_star_names !== undefined) {
                            state.showStarNames = data.show_star_names;
                        }
                        
                        // Check for astrolabe view state
                        if (data.astrolabe_visible !== undefined) {
                            state.showAstrolabe = data.astrolabe_visible;
                            toggleAstrolabeView(state.showAstrolabe);
                        }
                        
                        // Update the display - only star chart if not in astrolabe mode
                        if (!state.showAstrolabe) {
                            updateAllViews();
                        }
                        
                        console.log('✅ Real-time update processed successfully');
                    }
                    
                    // Initialize Ultra-Fast Local P2P sync first
                    initDisplayLocalSync();
                    
                    // Initialize WebSocket connection as fallback
                    if (!localSyncActive) {
                        initDisplayWebSocket();
                    } else {
                        console.log('⚡ Display Local P2P active, WebSocket disabled for maximum performance');
                        // Don't initialize WebSocket when P2P is working
                    }
                    
                    // Fallback polling system (only if both P2P and WebSocket fail)
                    let fallbackPolling = null;
                    let lastStateHash = '';
                    
                    function startFallbackPolling() {
                        if (fallbackPolling) return; // Already running
                        
                        console.log('🔄 Starting HTTP fallback polling');
                        updateDisplayConnectionStatus('http_fallback');
                        fallbackPolling = setInterval(async () => {
                            if (wsConnected) {
                                // WebSocket is working, stop polling
                                clearInterval(fallbackPolling);
                                fallbackPolling = null;
                                console.log('🚀 WebSocket reconnected, stopping HTTP fallback');
                                return;
                            }
                            
                            try {
                                const serverState = await AstrolabeCommon.fetchState(sessionKey);
                                if (serverState && serverState.state) {
                                    const data = serverState.state;
                                    
                                    // Create hash to detect changes
                                    const currentStateHash = JSON.stringify({
                                        year: data.local_year,
                                        month: data.local_month,
                                        day: data.local_day,
                                        hour: data.local_hour,
                                        minute: data.local_minute,
                                        second: data.local_second,
                                        latitude: data.latitude,
                                        showStarNames: data.show_star_names,
                                        astrolabeVisible: data.astrolabe_visible
                                    });
                                    
                                    // Only update if state has changed
                                    if (currentStateHash !== lastStateHash) {
                                        console.log('📥 HTTP Fallback: State changed, updating display');
                                        lastStateHash = currentStateHash;
                                        handleRealTimeUpdate(data);
                                    }
                                }
                            } catch (error) {
                                console.error('HTTP Fallback error:', error);
                            }
                        }, 2000); // Slower polling as fallback - 2 seconds
                    }
                    
                    // Start fallback polling initially in case WebSocket fails immediately
                    setTimeout(() => {
                        if (!wsConnected && !localSyncActive) {
                            startFallbackPolling();
                        }
                    }, 5000); // Wait 5 seconds before starting fallback (only if P2P also failed)
                }
            }

            initialize();
            
            // Update ephemeris tables after initialization
            setTimeout(() => {
                updateEphemerisTables();
            }, 500);
            
            // Screenshot capture functionality
            window.captureAstrolabeScreenshot = async function() {
                console.log('📸 Starting screenshot capture...');
                
                try {
                    const screenshots = {};
                    
                    // Get both containers
                    const astrolabeContainer = document.querySelector('.astrolabe-container');
                    const starChartContainer = document.querySelector('.star-chart-container');
                    
                    // Store original display states
                    const originalAstrolabeDisplay = astrolabeContainer ? astrolabeContainer.style.display : 'none';
                    const originalStarChartDisplay = starChartContainer ? starChartContainer.style.display : 'none';
                    
                    // Capture star chart (temporarily show if hidden)
                    if (starChartContainer) {
                        console.log('📸 Capturing star chart...');
                        starChartContainer.style.display = 'block';
                        await new Promise(resolve => setTimeout(resolve, 100)); // Wait for render
                        
                        const starChartCanvas = await html2canvas(starChartContainer, {
                            backgroundColor: '#090a0f',
                            scale: 2,
                            logging: false,
                            useCORS: true
                        });
                        screenshots.starChart = starChartCanvas.toDataURL('image/png');
                        
                        // Restore original display state
                        starChartContainer.style.display = originalStarChartDisplay;
                    }
                    
                    // Capture astrolabe (temporarily show if hidden)
                    if (astrolabeContainer) {
                        console.log('📸 Capturing astrolabe...');
                        astrolabeContainer.style.display = 'block';
                        await new Promise(resolve => setTimeout(resolve, 100)); // Wait for render
                        
                        const astrolabeCanvas = await html2canvas(astrolabeContainer, {
                            backgroundColor: '#090a0f',
                            scale: 2,
                            logging: false,
                            useCORS: true
                        });
                        screenshots.astrolabe = astrolabeCanvas.toDataURL('image/png');
                        
                        // Restore original display state
                        astrolabeContainer.style.display = originalAstrolabeDisplay;
                    }
                    
                    // Send screenshots via P2P
                    if (localSync && Object.keys(screenshots).length > 0) {
                        console.log('📤 Sending screenshots via P2P...');
                        localSync.sendBroadcast('screenshot_capture', {
                            screenshots: screenshots,
                            timestamp: Date.now(),
                            sessionKey: sessionKey
                        });
                        return screenshots;
                    }
                    
                    return screenshots;
                    
                } catch (error) {
                    console.error('❌ Screenshot capture failed:', error);
                    return null;
                }
            };
            
        });
    </script>
</body>
</html>
