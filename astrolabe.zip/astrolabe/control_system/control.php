<!DOCTYPE html>
<html lang="tr">
<head>
    <?php
    session_start();
    require_once 'includes/db.php';
    $db = Database::getInstance();
    $db->requireAuth();
    $db->createDefaultAdmin();
    ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yıldız Haritası - Kontrol Paneli</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Play:wght@400;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        @keyframes backgroundPan { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        body {
            font-family: 'Roboto', sans-serif;
            background: radial-gradient(ellipse at bottom, #1b2735 0%, #090a0f 100%) !important;
            color: #e5e7eb;
            overflow: hidden;
            background-size: 250% 250% !important;
            animation: backgroundPan 45s linear infinite;
            touch-action: none;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }
        .controls-card { background: rgba(10, 10, 20, 0.5); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.1); }
        #main-layout { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100vw; 
            height: 100vh; 
            display: flex; 
            flex-direction: row; 
            overflow: hidden;
        }
        
        #right-controls {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 280px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 15px;
            align-items: stretch;
            background: rgba(10, 10, 20, 0.4);
            backdrop-filter: blur(15px);
            border-left: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            z-index: 100;
        }
        
        #controller-area {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            min-height: 0;
            position: relative;
        }
        
        /* Rete background layer */
        .rete-background {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: min(calc(100vh - 40px), calc(100vw - 320px));
            height: min(calc(100vh - 40px), calc(100vw - 320px));
            opacity: 0.5;
            pointer-events: none;
            z-index: 1;
        }
        
        .rete-background svg {
            width: 100%;
            height: 100%;
        }
        
        .rete-background path,
        .rete-background circle,
        .rete-background ellipse,
        .rete-background line,
        .rete-background polygon,
        .rete-background polyline {
            stroke: #b4b4b4 !important;
            fill: none !important;
            stroke-width: 0.3 !important;
        }
        
        .rete-background text {
            display: none !important;
        }
        
        /* Hide star names specifically in rete */
        .rete-background #starnames_textgroup text {
            display: none !important;
        }
        
        /* Hide all text elements in rete layer */
        .rete-background #reteLayer text {
            display: none !important;
        }
        
        /* Hide star names group completely */
        .rete-background #starnames_textgroup {
            display: none !important;
        }
        
        #draggable-controller-wrapper { 
            width: 100%; 
            height: 100%; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            position: relative;
            z-index: 2;
        }
        .controller-container { 
            width: min(calc(100vh - 40px), calc(100vw - 320px)); 
            height: min(calc(100vh - 40px), calc(100vw - 320px)); 
            cursor: grab; 
            position: relative;
            z-index: 2;
        }
        .controller-container:active { cursor: grabbing; }
        .hilal-mask { filter: drop-shadow(0 0 15px rgba(255, 255, 255, 0.7)) drop-shadow(0 0 5px rgba(255, 255, 255, 1)); }
        input[type="range"] { -webkit-appearance: none; appearance: none; width: 100%; height: 6px; background: rgba(255, 255, 255, 0.1); outline: none; border-radius: 3px; }
        input[type="range"]::-webkit-slider-thumb { -webkit-appearance: none; appearance: none; width: 20px; height: 20px; background: #ef4444; cursor: pointer; border-radius: 50%; border: 3px solid #7f1d1d; box-shadow: 0 0 5px #ef4444, 0 0 10px #ef4444; }
        .user-info { position: fixed; top: 20px; right: 20px; padding: 8px 16px; background: rgba(0, 0, 0, 0.7); color: #ffffff; border: 1px solid #ffffff; border-radius: 20px; font-size: 12px; font-family: 'Courier New', monospace; display: flex; align-items: center; gap: 12px; z-index: 10000; }
        .logout-button { background: #8a2a2a; color: #ffffff; border: 1px solid #ff6666; padding: 4px 8px; border-radius: 12px; font-size: 10px; text-decoration: none; transition: background 0.3s ease; }
        .logout-button:hover { background: #9a3a3a; }
        
        /* Portrait orientation optimization */
        @media (max-height: 600px) {
            #right-controls {
                width: 240px;
                gap: 10px;
                padding: 15px;
            }
            .controller-container { 
                width: min(calc(100vh - 30px), calc(100vw - 260px)); 
                height: min(calc(100vh - 30px), calc(100vw - 260px)); 
            }
            .rete-background {
                width: min(calc(100vh - 30px), calc(100vw - 260px));
                height: min(calc(100vh - 30px), calc(100vw - 260px));
            }
        }
        
        @media (max-width: 800px) {
            #right-controls {
                width: 200px;
                gap: 8px;
                padding: 10px;
            }
            .controller-container { 
                width: min(calc(100vh - 20px), calc(100vw - 220px)); 
                height: min(calc(100vh - 20px), calc(100vw - 220px)); 
            }
            .rete-background {
                width: min(calc(100vh - 20px), calc(100vw - 220px));
                height: min(calc(100vh - 20px), calc(100vw - 220px));
            }
        }
    </style>
</head>
<body>
    <div class="user-info">
      <span>User: <?php echo htmlspecialchars($_SESSION['username'] ?? 'Unknown'); ?></span>
      <a href="logout.php" class="logout-button">Logout</a>
    </div>

    <!-- Connection Status Indicator -->
    <div id="connection-status">
        <div id="status-indicator" class="status-disconnected"></div>
        <span id="status-text">Bağlantı Kuriliyor...</span>
    </div>

    <div id="main-layout">        
        <div id="controller-area">
            <!-- Rete Background Layer -->
            <div class="rete-background" id="rete-bg"></div>
            
            <div id="draggable-controller-wrapper">
                <div id="controller" class="controller-container relative flex items-center justify-center select-none">
            <svg width="100%" height="100%" viewBox="0 0 500 500">
                <defs><radialGradient id="backgroundGradient" cx="50%" cy="50%" r="50%" fx="50%" fy="50%"><stop offset="40%" style="stop-color:rgb(0, 0, 0); stop-opacity:1" /><stop offset="85%" style="stop-color:rgb(59, 17, 17); stop-opacity:0.9" /><stop offset="100%" style="stop-color:rgb(127, 29, 29); stop-opacity:0.8" /></radialGradient></defs>
                <circle cx="250" cy="250" r="250" fill="url(#backgroundGradient)" />
                <g id="year-group"></g>
                <g id="month-group"></g>
                <g id="day-group"></g>
                <g id="time-group">
                     <circle cx="250" cy="250" r="90" fill="rgba(0,0,0,0.5)" />
                     <path class="hilal-mask" d="M250,170 A80,80 0 1,1 250,330 A65,80 0 1,0 250,170 Z" fill="white"/>
                </g>
            </svg>
            <div class="date-display absolute rounded-full flex flex-col items-center justify-center text-center p-4 pointer-events-none" style="width: 150px; height: 150px;">
                <div id="date-str" class="text-sm font-bold tracking-widest text-shadow"></div>
                <div id="time-str" class="text-xs opacity-80 text-shadow"></div>
            </div>
        </div>
                </svg>
                </div>
            </div>
        </div>
        
        <div id="right-controls">
            <!-- AI Horoscope Button -->
            <button id="ai-horoscope-btn" class="relative group overflow-hidden px-6 py-3 rounded-xl bg-gradient-to-r from-red-600/80 to-orange-600/80 hover:from-red-500 hover:to-orange-500 transition-all duration-300 backdrop-blur-sm border border-red-400/30 shadow-lg hover:shadow-red-500/20">
                <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                <div class="relative flex items-center justify-center space-x-2 font-['Play'] font-bold text-white">
                    <span>Ahkam-ı Nücum</span>
                </div>
            </button>
            
            <!-- Latitude Slider -->
            <div class="flex flex-col space-y-2 bg-black/20 px-4 py-3 rounded-lg border border-white/10">
                <span class="text-white font-['Play'] text-sm text-center">Enlem:</span>
                <div class="flex items-center space-x-3">
                    <input type="range" id="latitude-slider" min="20" max="70" value="41" class="flex-1">
                    <span id="latitude-display" class="text-white font-['Play'] text-sm w-8 text-center">41</span>
                </div>
            </div>
            
            <!-- Astrolabe Toggle Button -->
            <button id="toggle-astrolabe-btn" class="px-4 py-3 bg-black/20 hover:bg-white/10 border border-white/20 rounded-lg text-white font-['Play'] text-sm transition-all text-center">
                Usturlap
            </button>
            
            <!-- Toggle Names Button -->
            <button id="toggle-names-btn" class="px-4 py-3 bg-black/20 hover:bg-white/10 border border-white/20 rounded-lg text-white font-['Play'] text-sm transition-all text-center">
                Yıldızımı Göster
            </button>
        </div>
    </div>
    
    <!-- AI Horoscope Popup - Space Theme (Complete.html Style) -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Play:wght@400;700&family=Roboto:wght@400;500;700&display=swap');
        
        @keyframes starTwinkle {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 1; }
        }
        
        @keyframes cosmicGlow {
            0%, 100% { box-shadow: 0 0 20px rgba(239, 68, 68, 0.3), 0 0 40px rgba(127, 29, 29, 0.1); }
            50% { box-shadow: 0 0 30px rgba(239, 68, 68, 0.5), 0 0 60px rgba(127, 29, 29, 0.2); }
        }
        
        .space-popup {
            background: radial-gradient(ellipse at top, #1b2735 0%, #090a0f 100%);
            position: relative;
            overflow: hidden;
        }
        
        .space-popup::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="10" cy="10" r="1" fill="white" opacity="0.5"/><circle cx="90" cy="20" r="0.5" fill="white" opacity="0.7"/><circle cx="30" cy="80" r="0.8" fill="white" opacity="0.4"/><circle cx="70" cy="60" r="1.2" fill="white" opacity="0.6"/><circle cx="50" cy="30" r="0.6" fill="white" opacity="0.8"/></svg>') repeat;
            animation: starTwinkle 3s ease-in-out infinite;
            pointer-events: none;
        }
        
        .cosmic-card {
            background: rgba(10, 10, 20, 0.7);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border: 1px solid rgba(252, 165, 165, 0.2);
            animation: cosmicGlow 4s ease-in-out infinite;
        }
        
        .constellation-line-decoration {
            position: absolute;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, #ef4444, transparent);
            opacity: 0.3;
        }
        
        /* Custom Cosmic Scrollbar */
        .overflow-y-auto::-webkit-scrollbar,
        #horoscope-content::-webkit-scrollbar {
            width: 12px;
        }
        
        .overflow-y-auto::-webkit-scrollbar-track,
        #horoscope-content::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.4);
            border-radius: 10px;
            border: 1px solid rgba(239, 68, 68, 0.1);
        }
        
        .overflow-y-auto::-webkit-scrollbar-thumb,
        #horoscope-content::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, 
                #ef4444 0%, 
                #fb923c 50%, 
                #ef4444 100%);
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 
                inset 0 0 6px rgba(0, 0, 0, 0.3),
                0 0 10px rgba(239, 68, 68, 0.4);
        }
        
        .overflow-y-auto::-webkit-scrollbar-thumb:hover,
        #horoscope-content::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(180deg, 
                #dc2626 0%, 
                #ea580c 50%, 
                #dc2626 100%);
            box-shadow: 
                inset 0 0 6px rgba(0, 0, 0, 0.3),
                0 0 20px rgba(239, 68, 68, 0.6);
        }
        
        /* Firefox Scrollbar */
        .overflow-y-auto,
        #horoscope-content {
            scrollbar-width: thin;
            scrollbar-color: #ef4444 rgba(0, 0, 0, 0.4);
        }
        
        /* Connection Status Icon */
        #connection-status {
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 1000;
            display: flex;
            align-items: center;
            space-x: 2;
            padding: 6px 12px;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            font-family: 'Play', sans-serif;
            font-size: 11px;
            color: white;
        }
        
        #status-indicator {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 6px;
            transition: all 0.3s ease;
        }
        
        .status-p2p {
            background: #22c55e;
            box-shadow: 0 0 6px #22c55e;
            animation: pulse 2s infinite;
        }
        
        .status-http {
            background: #f59e0b;
            box-shadow: 0 0 6px #f59e0b;
            animation: pulse 2s infinite;
        }
        
        .status-disconnected {
            background: #ef4444;
            box-shadow: 0 0 6px #ef4444;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        /* Responsive AI Horoscope Popup sizing - 70% of controller for square in circle */
        @media (max-height: 600px) {
            #ai-horoscope-popup .space-popup {
                max-width: min(calc(70vh - 21px), calc(70vw - 182px)) !important;
                max-height: min(calc(70vh - 21px), calc(70vw - 182px)) !important;
            }
        }
        
        @media (max-width: 800px) {
            #ai-horoscope-popup .space-popup {
                max-width: min(calc(70vh - 14px), calc(70vw - 154px)) !important;
                max-height: min(calc(70vh - 14px), calc(70vw - 154px)) !important;
            }
        }
    </style>
    
    <div id="ai-horoscope-popup" class="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 hidden items-center justify-center">
        <div class="space-popup cosmic-card rounded-2xl w-full mx-4 overflow-y-auto overflow-x-hidden transform transition-all duration-300 relative flex flex-col" style="max-width: min(calc(70vh - 28px), calc(70vw - 224px)); max-height: min(calc(70vh - 28px), calc(70vw - 224px));">
            
            <!-- Stars Background Layer -->
            <div class="absolute inset-0 pointer-events-none opacity-30">
                <div class="absolute top-10 left-10 w-2 h-2 bg-white rounded-full animate-pulse"></div>
                <div class="absolute top-20 right-20 w-1 h-1 bg-blue-200 rounded-full animate-pulse" style="animation-delay: 0.5s"></div>
                <div class="absolute bottom-20 left-30 w-1.5 h-1.5 bg-purple-200 rounded-full animate-pulse" style="animation-delay: 1s"></div>
            </div>
            
            <!-- Header with Constellation Theme -->
            <div class="relative p-6 border-b border-white/10 bg-gradient-to-r from-transparent via-red-900/20 to-transparent">
                <div class="constellation-line-decoration top-0"></div>
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-3">
                        <div class="relative">
                            <div class="w-10 h-10 rounded-full bg-gradient-to-r from-red-400 to-orange-400 opacity-20 absolute animate-ping"></div>
                            <div class="w-10 h-10 rounded-full bg-gradient-to-r from-red-400 to-orange-400 flex items-center justify-center relative">
                            </div>
                        </div>
                        <h2 class="text-2xl font-['Play'] font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-300 to-orange-300">
                            Burç Analizi
                        </h2>
                        <div id="stream-indicator" class="hidden">
                            <div class="flex items-center space-x-2 px-3 py-1 rounded-full bg-green-400/10 border border-green-400/30">
                                <div class="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                                <span class="text-green-400 text-xs font-['Play'] uppercase tracking-wider">Canlı</span>
                            </div>
                        </div>
                    </div>
                    <button id="close-popup" class="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-all duration-300 border border-white/10">
                        <span class="text-xl font-light">×</span>
                    </button>
                </div>
            </div>
            
            <!-- Content Area with Starfield -->
            <div class="p-8 overflow-y-auto flex-1 relative">
                <div id="horoscope-content" class="text-gray-200 font-['Roboto'] leading-relaxed text-justify relative z-10">
                    <div class="text-center text-gray-400 flex flex-col items-center justify-center space-y-4 py-12">
                        <!-- Cosmic Loading Animation -->
                        <div class="relative w-20 h-20">
                            <div class="absolute inset-0 rounded-full border-2 border-red-400/30 animate-spin"></div>
                            <div class="absolute inset-2 rounded-full border-2 border-orange-400/30 animate-spin" style="animation-direction: reverse; animation-duration: 3s"></div>
                            <div class="absolute inset-4 rounded-full border-2 border-yellow-400/20 animate-spin" style="animation-duration: 2s"></div>
                            <div class="absolute inset-0 flex items-center justify-center">
                            </div>
                        </div>
                        <span class="font-['Play'] text-lg text-transparent bg-clip-text bg-gradient-to-r from-red-300 via-orange-300 to-red-300 animate-pulse">
                            Yıldızlar okunuyor...
                        </span>
                    </div>
                </div>
                
            </div>
            
            <!-- Footer with Cosmic Button -->
            <div class="relative p-6 border-t border-white/10 bg-gradient-to-r from-transparent via-red-900/20 to-transparent">
                <div class="constellation-line-decoration bottom-0"></div>
                
                <!-- Email Input Section -->
                <div id="email-input-section" class="hidden mb-4">
                    <div class="flex flex-col space-y-3">
                        <div class="flex space-x-2">
                            <input type="email" 
                                   id="recipient-email" 
                                   placeholder="E-posta adresinizi girin..." 
                                   class="flex-1 px-4 py-2 bg-black/30 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-orange-400 transition-colors font-['Play']">
                            <button id="confirm-email-btn" 
                                    class="px-4 py-2 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 border border-white/20 rounded-lg text-white transition-all font-['Play'] disabled:opacity-50 disabled:cursor-not-allowed">
                                Gönder
                            </button>
                            <button id="cancel-email-btn" 
                                    class="px-4 py-2 bg-gray-800/50 hover:bg-gray-700/50 border border-white/20 rounded-lg text-gray-300 hover:text-white transition-all font-['Play']">
                                İptal
                            </button>
                        </div>
                        <!-- KVKK Onay Checkbox -->
                        <div class="flex items-start space-x-2">
                            <input type="checkbox" 
                                   id="kvkk-consent" 
                                   class="mt-1 w-4 h-4 bg-black/30 border border-white/30 rounded focus:ring-2 focus:ring-orange-400 text-orange-600 cursor-pointer">
                            <label for="kvkk-consent" class="text-xs text-gray-300 font-['Play'] leading-relaxed cursor-pointer">
                                <a href="kvkk.php" target="_blank" class="text-orange-400 hover:text-orange-300 underline">KVKK Aydınlatma Metni</a>'ni okudum ve e-posta adresimin burç analizi raporunun gönderilmesi için işlenmesini kabul ediyorum.
                            </label>
                        </div>
                        <div id="email-error" class="text-red-400 text-sm hidden"></div>
                    </div>
                </div>
                
                <button id="send-email-btn" class="w-full relative group overflow-hidden rounded-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed" disabled>
                    <div class="absolute inset-0 bg-gradient-to-r from-red-600 to-orange-600 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                    <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                    <div class="relative py-3 px-4 font-['Play'] font-bold text-white flex items-center justify-center space-x-2">
                        <span>Raporu Gönder</span>
                    </div>
                </button>
            </div>
        </div>
    </div>
    

    <script src="includes/common.js"></script>
    <script src="local_sync.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // --- STATE & SHARED VARIABLES ---
            let state = { date: new Date(), latitude: 41, showStarNames: true, showAstrolabe: false };
            const svgNS = "http://www.w3.org/2000/svg";
            const sessionKey = AstrolabeCommon.getSessionKey();

            // --- CONTROLLER ELEMENTS ---
            const controller = document.getElementById('controller');
            const dateStrEl = document.getElementById('date-str');
            const timeStrEl = document.getElementById('time-str');
            const latitudeSlider = document.getElementById('latitude-slider');
            const latitudeDisplay = document.getElementById('latitude-display');
            const toggleNamesBtn = document.getElementById('toggle-names-btn');
            const toggleAstrolabeBtn = document.getElementById('toggle-astrolabe-btn');
            const yearGroup = document.getElementById('year-group');
            const monthGroup = document.getElementById('month-group');
            const dayGroup = document.getElementById('day-group');
            const timeGroup = document.getElementById('time-group');
            const controllerSvg = controller.querySelector('svg');
            
            // --- CONTROLLER WRAPPER ---
            const draggableWrapper = document.getElementById('draggable-controller-wrapper');

            // --- CONTROLLER DRAG STATE ---
            let controllerDragState = { isDragging: false, target: null, lastAngle: 0 };
            const RADIUS_CONFIG = { year: { min: 210, max: 250 }, month: { min: 170, max: 210 }, day: { min: 130, max: 170 }, time: { min: 0, max: 130 } };


            // --- ULTRA-FAST LOCAL P2P SYNC ---
            let localSync = null;
            let localSyncActive = false;
            
            // --- WEBSOCKET REAL-TIME SYNC (FALLBACK) ---
            let ws = null;
            let wsConnected = false;
            let reconnectInterval = null;
            let heartbeatInterval = null;
            let syncTimeout;
            
            function initLocalSync() {
                try {
                    localSync = new LocalAstrolabeSync('control');
                    
                    // Listen for updates from display
                    localSync.on('astrolabe_update', (data) => {
                        console.log('📨 Local P2P update received:', data);
                        // Don't echo back to display, just log for debugging
                    });
                    
                    // Check connection status
                    const status = localSync.getConnectionStatus();
                    console.log('🚀 Local P2P Status:', status);
                    
                    if (status.broadcastChannel && status.ultraFastMode) {
                        localSyncActive = true;
                        updateConnectionStatus('p2p');
                        console.log('✅ Local P2P sync active - ultra-fast mode!');
                    }
                    
                } catch (error) {
                    console.error('❌ Local P2P sync failed:', error);
                    localSyncActive = false;
                }
            }
            
            function initWebSocket() {
                try {
                    ws = new WebSocket('ws://localhost:8080');
                    
                    ws.onopen = function() {
                        wsConnected = true;
                        console.log('🔗 WebSocket connected');
                        updateConnectionStatus('http');
                        
                        // Join session as control client
                        ws.send(JSON.stringify({
                            type: 'join_session',
                            sessionKey: sessionKey,
                            clientType: 'control'
                        }));
                        
                        // Start heartbeat
                        startHeartbeat();
                        
                        // Clear reconnect interval if was trying to reconnect
                        if (reconnectInterval) {
                            clearInterval(reconnectInterval);
                            reconnectInterval = null;
                        }
                    };
                    
                    ws.onmessage = function(event) {
                        try {
                            const data = JSON.parse(event.data);
                            console.log('📨 WebSocket received:', data);
                            
                            switch (data.type) {
                                case 'welcome':
                                case 'session_joined':
                                    console.log('✅ ' + (data.message || 'Session joined'));
                                    break;
                                case 'pong':
                                    // Heartbeat response
                                    break;
                                case 'astrolabe_update':
                                    // Update received from display client
                                    console.log('🔄 Received update from display');
                                    break;
                            }
                        } catch (e) {
                            console.error('Failed to parse WebSocket message:', e);
                        }
                    };
                    
                    ws.onclose = function() {
                        wsConnected = false;
                        console.log('❌ WebSocket disconnected');
                        updateConnectionStatus('disconnected');
                        stopHeartbeat();
                        attemptReconnect();
                    };
                    
                    ws.onerror = function(error) {
                        console.error('❌ WebSocket error:', error);
                        updateConnectionStatus('error');
                    };
                    
                } catch (error) {
                    console.error('❌ Failed to create WebSocket:', error);
                    updateConnectionStatus('error');
                    attemptReconnect();
                }
            }
            
            function attemptReconnect() {
                if (!reconnectInterval) {
                    console.log('🔄 Attempting to reconnect...');
                    updateConnectionStatus('reconnecting');
                    
                    reconnectInterval = setInterval(() => {
                        if (!wsConnected) {
                            console.log('🔄 Reconnecting to WebSocket...');
                            initWebSocket();
                        }
                    }, 3000);
                }
            }
            
            function startHeartbeat() {
                heartbeatInterval = setInterval(() => {
                    if (ws && ws.readyState === WebSocket.OPEN) {
                        ws.send(JSON.stringify({
                            type: 'ping',
                            timestamp: Date.now()
                        }));
                    }
                }, 30000); // Every 30 seconds
            }
            
            function stopHeartbeat() {
                if (heartbeatInterval) {
                    clearInterval(heartbeatInterval);
                    heartbeatInterval = null;
                }
            }
            
            function updateConnectionStatus(status) {
                const statusIndicator = document.getElementById('status-indicator');
                const statusText = document.getElementById('status-text');
                
                if (!statusIndicator || !statusText) return;
                
                // Remove all status classes
                statusIndicator.className = '';
                statusIndicator.classList.add('status-indicator');
                
                switch (status) {
                    case 'p2p':
                        statusIndicator.classList.add('status-p2p');
                        statusText.textContent = 'P2P';
                        break;
                    case 'http':
                        statusIndicator.classList.add('status-http');
                        statusText.textContent = 'HTTP';
                        break;
                    case 'disconnected':
                    default:
                        statusIndicator.classList.add('status-disconnected');
                        statusText.textContent = 'OFFLINE';
                }
            }
            
            function scheduleSync() {
                clearTimeout(syncTimeout);
                syncTimeout = setTimeout(() => {
                    const dataToSync = {
                        local_year: state.date.getFullYear(),
                        local_month: state.date.getMonth() + 1,
                        local_day: state.date.getDate(),
                        local_hour: state.date.getHours(),
                        local_minute: state.date.getMinutes(),
                        local_second: state.date.getSeconds(),
                        latitude: state.latitude,
                        star_chart_visible: !state.showAstrolabe,
                        astrolabe_visible: state.showAstrolabe,
                        show_star_names: state.showStarNames
                    };
                    
                    // Priority 1: Ultra-fast Local P2P (< 1ms latency)
                    if (localSyncActive && localSync) {
                        localSync.syncData(dataToSync);
                        console.log('⚡ ULTRA-FAST Local P2P sync sent!');
                        return; // Skip other methods when P2P is active
                    }
                    
                    // Priority 2: WebSocket (real-time ~10ms)
                    if (ws && ws.readyState === WebSocket.OPEN) {
                        ws.send(JSON.stringify({
                            type: 'astrolabe_sync',
                            sessionKey: sessionKey,
                            from: 'control',
                            data: dataToSync
                        }));
                        console.log('🚀 Real-time sync sent via WebSocket');
                    } else {
                        // Priority 3: HTTP fallback (slow ~500ms)
                        console.log('📤 Fallback to HTTP - Sending to server:', dataToSync);
                        AstrolabeCommon.updateState(sessionKey, dataToSync)
                            .then(response => {
                                console.log('✅ Fallback HTTP sync successful:', response);
                            })
                            .catch(error => {
                                console.error('❌ Sync failed:', error);
                            });
                    }
                }, localSyncActive ? 10 : 100); // Ultra-fast debounce for P2P: 10ms vs 100ms
            }

            // --- MAIN UPDATE FUNCTION ---
            // Removed updateAllViews as it was causing race conditions
            // Each handler now updates only what it needs and calls scheduleSync directly

            // --- CONTROLLER DRAWING ---
            function drawControllerRings() { const center = 250; yearGroup.innerHTML = ''; monthGroup.innerHTML = ''; dayGroup.innerHTML = ''; for (let i = 0; i < 120; i++) { const angle = i * 3; const isMajorTick = i % 10 === 0; const rad = (angle - 90) * Math.PI / 180; const r1 = 220; const r2 = isMajorTick ? 240 : 230; const tick = document.createElementNS(svgNS, 'line'); tick.setAttribute('x1', center + r1 * Math.cos(rad)); tick.setAttribute('y1', center + r1 * Math.sin(rad)); tick.setAttribute('x2', center + r2 * Math.cos(rad)); tick.setAttribute('y2', center + r2 * Math.sin(rad)); tick.setAttribute('stroke', 'rgba(255,255,255,0.3)'); tick.setAttribute('stroke-width', isMajorTick ? '2' : '0.75'); yearGroup.appendChild(tick); } for (let i = 0; i < 60; i++) { const angle = i * 6; const isMajorTick = i % 5 === 0; const rad = (angle - 90) * Math.PI / 180; const r1 = 180; const r2 = isMajorTick ? 200 : 190; const tick = document.createElementNS(svgNS, 'line'); tick.setAttribute('x1', center + r1 * Math.cos(rad)); tick.setAttribute('y1', center + r1 * Math.sin(rad)); tick.setAttribute('x2', center + r2 * Math.cos(rad)); tick.setAttribute('y2', center + r2 * Math.sin(rad)); tick.setAttribute('stroke', 'rgba(255,255,255,0.4)'); tick.setAttribute('stroke-width', isMajorTick ? '2.5' : '1'); monthGroup.appendChild(tick); } for (let i = 1; i <= 31; i++) { const angle = (i - 1) * (360 / 31); const isMajorTick = i % 5 === 0; const rad = (angle - 90) * Math.PI / 180; const r1 = 140; const r2 = isMajorTick ? 160 : 150; const tick = document.createElementNS(svgNS, 'line'); tick.setAttribute('x1', center + r1 * Math.cos(rad)); tick.setAttribute('y1', center + r1 * Math.sin(rad)); tick.setAttribute('x2', center + r2 * Math.cos(rad)); tick.setAttribute('y2', center + r2 * Math.sin(rad)); tick.setAttribute('stroke', 'rgba(255,255,255,0.3)'); tick.setAttribute('stroke-width', isMajorTick ? '2.5' : '1'); dayGroup.appendChild(tick); } }
            const getRotation = (el) => { const transform = el.getAttribute('transform'); if (!transform) return 0; const match = /rotate\(([^ ]+)/.exec(transform); return match ? parseFloat(match[1]) : 0; };
            
            // --- CONTROLLER DRAG LOGIC ---
            function getDragTarget(x, y) { const rect = controllerSvg.getBoundingClientRect(); const svgX = x - rect.left; const svgY = y - rect.top; const scaleX = 500 / rect.width; const scaleY = 500 / rect.height; const dx = (svgX * scaleX) - 250; const dy = (svgY * scaleY) - 250; const r = Math.sqrt(dx * dx + dy * dy); for (const target in RADIUS_CONFIG) { if (r >= RADIUS_CONFIG[target].min && r < RADIUS_CONFIG[target].max) return target; } return null; }
            function handleControllerDragStart(e) { e.preventDefault(); const x = e.clientX || e.touches[0].clientX; const y = e.clientY || e.touches[0].clientY; controllerDragState.target = getDragTarget(x, y); if (!controllerDragState.target) return; controllerDragState.isDragging = true; const dx = x - controller.getBoundingClientRect().left - controller.offsetWidth / 2; const dy = y - controller.getBoundingClientRect().top - controller.offsetHeight / 2; controllerDragState.lastAngle = Math.atan2(dy, dx) * 180 / Math.PI; controller.classList.add('active:cursor-grabbing'); }
            function handleControllerDragMove(e) {
                if (!controllerDragState.isDragging) return;
                e.preventDefault();
                const x = e.clientX || e.touches[0].clientX;
                const y = e.clientY || e.touches[0].clientY;
                const dx = x - controller.getBoundingClientRect().left - controller.offsetWidth / 2;
                const dy = y - controller.getBoundingClientRect().top - controller.offsetHeight / 2;
                const currentAngle = Math.atan2(dy, dx) * 180 / Math.PI;
                let incrementalDelta = currentAngle - controllerDragState.lastAngle;

                if (incrementalDelta > 180) incrementalDelta -= 360;
                if (incrementalDelta < -180) incrementalDelta += 360;

                const newDate = new Date(state.date.getTime());
                const msInDay = 86400000;

                switch (controllerDragState.target) {
                    case 'year': newDate.setTime(newDate.getTime() + incrementalDelta * (msInDay * 30.44)); break;
                    case 'month': newDate.setTime(newDate.getTime() + incrementalDelta * (msInDay * 30.44 / 30.0)); break;
                    case 'day': newDate.setTime(newDate.getTime() + incrementalDelta * (msInDay / (360.0 / 31.0))); break;
                    case 'time': newDate.setTime(newDate.getTime() + incrementalDelta * 4 * 60000); break;
                }
                
                state.date = newDate;
                
                // Update rotation immediately
                const group = document.getElementById(`${controllerDragState.target}-group`);
                const currentRotation = getRotation(group);
                group.setAttribute('transform', `rotate(${currentRotation + incrementalDelta} 250 250)`);
                
                // Update display without resetting rotations
                const optionsDate = { day: 'numeric', month: 'long', year: 'numeric' };
                const dateText = state.date.toLocaleDateString('tr-TR', optionsDate);
                const timeText = state.date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
                
                // Update controller center display
                dateStrEl.textContent = dateText;
                timeStrEl.textContent = timeText;
                
                
                // Schedule sync but don't call updateAllViews which might reset rotations
                scheduleSync();
                
                controllerDragState.lastAngle = currentAngle;
            }
            function handleControllerDragEnd() { if (!controllerDragState.isDragging) return; controllerDragState.isDragging = false; controller.classList.remove('active:cursor-grabbing'); }
            

            // --- INITIALIZE ---
            async function initialize() {
                // Load state from database first BEFORE drawing
                try {
                    const savedState = await AstrolabeCommon.fetchState(sessionKey);
                    if (savedState && savedState.local_year) {
                        const hour = typeof savedState.local_hour === 'string' ? parseInt(savedState.local_hour, 10) : (savedState.local_hour || 0);
                        const minute = typeof savedState.local_minute === 'string' ? parseInt(savedState.local_minute, 10) : (savedState.local_minute || 0);
                        const second = typeof savedState.local_second === 'string' ? parseInt(savedState.local_second, 10) : (savedState.local_second || 0);
                        
                        state.date = new Date(
                            parseInt(savedState.local_year),
                            parseInt(savedState.local_month) - 1,
                            parseInt(savedState.local_day),
                            hour,
                            minute,
                            second
                        );
                        
                        if (savedState.latitude !== undefined) {
                            state.latitude = parseInt(savedState.latitude);
                            latitudeSlider.value = state.latitude;
                        }
                        
                        if (savedState.astrolabe_visible !== undefined) {
                            state.showAstrolabe = savedState.astrolabe_visible;
                            toggleAstrolabeBtn.textContent = state.showAstrolabe ? 'Yıldız Haritası' : 'Usturlap';
                        }
                        
                        console.log('📥 Loaded state from database:', state.date.toLocaleString('tr-TR'), 'Latitude:', state.latitude, 'Astrolabe:', state.showAstrolabe);
                    }
                } catch (error) {
                    console.error('Failed to load state:', error);
                }
                
                // Now draw and set rotations based on loaded state
                drawControllerRings();
                
                const yearAngle = -(state.date.getFullYear() - 2024) * 12;
                yearGroup.setAttribute('transform', `rotate(${yearAngle} 250 250)`);
                const monthAngle = -(state.date.getMonth() * 30);
                monthGroup.setAttribute('transform', `rotate(${monthAngle} 250 250)`);
                const dayAngle = -(state.date.getDate() - 1) * (360 / 31);
                dayGroup.setAttribute('transform', `rotate(${dayAngle} 250 250)`);
                const totalMinutes = state.date.getHours() * 60 + state.date.getMinutes();
                const timeAngle = (totalMinutes / 1440) * 360;
                timeGroup.setAttribute('transform', `rotate(${timeAngle} 250 250)`);
                
                console.log('🔄 Initial rotations - Time angle:', timeAngle, 'degrees for', state.date.getHours() + ':' + state.date.getMinutes());

                // Don't call updateAllViews here as it will trigger a sync
                // Just update the display
                const optionsDate = { day: 'numeric', month: 'long', year: 'numeric' };
                const dateText = state.date.toLocaleDateString('tr-TR', optionsDate);
                const timeText = state.date.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
                
                // Update controller center display
                dateStrEl.textContent = dateText;
                timeStrEl.textContent = timeText;
                
                
                latitudeDisplay.textContent = state.latitude;
                toggleNamesBtn.textContent = state.showStarNames ? 'Yıldızımı Göster' : 'Bilgileri Göster';

                controller.addEventListener('mousedown', handleControllerDragStart);
                window.addEventListener('mousemove', handleControllerDragMove);
                window.addEventListener('mouseup', handleControllerDragEnd);
                controller.addEventListener('touchstart', handleControllerDragStart, { passive: false });
                window.addEventListener('touchmove', handleControllerDragMove, { passive: false });
                window.addEventListener('touchend', handleControllerDragEnd);
                

                latitudeSlider.addEventListener('input', (e) => { 
                    state.latitude = parseInt(e.target.value); 
                    latitudeDisplay.textContent = state.latitude;
                    scheduleSync();
                });
                toggleNamesBtn.addEventListener('click', () => { 
                    state.showStarNames = !state.showStarNames; 
                    toggleNamesBtn.textContent = state.showStarNames ? 'Yıldızımı Göster' : 'Bilgileri Göster';
                    scheduleSync();
                });
                
                // Add event listener for astrolabe toggle button
                toggleAstrolabeBtn.addEventListener('click', () => {
                    // Toggle astrolabe view
                    state.showAstrolabe = !state.showAstrolabe;
                    
                    // Update button text
                    toggleAstrolabeBtn.textContent = state.showAstrolabe ? 'Yıldız Haritası' : 'Usturlap';
                    
                    // Schedule sync to update server state
                    scheduleSync();
                });
            }
            
            // AI Horoscope Button
            const aiHoroscopeBtn = document.getElementById('ai-horoscope-btn');
            const aiHoroscopePopup = document.getElementById('ai-horoscope-popup');
            const closePopupBtn = document.getElementById('close-popup');
            const sendEmailBtn = document.getElementById('send-email-btn');
            const horoscopeContent = document.getElementById('horoscope-content');
            
            let currentHoroscopeText = '';
            
            if (aiHoroscopeBtn) {
                aiHoroscopeBtn.addEventListener('click', () => {
                    aiHoroscopePopup.classList.remove('hidden');
                    aiHoroscopePopup.classList.add('flex');
                    
                    // Show enhanced indicators
                    const streamIndicator = document.getElementById('stream-indicator');
                    if (streamIndicator) streamIndicator.classList.remove('hidden');
                    
                    generateHoroscope();
                });
            }
            
            if (closePopupBtn) {
                closePopupBtn.addEventListener('click', () => {
                    aiHoroscopePopup.classList.add('hidden');
                    aiHoroscopePopup.classList.remove('flex');
                    
                    // Hide indicators when closing
                    const streamIndicator = document.getElementById('stream-indicator');
                    if (streamIndicator) streamIndicator.classList.add('hidden');
                });
            }
            
            // Email button handlers
            const emailInputSection = document.getElementById('email-input-section');
            const recipientEmailInput = document.getElementById('recipient-email');
            const confirmEmailBtn = document.getElementById('confirm-email-btn');
            const cancelEmailBtn = document.getElementById('cancel-email-btn');
            const emailError = document.getElementById('email-error');
            
            if (sendEmailBtn) {
                sendEmailBtn.addEventListener('click', () => {
                    // Show email input section
                    emailInputSection.classList.remove('hidden');
                    recipientEmailInput.focus();
                    sendEmailBtn.style.display = 'none';
                });
            }
            
            if (confirmEmailBtn) {
                confirmEmailBtn.addEventListener('click', () => {
                    const email = recipientEmailInput.value.trim();
                    const kvkkConsent = document.getElementById('kvkk-consent');
                    
                    if (!kvkkConsent.checked) {
                        emailError.textContent = 'Lütfen KVKK aydınlatma metnini onaylayın.';
                        emailError.classList.remove('hidden');
                    } else if (validateEmail(email)) {
                        sendHoroscopeEmail(email);
                    } else {
                        emailError.textContent = 'Lütfen geçerli bir e-posta adresi girin.';
                        emailError.classList.remove('hidden');
                    }
                });
            }
            
            if (cancelEmailBtn) {
                cancelEmailBtn.addEventListener('click', () => {
                    // Hide email input section and show button again
                    emailInputSection.classList.add('hidden');
                    sendEmailBtn.style.display = 'block';
                    recipientEmailInput.value = '';
                    document.getElementById('kvkk-consent').checked = false;
                    emailError.classList.add('hidden');
                });
            }
            
            if (recipientEmailInput) {
                recipientEmailInput.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') {
                        const email = recipientEmailInput.value.trim();
                        const kvkkConsent = document.getElementById('kvkk-consent');
                        
                        if (!kvkkConsent.checked) {
                            emailError.textContent = 'Lütfen KVKK aydınlatma metnini onaylayın.';
                            emailError.classList.remove('hidden');
                        } else if (validateEmail(email)) {
                            sendHoroscopeEmail(email);
                        } else {
                            emailError.textContent = 'Lütfen geçerli bir e-posta adresi girin.';
                            emailError.classList.remove('hidden');
                        }
                    }
                });
            }
            
            function validateEmail(email) {
                const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return re.test(email);
            }
            
            // Generate Horoscope Function
            async function generateHoroscope() {
                console.log('generateHoroscope started');
                console.log('Current state:', state);
                
                // Check if state exists
                if (!state || !state.date) {
                    console.error('State or state.date is undefined!');
                    horoscopeContent.innerHTML = '<div class="text-red-400">Hata: Tarih bilgisi bulunamadı. Lütfen sayfayı yenileyin.</div>';
                    return;
                }
                
                // Clear content and show cosmic loading animation
                horoscopeContent.innerHTML = `
                    <div class="text-center text-gray-400 flex flex-col items-center justify-center space-y-4 py-12">
                        <!-- Cosmic Loading Animation -->
                        <div class="relative w-20 h-20">
                            <div class="absolute inset-0 rounded-full border-2 border-red-400/30 animate-spin"></div>
                            <div class="absolute inset-2 rounded-full border-2 border-orange-400/30 animate-spin" style="animation-direction: reverse; animation-duration: 3s"></div>
                            <div class="absolute inset-4 rounded-full border-2 border-yellow-400/20 animate-spin" style="animation-duration: 2s"></div>
                            <div class="absolute inset-0 flex items-center justify-center">
                            </div>
                        </div>
                        <span class="font-['Play'] text-lg text-transparent bg-clip-text bg-gradient-to-r from-red-300 via-orange-300 to-red-300 animate-pulse">
                            Yıldızlar okunuyor...
                        </span>
                    </div>
                `;
                sendEmailBtn.disabled = true;
                currentHoroscopeText = '';
                
                // No progress bar needed for streaming
                
                try {
                    console.log('Preparing ephemeris data...');
                    // Get current ephemeris data
                    const ephemerisData = {
                        date: state.date.toDateString(),
                        latitude: state.latitude,
                        year: state.date.getFullYear(),
                        month: state.date.getMonth() + 1,
                        day: state.date.getDate(),
                        hour: state.date.getHours(),
                        minute: state.date.getMinutes()
                    };
                    
                    console.log('Sending request with data:', ephemerisData);
                    
                    const response = await fetch('ai_horoscope.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(ephemerisData)
                    });
                    
                    console.log('Response received:', response.status, response.statusText);
                    
                    if (!response.ok) {
                        throw new Error(`Network response was not ok: ${response.status} ${response.statusText}`);
                    }
                    
                    const reader = response.body.getReader();
                    const decoder = new TextDecoder();
                    
                    // Clear loading animation as soon as stream starts
                    let firstChunk = true;
                    
                    while (true) {
                        const { done, value } = await reader.read();
                        if (done) break;
                        
                        let chunk = decoder.decode(value);
                        
                        // Filter out PHP error messages completely
                        if (chunk.includes('<br') || chunk.includes('<b>') || chunk.includes('Notice') || chunk.includes('Warning') || chunk.includes('ob_flush')) {
                            console.warn('Filtered PHP error from stream, skipping chunk');
                            // Try to extract only the data: lines if present
                            const dataMatch = chunk.match(/data: .*/g);
                            if (dataMatch) {
                                chunk = dataMatch.join('\n');
                            } else {
                                continue;
                            }
                        }
                        
                        console.log('Received chunk:', chunk); // Debug log
                        const lines = chunk.split('\n');
                        
                        for (const line of lines) {
                            if (line.trim() === '') continue;
                            
                            if (line.startsWith('data: ')) {
                                const data = line.substring(6);
                                console.log('Processing data:', data); // Debug log
                                
                                if (data === '[DONE]') {
                                    sendEmailBtn.disabled = false;
                                    
                                    // Hide stream indicator
                                    setTimeout(() => {
                                        const streamIndicator = document.getElementById('stream-indicator');
                                        if (streamIndicator) streamIndicator.classList.add('hidden');
                                    }, 500);
                                    
                                    return;
                                }
                                
                                try {
                                    const parsed = JSON.parse(data);
                                    console.log('Parsed data:', parsed); // Debug log
                                    
                                    if (parsed.error) {
                                        // Show error message
                                        horoscopeContent.innerHTML = `
                                            <div class="text-center text-red-400 p-8">
                                                <div class="text-4xl mb-4">⚠️</div>
                                                <div class="text-lg font-bold mb-2">Yapılandırma Hatası</div>
                                                <div class="text-sm">${parsed.error}</div>
                                                <div class="mt-4 text-xs text-gray-400">
                                                    Lütfen .env dosyasında OPENROUTER_API_KEY değerini ayarlayın.
                                                </div>
                                            </div>
                                        `;
                                        sendEmailBtn.disabled = true;
                                        const streamIndicator = document.getElementById('stream-indicator');
                                        if (streamIndicator) streamIndicator.classList.add('hidden');
                                        return;
                                    }
                                    if (parsed.content) {
                                        // Clear loading animation on first content
                                        if (firstChunk) {
                                            horoscopeContent.innerHTML = '';
                                            firstChunk = false;
                                        }
                                        
                                        currentHoroscopeText += parsed.content;
                                        
                                        // Format the text with proper HTML styling
                                        let formattedText = currentHoroscopeText
                                            // Convert markdown bold to styled spans
                                            .replace(/\*\*(.*?)\*\*/g, '<span class="text-transparent bg-clip-text bg-gradient-to-r from-red-300 to-orange-300 font-bold text-lg">$1</span>')
                                            // Convert numbered lists to styled format
                                            .replace(/^(\d+)\.\s(.*)$/gm, '<div class="flex items-start space-x-3 mb-3"><div class="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-r from-red-500/20 to-orange-500/20 flex items-center justify-center text-red-300 font-bold">$1</div><div class="flex-1 text-gray-200">$2</div></div>')
                                            // Convert section headers (lines ending with :)
                                            .replace(/^([^:]+):$/gm, '<div class="text-transparent bg-clip-text bg-gradient-to-r from-red-300 to-orange-300 font-bold text-lg mb-2 mt-4">$1:</div>')
                                            // Convert bullet points
                                            .replace(/^[•\-]\s(.*)$/gm, '<div class="flex items-start space-x-2 mb-2"><span class="text-orange-400">✦</span><div class="text-gray-200">$1</div></div>')
                                            // Convert line breaks
                                            .replace(/\n\n/g, '</p><p class="mb-3 text-gray-200 leading-relaxed">')
                                            .replace(/\n/g, '<br>');
                                        
                                        // Wrap in paragraph if not already wrapped
                                        if (!formattedText.startsWith('<p') && !formattedText.startsWith('<div')) {
                                            formattedText = '<p class="mb-3 text-gray-200 leading-relaxed">' + formattedText + '</p>';
                                        }
                                        
                                        horoscopeContent.innerHTML = formattedText;
                                        horoscopeContent.scrollTop = horoscopeContent.scrollHeight;
                                    }
                                } catch (e) {
                                    console.error('JSON parse error:', e, 'Data:', data); // Debug log
                                }
                            }
                        }
                    }
                } catch (error) {
                    console.error('Error in generateHoroscope:', error);
                    horoscopeContent.innerHTML = `<div class="text-red-400">
                        <div class="text-2xl mb-2">❌ Hata</div>
                        <div>${error.message || 'AI yorumu alınamadı'}</div>
                        <div class="text-sm mt-2">Lütfen admin panelinden ayarları kontrol edin.</div>
                    </div>`;
                    
                    // Clean up on error
                    const streamIndicator = document.getElementById('stream-indicator');
                    if (streamIndicator) streamIndicator.classList.add('hidden');
                }
            }
            
            // Store captured screenshots
            let capturedScreenshots = null;
            
            // Send Horoscope Email Function
            async function sendHoroscopeEmail(recipientEmail) {
                if (!currentHoroscopeText) {
                    emailError.textContent = 'Önce AI yorumu oluşturulmalı!';
                    emailError.classList.remove('hidden');
                    return;
                }
                
                if (!recipientEmail) {
                    recipientEmail = recipientEmailInput.value.trim();
                    const kvkkConsent = document.getElementById('kvkk-consent');
                    
                    if (!kvkkConsent.checked) {
                        emailError.textContent = 'Lütfen KVKK aydınlatma metnini onaylayın.';
                        emailError.classList.remove('hidden');
                        return;
                    }
                    
                    if (!validateEmail(recipientEmail)) {
                        emailError.textContent = 'Lütfen geçerli bir e-posta adresi girin.';
                        emailError.classList.remove('hidden');
                        return;
                    }
                }
                
                // Update button to show sending status
                const originalButtonContent = sendEmailBtn.innerHTML;
                sendEmailBtn.disabled = true;
                sendEmailBtn.innerHTML = `
                    <div class="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-500"></div>
                    <div class="relative py-3 px-4 font-['Play'] font-bold text-white">
                        📸 Ekran Görüntüsü Alınıyor...
                    </div>
                `;
                
                // Request screenshots from display.php via P2P
                capturedScreenshots = null;
                
                // Set up listener for screenshot response
                if (localSync) {
                    localSync.on('screenshot_capture', (data) => {
                        console.log('📸 Screenshots received:', data);
                        capturedScreenshots = data.screenshots;
                    });
                    
                    // Request screenshot
                    localSync.sendBroadcast('request_screenshot', {
                        sessionKey: sessionKey,
                        timestamp: Date.now()
                    });
                }
                
                // Wait for screenshots with timeout
                let screenshotAttempts = 0;
                const maxAttempts = 10;
                
                while (!capturedScreenshots && screenshotAttempts < maxAttempts) {
                    await new Promise(resolve => setTimeout(resolve, 500));
                    screenshotAttempts++;
                }
                
                sendEmailBtn.innerHTML = `
                    <div class="absolute inset-0 bg-gradient-to-r from-green-600 to-green-500"></div>
                    <div class="relative py-3 px-4 font-['Play'] font-bold text-white">
                        📨 Gönderiliyor...
                    </div>
                `;
                
                try {
                    const response = await fetch('send_horoscope_email.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            horoscope_text: currentHoroscopeText,
                            date: state.date.toDateString(),
                            latitude: state.latitude,
                            recipient_email: recipientEmail,
                            screenshots: capturedScreenshots || null
                        })
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        // Success - show confirmation
                        sendEmailBtn.innerHTML = `
                            <div class="absolute inset-0 bg-gradient-to-r from-green-600 to-green-500"></div>
                            <div class="relative py-3 px-4 font-['Play'] font-bold text-white">
                                ✅ E-posta Gönderildi!
                            </div>
                        `;
                        
                        // Reset after 3 seconds
                        setTimeout(() => {
                            emailInputSection.classList.add('hidden');
                            sendEmailBtn.style.display = 'block';
                            sendEmailBtn.innerHTML = originalButtonContent;
                            sendEmailBtn.disabled = false;
                            recipientEmailInput.value = '';
                            document.getElementById('kvkk-consent').checked = false;
                            emailError.classList.add('hidden');
                        }, 3000);
                    } else {
                        throw new Error(result.error || 'Email gönderilemedi');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    emailError.textContent = 'Email gönderilirken hata: ' + error.message;
                    emailError.classList.remove('hidden');
                    sendEmailBtn.innerHTML = originalButtonContent;
                    sendEmailBtn.disabled = false;
                }
            }

            initialize();
            
            // Initialize Ultra-Fast Local P2P sync first
            initLocalSync();
            
            // Initialize WebSocket connection as fallback
            if (!localSyncActive) {
                initWebSocket();
            } else {
                console.log('⚡ Local P2P active, WebSocket disabled for maximum performance');
                // Don't initialize WebSocket when P2P is working
            }
            
            // Load actual Rete from astrolabe
            function loadReteSVG() {
                const reteBg = document.getElementById('rete-bg');
                if (!reteBg) return;
                
                // Set z-index for the rete background
                reteBg.style.zIndex = '20';
                
                // Create SVG structure matching exactly what rete.js expects
                const svgContent = `
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000" style="width: 100%; height: 100%; z-index: 20; position: relative;">
                        <g transform="translate(500,500) scale(-5.5, 5.5)">
                            <g id="reteLayer" transform="rotate(180)">
                                <g id="reteGroup" transform="rotate(0)">
                                    <g id="retebrassGroup" stroke="rgb(105,85,60)" stroke-width="0.15" fill="rgb(235,215,110)">
                                        <path id="capella" d=""/>
                                        <path id="retePath"/>
                                        <g id="reteMarks"/>
                                        <g id="starnames_textgroup"/>
                                    </g>
                                    <g id="stargroup"/>
                                    <g id="starpointer_group"/>
                                </g>
                                <g id="eclipticGroup">
                                    <path id="ecliptic"/>
                                    <g id="eclipticMarks"/>
                                </g>
                                <g id="planetsGroup">
                                    <g id="moonGroup"/>
                                    <g id="sunGroup"/>
                                    <g id="mercuryplanet"/>
                                    <g id="mercurytext"/>
                                    <g id="venusplanet"/>
                                    <g id="venustext"/>
                                    <g id="marsplanet"/>
                                    <g id="marstext"/>
                                    <g id="jupiterplanet"/>
                                    <g id="jupitertext"/>
                                    <g id="saturnplanet"/>
                                    <g id="saturntext"/>
                                </g>
                                <defs>
                                    <radialGradient id="mercuryGrad"/>
                                    <radialGradient id="venusGrad"/>
                                    <radialGradient id="marsGrad"/>
                                    <radialGradient id="jupiterGrad"/>
                                    <radialGradient id="saturnGrad"/>
                                </defs>
                            </g>
                        </g>
                    </svg>
                `;
                
                reteBg.innerHTML = svgContent;
                
                // Define required variables for rete.js
                window.xmlns = "http://www.w3.org/2000/svg";
                window.obliquity = 23.4; // mean obliquity of the ecliptic
                window.e0 = 23.4; // same as obliquity
                window.Rcapricorn = 87; // tropic of capricorn
                window.Req = window.Rcapricorn/Math.tan((Math.PI/180)*(90+window.obliquity)/2);  // equator
                window.Rcancer = window.Req*Math.tan((Math.PI/180)*(90-window.obliquity)/2); // tropic of cancer
                window.Recliptic = (window.Rcapricorn+window.Rcancer)/2; // radius of ecliptic disk
                window.yce = window.Rcapricorn-window.Recliptic; // center of ecliptic disk
                
                // Create minimal jQuery-like function for rete.js
                window.$ = function(selector) {
                    const element = document.querySelector(selector);
                    return {
                        on: function(event, callback) {
                            if (element) element.addEventListener(event.replace('vmouse', 'mouse'), callback);
                            return this;
                        },
                        css: function(property, value) {
                            if (element && typeof property === 'string' && value) {
                                element.style[property] = value;
                            }
                            return this;
                        },
                        prop: function(prop, value) {
                            if (element && value !== undefined) {
                                element[prop] = value;
                            }
                            return this;
                        },
                        flipswitch: function(action) {
                            // Mock flipswitch method for compatibility
                            return this;
                        }
                    };
                };
                
                // Create minimal D3-like function for rete.js
                window.d3 = {
                    drag: function() {
                        return {
                            on: function(event, callback) {
                                return this;
                            }
                        };
                    },
                    select: function(selector) {
                        return {
                            call: function(dragBehavior) {
                                return this;
                            }
                        };
                    },
                    event: {
                        x: 0,
                        y: 0
                    }
                };
                
                // Load and execute the Turkish rete.js
                const script = document.createElement('script');
                script.src = '../differences_output/turkce_farkli/rete.js';
                script.onload = function() {
                    console.log('Rete.js loaded successfully');
                    
                    // Call the rete() function if it exists
                    if (typeof rete === 'function') {
                        try {
                            rete();
                            console.log('Rete function executed successfully');
                            
                            // Override the colors to match controller theme - light grey lines
                            const reteBrassGroup = document.getElementById('retebrassGroup');
                            if (reteBrassGroup) {
                                reteBrassGroup.setAttribute('stroke', 'rgba(180, 180, 180, 0.6)');
                                reteBrassGroup.setAttribute('fill', 'rgba(180, 180, 180, 0.05)');
                                reteBrassGroup.setAttribute('stroke-width', '0.8');
                                reteBrassGroup.style.opacity = '0.5';
                            }
                            
                            // Apply to all child elements too
                            const reteElements = reteBg.querySelectorAll('path, circle, ellipse, line, polygon, text');
                            reteElements.forEach(element => {
                                if (element.tagName === 'text') {
                                    element.style.display = 'none'; // Hide text elements
                                } else {
                                    element.setAttribute('stroke', 'rgba(180, 180, 180, 0.4)');
                                    if (element.getAttribute('fill') !== 'none') {
                                        element.setAttribute('fill', 'rgba(180, 180, 180, 0.05)');
                                    }
                                    element.setAttribute('stroke-width', '0.8');
                                }
                            });
                        } catch (e) {
                            console.error('Error executing rete function:', e);
                        }
                    } else {
                        console.error('rete function not found');
                    }
                };
                script.onerror = function() {
                    console.error('Failed to load rete.js');
                };
                document.head.appendChild(script);
            }
            
            // Load rete when page loads
            loadReteSVG();
            
        });
    </script>
</body>
</html>