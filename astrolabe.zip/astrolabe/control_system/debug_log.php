<?php
// Show recent error log entries
$logFile = ini_get('error_log');
if (!$logFile) {
    $logFile = 'C:\xampp\apache\logs\error.log'; // Default XAMPP path
}

echo "<h3>Error Log Location: $logFile</h3>";

if (file_exists($logFile)) {
    $lines = file($logFile);
    $recentLines = array_slice($lines, -50); // Last 50 lines
    
    echo "<pre>";
    foreach ($recentLines as $line) {
        if (strpos($line, '📧') !== false || strpos($line, '❌') !== false) {
            echo "<strong style='color: red;'>$line</strong>";
        } else {
            echo $line;
        }
    }
    echo "</pre>";
} else {
    echo "<p>Error log file not found at: $logFile</p>";
    echo "<p>Try checking: " . error_get_last()['message'] ?? 'No PHP errors' . "</p>";
}
?>