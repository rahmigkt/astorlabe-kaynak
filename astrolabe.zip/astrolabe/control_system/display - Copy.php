<!DOCTYPE html>
<html>
<head>
  <title>Astrolabe Projection Display</title>
  <meta name="viewport" content="width=device-width,user-scalable=yes,initial-scale=1" charset="UTF-8">
  
  <!-- Same stylesheets as index.html -->
  <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css" />
  <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile.icons-1.4.5.css" />
  <link rel="stylesheet" href="../style.css"> 
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Reem+Kufi:wght@400..700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=IM+Fell+English&display=swap"> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  
  <!-- Same scripts as index.html -->
  <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
  <script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
  <script src="../d3-dispatch.v1.min.js"></script>
  <script src="../d3-selection.v1.min.js"></script>
  <script src="../d3-drag.v1.min.js"></script>
  <script src="../astronomy.js"></script>
  <script src="../infrastructure.js"></script>
  <script src="../timewheels.js"></script>
  <script src="../nav_buttons.js"></script>
  <script src="../panel_buttons.js"></script>
  
  <script>
    // Language support (default to Latin)
    var savedLanguage = 'latin';
    var languageFolder = '../differences_output/latince_farkli';
    
    // Define required globals before loading scripts
    window.latitude = 40;
    window.longitude = 0;
    
    document.write('<script src="' + languageFolder + '/tympanum.js" id="tympanum-script"><\/script>');
    document.write('<script src="' + languageFolder + '/rete.js" id="rete-script"><\/script>');
    document.write('<script src="' + languageFolder + '/rete_51459.js" id="rete51459-script"><\/script>');
  </script>
  
  <script src="../revolve.js"></script>
  <script src="../stars.js"></script>
  <script src="../constellation_data.js"></script>
  <!-- Use original star chart module -->
  <script src="../star_chart.js"></script>
  <script src="../world_map_enhanced.js"></script>
  <script src="../iphone_sliders.js"></script>
  <script src="../geolocation.js"></script>
  <script src="../multi_calendar.js"></script>
  
  <style>
    /* Display mode specific styles - matching control.php background */
    html, body {
      margin: 0;
      padding: 0;
      background: #333333 !important;
      background-color: #333333 !important;
      color: #e0e0e0;
      font-family: 'Reem Kufi', 'IM Fell English', serif;
      overflow: hidden;
      min-height: 100vh;
    }
    
    /* Ephemeris table styles from index.html */
    #ephemerisDiv {
      margin-left: .2em;
      margin-right: .2em;
      margin-bottom: 1.5em;
      background: #2a2a2a;
      border: 1px solid rgba(204, 68, 68, 0.3);
      border-radius: 8px;
      padding: 1em;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
    }
    
    #ephemerisTable {
      display: table;
      margin: auto;
      border-collapse: collapse;
    }
    
    #ephemerisTable td {
      border: none;
      color: #e0e0e0;
      font-size: 16px; 
      text-shadow: 0 0 8px rgba(230, 243, 255, 0.3);
      font-family: 'Courier New', Courier, monospace;
      white-space: pre;
      text-align: right;
      padding-left: .7em;
      padding-right: .7em;
    }
    
    .graycell {
      background: #aa3333;
      border: 1px solid rgba(204, 68, 68, 0.2);
    }
    
    .zsign_eph {
      text-align: right;
      width: .8em;
      padding-right: 0em;
      padding-left: 0em;
    }
    
    .housedigit {
      font-family: 'Courier New', monospace;
      font-size: 14px;
    }
    
    /* Date/Time display styles */
    .datetime-display {
      position: absolute;
      left: 20px;
      top: 50%;
      transform: translateY(-50%);
      background: #2a2a2a;
      border: 1px solid rgba(204, 68, 68, 0.3);
      border-radius: 8px;
      padding: 1.5em;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
      color: #e0e0e0;
      font-family: 'Courier New', Courier, monospace;
      z-index: 10000;
      min-width: 200px;
    }
    
    .datetime-display h3 {
      margin: 0 0 1em 0;
      font-size: 1.2em;
      text-align: center;
      color: #e0e0e0;
      text-shadow: 0 0 10px rgba(230, 243, 255, 0.5);
      font-weight: bold;
      letter-spacing: 2px;
    }
    
    .datetime-display .date-row,
    .datetime-display .time-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 0.5em 0;
      padding: 0.5em;
      background: #aa3333;
      border: 1px solid rgba(204, 68, 68, 0.2);
      border-radius: 4px;
    }
    
    .datetime-display .label {
      font-weight: bold;
      color: #e0e0e0;
      margin-right: 1em;
      text-shadow: 0 0 5px rgba(230, 243, 255, 0.3);
    }
    
    .datetime-display .value {
      font-size: 1.1em;
      text-shadow: 0 0 5px rgba(230, 243, 255, 0.3);
      color: #e0e0e0;
      font-weight: bold;
    }
    
    /* Position ephemeris table on the right */
    .ephemeris-container {
      position: absolute;
      right: 20px;
      top: 50%;
      transform: translateY(-50%);
      z-index: 10000;
      max-height: 80vh;
      overflow-y: auto;
    }
    
    /* Override jQuery Mobile backgrounds */
    .ui-page, .ui-content, .page, #mainpage {
      background: #333333 !important;
      background-color: #333333 !important;
    }
    
    /* Override all divs backgrounds */
    div[data-role="page"], div[data-role="content"] {
      background: #333333 !important;
      background-color: #333333 !important;
    }
    
    /* Remove any jQuery Mobile themes */
    .ui-body-a, .ui-body-b, .ui-body-c, .ui-overlay-a {
      background: #333333 !important;
      background-color: #333333 !important;
    }
    
    /* Hide all control elements but keep DOM structure */
    #mainnavpanel,
    #settingspanel,
    .nav_buttons,
    .nav-button-wrapper,
    #navbutton_group,
    .toparrow,
    .ui-panel,
    .ui-panel-dismiss,
    .ui-panel-inner,
    #settings_button,
    .ui-collapsible,
    .ui-btn,
    .ui-link,
    .location-controls,
    .time-controls,
    #svg_buttons,
    #speedpar,
    #buttonpanel_group,
    .slider-container,
    .slider-wrapper {
      display: none !important;
      visibility: hidden !important;
    }
    
    /* Center the display */
    .main-container {
      width: 100vw;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
      overflow: visible;
    }
    
    .charts-wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;
      position: relative;
    }
    
    /* Astrolabe styling - exact same as index */
    .astrolabe-container {
      width: 90vmin;
      height: 90vmin;
      max-width: 1000px;
      max-height: 1000px;
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    
    #svg_astrolabe {
      width: 100%;
      height: 100%;
    }
    
    /* Star chart styling - exact same as index */
    .star-chart-container {
      width: 90vmin;
      height: 90vmin;
      max-width: 800px;
      max-height: 800px;
      position: absolute;
      display: none;
      justify-content: center;
      align-items: center;
    }
    
    /* Sync status indicator */
    .sync-status {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 8px 16px;
      background: rgba(0, 0, 0, 0.7);
      color: #00ff00;
      border: 1px solid #00ff00;
      border-radius: 20px;
      font-size: 12px;
      font-family: 'Courier New', monospace;
      display: flex;
      align-items: center;
      gap: 8px;
      z-index: 10000;
    }
    
    .sync-dot {
      width: 8px;
      height: 8px;
      background: #00ff00;
      border-radius: 50%;
      animation: pulse 1s infinite;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.3; }
    }
    
    .sync-status.disconnected {
      color: #ff0000;
      border-color: #ff0000;
    }
    
    .sync-status.disconnected .sync-dot {
      background: #ff0000;
      animation: none;
    }
    
    /* Display mode indicator */
    .display-mode {
      position: fixed;
      top: 20px;
      left: 20px;
      padding: 8px 16px;
      background: rgba(0, 0, 0, 0.7);
      color: #ffffff;
      border: 1px solid #ffffff;
      border-radius: 20px;
      font-size: 14px;
      font-family: 'Reem Kufi', sans-serif;
      z-index: 10000;
    }
  </style>
</head>

<body>
  <div id="mainpage" data-role="page" class="page">
    <!-- Sync status indicator -->
    <div class="sync-status">
      <div class="sync-dot"></div>
      <span id="sync-text">SYNCED</span>
    </div>
    
    <!-- Display mode indicator -->
    <div class="display-mode" id="display-mode">
      ASTROLABE
    </div>
    
    <!-- Main container -->
    <div class="main-container">
      <!-- Date/Time Display -->
      <div class="datetime-display">
      <h3>Date & Time</h3>
      <div class="date-row">
        <span class="label">Year:</span>
        <span class="value" id="year-display">2025</span>
      </div>
      <div class="date-row">
        <span class="label">Month:</span>
        <span class="value" id="month-display">1</span>
      </div>
      <div class="date-row">
        <span class="label">Day:</span>
        <span class="value" id="day-display">1</span>
      </div>
      <div class="time-row">
        <span class="label">Hour:</span>
        <span class="value" id="hour-display">12</span>
      </div>
      <div class="time-row">
        <span class="label">Minute:</span>
        <span class="value" id="minute-display">00</span>
      </div>
    </div>
    
    <!-- Ephemeris Table Container -->
    <div class="ephemeris-container">
      <div id="ephemerisDiv">
        <table id="ephemerisTable">
          <tr>
            <td id="col0" colspan="2" style="text-align:center;"></td>
            <td id="col1" colspan="2" style="text-align:center; font-weight:bold;">λ</td>
            <td id="col2" style="width:4em; text-align:center; font-weight:bold;">β</td>
            <td id="col3" style="width:4em; text-align:center; font-weight:bold;">RA</td>
            <td id="col4" style="width:4em; text-align:center; font-weight:bold;">Dec</td>
            <td id="col5" style="width:4em; text-align:center; font-weight:bold;">Az</td>
            <td id="col6" style="width:4em; text-align:center; font-weight:bold;">El</td>
            <td id="col7" colspan="2" style="text-align:center; font-weight:bold;">House</td>
          </tr>
          <tr id="saturnRow">
            <td id="saturnName" class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Saturn</td>
            <td id="saturnSign" class="graycell" style="text-align:center;">♄</td>
            <td id="saturnLambdaSign" class="zsign_eph"></td>
            <td id="saturnLambda" style="padding-left:0em;"></td>
            <td id="saturnBeta" class="graycell"></td>
            <td id="saturnAlpha"></td>
            <td id="saturnDelta" class="graycell"></td>
            <td id="saturnAZ"></td>
            <td id="saturnAL" class="graycell"></td>
            <td id="saturnHouse" class="housedigit" style="text-align:center; width:1em;"></td>
            <td id="saturnHouseVal" style="padding-left:0em; width:3.7em;"></td>
          </tr>   
          <tr id="jupiterRow">
            <td id="jupiterName" class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Jupiter</td>
            <td id="jupiterSign" class="graycell" style="text-align:center;">♃</td>
            <td id="jupiterLambdaSign" class="zsign_eph"></td>
            <td id="jupiterLambda" style="padding-left:0em;"></td>
            <td id="jupiterBeta" class="graycell"></td>
            <td id="jupiterAlpha"></td>
            <td id="jupiterDelta" class="graycell"></td>
            <td id="jupiterAZ"></td>
            <td id="jupiterAL" class="graycell"></td>
            <td id="jupiterHouse" class="housedigit" style="text-align:center; width:1em;"></td>
            <td id="jupiterHouseVal" style="padding-left:0em; width:3.7em;"></td>
          </tr>   
          <tr id="marsRow">
            <td id="marsName" class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Mars</td>
            <td id="marsSign" class="graycell" style="text-align:center;">♂</td>
            <td id="marsLambdaSign" class="zsign_eph"></td>
            <td id="marsLambda" style="padding-left:0em;"></td>
            <td id="marsBeta" class="graycell"></td>
            <td id="marsAlpha"></td>
            <td id="marsDelta" class="graycell"></td>
            <td id="marsAZ"></td>
            <td id="marsAL" class="graycell"></td>
            <td id="marsHouse" class="housedigit" style="text-align:center; width:1em;"></td>
            <td id="marsHouseVal" style="padding-left:0em; width:3.7em;"></td>
          </tr>   
          <tr id="venusRow">
            <td id="venusName" class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Venus</td>
            <td id="venusSign" class="graycell" style="text-align:center;">♀</td>
            <td id="venusLambdaSign" class="zsign_eph"></td>
            <td id="venusLambda" style="padding-left:0em;"></td>
            <td id="venusBeta" class="graycell"></td>
            <td id="venusAlpha"></td>
            <td id="venusDelta" class="graycell"></td>
            <td id="venusAZ"></td>
            <td id="venusAL" class="graycell"></td>
            <td id="venusHouse" class="housedigit" style="text-align:center; width:1em;"></td>
            <td id="venusHouseVal" style="padding-left:0em; width:3.7em;"></td>
          </tr>     
          <tr id="mercuryRow">
            <td id="mercuryName" class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Mercury</td>
            <td id="mercurySign" class="graycell" style="text-align:center;">☿</td>
            <td id="mercuryLambdaSign" class="zsign_eph"></td>
            <td id="mercuryLambda" style="padding-left:0em;"></td>
            <td id="mercuryBeta" class="graycell"></td>
            <td id="mercuryAlpha"></td>
            <td id="mercuryDelta" class="graycell"></td>
            <td id="mercuryAZ"></td>
            <td id="mercuryAL" class="graycell"></td>
            <td id="mercuryHouse" class="housedigit" style="text-align:center; width:1em;"></td>
            <td id="mercuryHouseVal" style="padding-left:0em; width:3.7em;"></td>
          </tr>   
          <tr id="moonRow">
            <td id="moonName" class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Moon</td>
            <td id="moonSign" class="graycell" style="text-align:center;">☽</td>
            <td id="moonLambdaSign" class="zsign_eph"></td>
            <td id="moonLambda" style="padding-left:0em;"></td>
            <td id="moonBeta" class="graycell"></td>
            <td id="moonAlpha"></td>
            <td id="moonDelta" class="graycell"></td>
            <td id="moonAZ"></td>
            <td id="moonAL" class="graycell"></td>
            <td id="moonHouse" class="housedigit" style="text-align:center; width:1em;"></td>
            <td id="moonHouseVal" style="padding-left:0em; width:3.7em;"></td>
          </tr>   
          <tr id="sunRow">
            <td id="sunName" class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Sun</td>
            <td id="sunSign" class="graycell" style="text-align:center;">☉</td>
            <td id="sunLambdaSign" class="zsign_eph"></td>
            <td id="sunLambda" style="padding-left:0em;"></td>
            <td id="sunBeta" class="graycell">0.0°</td>
            <td id="sunAlpha"></td>
            <td id="sunDelta" class="graycell"></td>
            <td id="sunAZ"></td>
            <td id="sunAL" class="graycell"></td>
            <td id="sunHouse" class="housedigit" style="text-align:center; width:1em;"></td>
            <td id="sunHouseVal" style="padding-left:0em; width:3.7em;"></td>
          </tr>   
          <tr id="ascendantRow">
            <td id="ascendantName" class="graycell" style="text-align:left; font-weight:bold; padding-right:0em;">Asc</td>
            <td id="ascendantSign" class="graycell" style="text-align:center;">Asc</td>
            <td id="ascendantLambdaSign" class="zsign_eph"></td>
            <td id="ascendantLambda" style="padding-left:0em;"></td>
            <td id="ascendantBeta" class="graycell">0.0°</td>
            <td id="ascendantAlpha"></td>
            <td id="ascendantDelta" class="graycell"></td>
            <td id="ascendantAZ">90.0°</td>
            <td id="ascendantAL" class="graycell">0.0°</td>
            <td id="ascendantHouse" class="housedigit" style="text-align:center; width:1em;">①</td>
            <td id="ascendantHouseVal" style="padding-left:0em; width:3.7em;">0°00'</td>
          </tr>  
        </table>
      </div>
      
      <!-- Charts wrapper moved inside main-container -->
      <ul data-role="listview">
        <li><a href="#">Hidden</a></li>
      </ul>
    </div>
    
    <div data-role="panel" id="settingspanel" style="display:none;">
      <ul data-role="listview">
        <li><a href="#">Hidden</a></li>
      </ul>
    </div>
    
    <!-- Main content area -->
    <div data-role="content" class="ui-content" style="padding: 0;">
      <!-- Header area with hidden navigation -->
      <div class="nav_buttons" style="display:none;">
        <svg id="svg_toparrow1" class="svgx" width="2.5em" viewBox="0 0 10 10"></svg>
        <svg id="svg_toparrow2" class="svgx" width="2.5em" viewBox="0 0 10 10"></svg>
        <svg id="svg_toparrow3" class="svgx" width="2.5em" viewBox="0 0 10 10"></svg>
        <svg id="svg_toparrow4" class="svgx" width="2.5em" viewBox="0 0 10 10"></svg>
      </div>
      
      <!-- Time display elements (hidden but present for scripts) -->
      <div id="svg_wheel" style="display:none;"></div>
      <svg id="time_svg" style="display:none;"></svg>
      
      <!-- Time wheels SVG structure required by timewheels.js -->
      <svg id="svg_wheels" class="svgx" width="100%" viewBox="0 0 90 20" style="display:none;">
        <defs>
          <linearGradient id="silver"/>
        </defs>
        <g transform="matrix(1,0,0,-1,45,10)">
          <g id="wheelgroup" stroke="none">
            <rect id="yearwheel" x="0" y="0" width="0" height="0"/>
            <rect id="monthwheel" x="0" y="0" width="0" height="0"/>
            <rect id="daywheel" x="0" y="0" width="0" height="0"/>
            <rect id="hourwheel" x="0" y="0" width="0" height="0"/>
            <rect id="minutewheel" x="0" y="0" width="0" height="0"/>
          </g>
          <g id="wheel_textgroup" transform="matrix(1,0,0,-1,0,0)" font-size="5" font-family="monospace" stroke="none" text-anchor="middle">
            <g id="centuryblock_group"/>
            <g id="monthwheel_textgroup" transform="translate(0,1.5)"/>
            <g id="daywheel_textgroup_365" transform="translate(0,1.5)" visibility="visible"/>
            <g id="daywheel_textgroup_366" transform="translate(0,1.5)" visibility="hidden"/>
            <g id="daywheel_textgroup_355" transform="translate(0,1.5)" visibility="hidden"/>
            <g id="hourwheel_textgroup" transform="translate(0,1.5)"/>
            <g id="minutewheel_textgroup" transform="translate(0,1.5)"/>
          </g>
          <g id="wheelbox" stroke="none" fill="rgba(0,0,0,0)">
            <rect id="yearbox" x="0" y="0" width="0" height="0"/>
            <rect id="monthbox" x="0" y="0" width="0" height="0"/>
            <rect id="daybox" x="0" y="0" width="0" height="0"/>
            <rect id="hourbox" x="0" y="0" width="0" height="0"/>
            <rect id="minutebox" x="0" y="0" width="0" height="0"/>
          </g>
          <rect id="topshield" x="-50" y="0" width="100" height="50" fill="transparent" opacity="0"/>
          <rect id="bottomshield" x="-50" y="-50" width="100" height="50" fill="transparent" opacity="0"/>
        </g>
      </svg>
      
      <g id="month_wheel_g" style="display:none;"></g>
      <g id="day_wheel_g" style="display:none;"></g>
      <g id="hour_wheel_g" style="display:none;"></g>
      <g id="minute_wheel_g" style="display:none;"></g>
      <g id="second_wheel_g" style="display:none;"></g>
      <g id="year_wheel_g" style="display:none;"></g>
        <div class="charts-wrapper">
          <!-- Astrolabe Container -->
          <div class="astrolabe-container" id="astrolabe-display">
            <svg id="svg_astrolabe" class="svgx" viewBox="0 -30 210 240">
              <defs>
                <linearGradient id="brass"/>
                <radialGradient id="twilight"/>
                <radialGradient id="starglow"/>
                <clipPath id="skyClip">
                  <path id="skyClipPath" d=""/>
                </clipPath>
                <clipPath id="belowHorizonClip">
                  <path id="belowHorizonClipPath" d=""/>
                </clipPath>
                <clipPath id="CapricornClip">
                  <circle id="CapricornClipCircle" cx="0" cy="0" r="0"/>
                </clipPath>
              </defs>
              
              <!-- Head group -->
              <g id="headGroup" fill="none" stroke="none" transform="matrix(1,0,0,-1,105,105) rotate(0)">
                <!-- Head SVG content will be loaded here -->
              </g>
              
              <!-- Mater group with ALL required sub-elements -->
              <g id="mater_group" fill="none" stroke="none" transform="matrix(1,0,0,-1,105,105)">   
                <circle id="mater" cx="0" cy="0" r="0"/>
                <path id="limb" d=""/>
                <g id="limb_markings_group"/>
                <circle id="tropicOfCapricorn" cx="0" cy="0" r="0"/>
                <path id="south_out" d=""/>
                <path id="north_out" d=""/>
                <path id="east_out" d=""/>
                <path id="west_out" d=""/>
                <path id="eq_out" d=""/>
                <path id="cancer_out" d=""/>
                <path id="sky" d=""/>
                <circle id="halo" cx="0" cy="0" r="0"/>
                
                <g id="skyGroup">
                  <path id="east_in" d=""/>
                  <path id="west_in" d=""/>
                  <path id="eq_in1" d=""/>
                  <path id="eq_in2" d=""/>
                  <path id="cancer_in1" d=""/>
                  <path id="cancer_in2" d=""/>
                  <g id="altitudeGroup"/> 
                  <g id="azimuthGroup">  
                    <path id="south_in" d=""/>
                    <path id="north_in" d=""/>
                    <path id="east_in90" d=""/>
                    <path id="west_in90" d=""/>
                    <path id="eq_in0_1" d=""/>
                    <path id="eq_in0_2" d=""/>
                  </g>
                  <g id="cusps_above_horizon">  
                    <path id="cusp8" d=""/>
                    <path id="cusp9" d=""/>
                    <path id="cusp11" d=""/>
                    <path id="cusp12" d=""/>
                    <g id="uppercusps_textgroup">
                      <g id="uppercusps_textgroup_inner">
                        <text id="cusp7text" x="0" y="0">7</text>
                        <text id="cusp8text" x="0" y="0">8</text>
                        <text id="cusp9text" x="0" y="0">9</text>
                        <text id="cusp10text" x="0" y="0">10</text>
                        <text id="cusp11text" x="0" y="0">11</text>
                        <text id="cusp12text" x="0" y="0">12</text>
                      </g>
                    </g>
                  </g>
                  <g style="clip-path:url(#skyClip);">
                    <g id="starGroup" stroke="none" transform="rotate(0)"/>
                  </g>
                </g>
                
                <path id="sky_outline" d=""/>
                <g id="cusps_below_horizon">  
                  <path id="cusp2" d=""/>
                  <path id="cusp2a" d=""/>
                  <path id="cusp3" d=""/>
                  <path id="cusp3a" d=""/>
                  <path id="cusp5" d=""/>
                  <path id="cusp5a" d=""/>
                  <path id="cusp6" d=""/>
                  <path id="cusp6a" d=""/>
                  <g id="lowercusps_textgroup">
                    <text id="cusp1text" x="0" y="0">1</text>
                    <text id="cusp2text" x="0" y="0">2</text>
                    <text id="cusp3text" x="0" y="0">3</text>
                    <text id="cusp4text" x="0" y="0">4</text>
                    <text id="cusp5text" x="0" y="0">5</text>
                    <text id="cusp6text" x="0" y="0">6</text>
                  </g>
                </g>
                
                <g id="nocturnalGroup" visibility="hidden"/>
                <g id="highlightGroup" fill="none" stroke="none" stroke-width="1">
                  <circle id="capricorn_highlight" cx="0" cy="0" r="0"/>
                  <circle id="equator_highlight" cx="0" cy="0" r="0"/>
                  <circle id="cancer_highlight" cx="0" cy="0" r="0"/>
                  <g id="regiomontanus_group"/>
                  <g id="prayerline_group">
                    <path id="fajr" d="" fill="none" stroke="none"/>
                    <path id="shafaq" d="" fill="none" stroke="none"/>
                    <circle id="twilight_circle" cx="0" cy="0" r="0" fill="none" stroke="none"/>
                    <path id="asr" d="" fill="none" stroke="none"/>
                    <path id="zuhr" d="" fill="none" stroke="none"/>
                  </g>
                </g>
                
                <g id="horizon_group" fill="none"/>
                <g id="unequal_group" fill="none"/>
                <g id="belowHorizon_group" fill="none"/>
              </g>
              
              <!-- Upper layer -->
              <g id="upperlayer" fill="none" stroke="none" transform="matrix(1,0,0,-1,105,105)">
                <defs>
                  <radialGradient id="mercuryGrad"/>
                  <radialGradient id="venusGrad"/>
                  <radialGradient id="marsGrad"/>
                  <radialGradient id="jupiterGrad"/>
                  <radialGradient id="saturnGrad"/>
                </defs> 
                <g id="reteLayer" transform="rotate(0)">
                  <g id="alchabitius_group" stroke-width="1"/>
                  
                  <g id="reteGroup_default" class="rete_group active_rete">
                    <g id="retebrassGroup" class="rete">
                      <path id="capella" d=""/>
                      <path id="retePath"/>
                      <g id="reteMarks"/>
                      <g id="starnames_textgroup"/>
                      <g id="starpointer_group" transform="rotate(-270)" fill-rule="evenodd"/>
                    </g>
                    <g id="eclipticGroup" class="ecliptic">
                      <path id="ecliptic" d=""/>
                      <g id="eclipticMarks" class="ecliptic_marks"/>
                    </g>
                  </g>
                  
                  <g id="reteGroup_51459" class="rete_group inactive_rete"/>
                </g>
                
                <g id="ruleGroup"/>
                <g id="planetsGroup">    
                  <g id="saturnGroup">
                    <circle id="saturnplanet" cx="0" cy="0" r="0" fill="url(#saturnGrad)"/>
                    <text id="saturntext" x="0" y="0">♄</text>
                  </g>
                  <g id="jupiterGroup">
                    <circle id="jupiterplanet" cx="0" cy="0" r="0" fill="url(#jupiterGrad)"/>
                    <text id="jupitertext" x="0" y="0">♃</text>
                  </g>
                  <g id="marsGroup">
                    <circle id="marsplanet" cx="0" cy="0" r="0" fill="url(#marsGrad)"/>
                    <text id="marstext" x="0" y="0">♂</text>
                  </g>
                  <g id="sunGroup"/>
                  <g id="venusGroup">
                    <circle id="venusplanet" cx="0" cy="0" r="0" fill="url(#venusGrad)"/>
                    <text id="venustext" x="0" y="0">♀</text>
                  </g>
                  <g id="mercuryGroup">
                    <circle id="mercuryplanet" cx="0" cy="0" r="0" fill="url(#mercuryGrad)"/>
                    <text id="mercurytext" x="0" y="0">☿</text>
                  </g>
                  <g id="moonGroup"/>
                </g>              
              </g>
              
              <!-- OLD Rete/Rule groups for compatibility -->
              <g id="rete_group" fill="none" stroke="rgb(95,85,75)" stroke-width="0.25" transform="matrix(1,0,0,-1,105,105)">
                <g id="rete_51459_group" fill="none" stroke="none"/>
                <g id="monthMarkings_group"/>
                <circle id="tropicOfCancer" cx="0" cy="0" r="0"/>
                <circle id="tropicOfCapricornSmall" cx="0" cy="0" r="0"/>
                <g id="stars_group" stroke="none" fill="rgb(95,85,75)"/>
                <g id="pointers_group" stroke="rgb(95,85,75)" fill="none" stroke-width="0.25"/>
              </g>
              
              <g id="rule_group" fill="none" stroke="none" transform="matrix(1,0,0,-1,105,105) rotate(0)">
                <line id="rule" x1="0" y1="0" x2="0" y2="0"/>
                <g id="rule_markings_group" fill="none" stroke="none" stroke-width="0.25"/>
              </g>
            </svg>
          </div>
          
          <!-- Star Chart Container -->
          <div class="star-chart-container" id="star-chart-display" style="max-width: 600px; min-width: 400px; width: 90vmin; height: 90vmin; display: none;">
            <div class="star-chart-wrapper" style="padding: 0; border: none; box-shadow: none; position: relative;">
              <div style="position: relative; width: 100%; padding-bottom: 100%; overflow: hidden; border-radius: 50%;">
                <!-- Star chart layer with mask (bottom layer) -->
                <div style="position: absolute; top: 10%; left: 10%; width: 80%; height: 80%; z-index: 3; overflow: hidden; border-radius: 50%;">
                  <svg viewBox="0 0 100 100" style="width: 100%; height: 100%; position: relative; z-index: 1;">
                    <defs>
                      <!-- Radial gradient for non-visible space -->
                      <radialGradient id="spaceGradientDisplay" cx="50%" cy="50%">
                        <stop offset="0%" style="stop-color:#ff4444; stop-opacity:0.6"/>
                        <stop offset="30%" style="stop-color:#cc2222; stop-opacity:0.4"/>
                        <stop offset="60%" style="stop-color:#881111; stop-opacity:0.2"/>
                        <stop offset="100%" style="stop-color:#440000; stop-opacity:0.05"/>
                      </radialGradient>
                      
                      <!-- Inverse mask for non-visible area -->
                      <mask id="nonVisibleSkyMaskDisplay">
                        <!-- White background (everything visible) -->
                        <rect x="0" y="0" width="100" height="100" fill="white"/>
                        <!-- Black ellipse for visible area (to hide) -->
                        <ellipse id="nonVisibleAreaDisplay" cx="50" cy="50" rx="49" ry="49" fill="black"/>
                      </mask>
                      
                      <!-- Visible sky mask - unique ID for display page -->
                      <mask id="visibleSkyMaskDisplay">
                        <!-- Black background (everything hidden) -->
                        <rect x="0" y="0" width="100" height="100" fill="black"/>
                        <!-- White ellipse for visible area -->
                        <ellipse id="visibleAreaDisplay" cx="50" cy="50" rx="49" ry="49" fill="white"/>
                      </mask>
                    </defs>
                    
                    <!-- Starwheel layers -->
                    <g>
                      <!-- Dark background for contrast -->
                      <rect x="0" y="0" width="100" height="100" fill="#0a0a0a"/>
                      
                      <!-- Dimmed star chart (below horizon) -->
                      <image href="../starwheel_40N_en.svg" x="0" y="0" width="100" height="100"
                             style="opacity: 0.15;" id="starwheel-dim"/>
                      
                      <!-- Red gradient overlay for non-visible space -->
                      <rect x="0" y="0" width="100" height="100"
                            fill="url(#spaceGradientDisplay)"
                            mask="url(#nonVisibleSkyMaskDisplay)"
                            style="pointer-events: none;"/>
                      
                      <!-- Visible star chart (above horizon) with increased brightness -->
                      <image href="../starwheel_40N_en.svg" x="0" y="0" width="100" height="100"
                             mask="url(#visibleSkyMaskDisplay)"
                             style="filter: brightness(1.2) contrast(1.1);"
                             id="starwheel-visible"/>
                    </g>
                  </svg>
                </div>
                
                <!-- Star clock layer (middle layer) -->
                <div id="star-clock-container" style="position: absolute; width: 100%; height: 100%; z-index: 5;">
                  <img id="star-clock" src="../yildiz_saat.svg"
                       style="width: 100%; height: 100%;" />
                </div>
                
                <!-- Frame layer (top layer) -->
                <img src="../yildiz_cerceve.svg"
                     style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 10; pointer-events: none;" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Hidden navigation panels (required by scripts but hidden) -->
    <div data-role="panel" id="mainnavpanel" style="display:none;">
      <ul data-role="listview">
        <li><a href="#">Hidden</a></li>
      </ul>
    </div>
    
    <div data-role="panel" id="settingspanel" style="display:none;">
      <ul data-role="listview">
        <li><a href="#">Hidden</a></li>
      </ul>
    </div>
    
    <!-- Button Panel (hidden but present for scripts) -->
      <div style="display:none;">
        <svg id="svg_buttons" width="100%" viewBox="0 0 100 16">
          <defs>
            <radialGradient id="buttonglow"/>
          </defs>
          <g id="buttonpanel_group" transform="matrix(1,0,0,-1,50,8)">
            <g id="now_button_group" class="panel_button"/>
            <g id="stop_button_group" class="panel_button"/>
            <g id="ff_button_group" class="panel_button"/>
            <g id="rr_button_group" class="panel_button"/>
          </g> 
        </svg>
        <p id="speedpar" class="timetable"></p>
      </div>
      
      <!-- Settings elements (hidden but present) -->
      <div data-role="collapsible-set" style="display:none;">
        <div data-role="collapsible" id="settings_button">
          <h3><p class="menutitle">Settings</p></h3>
          <input type="number" name="year_numberinput" id="year_numberinput" value="0">
          <select name="month_select" id="month_select"></select>
          <select name="day_select" id="day_select"></select>
          <select name="hour_select" id="hour_select"></select>
          <select name="minute_select" id="minute_select"></select>
          <input type="range" name="timeZoneSlider" id="timeZoneSlider" value="0" min="-12" max="12" step="1" />
          <svg id="svg_radio1" class="svgx" width="100%" viewBox="0 0 36 10"/>
          <svg id="svg_radio2" class="svgx" width="100%" viewBox="0 0 36 10"/>
        </div>
      </div>
      
      <!-- Hidden controls for synchronization -->
      <input type="hidden" id="latitude" value="40">
      <input type="hidden" id="longitude" value="0">
      <input type="hidden" id="latitudeSlider" value="40">
      <input type="hidden" id="longitudeSlider" value="0">
      <span id="julian_day_local" style="display:none;">2460563.5</span>
      <span id="julian_day" style="display:none;">2460563.5</span>
      <span id="lmst_span" style="display:none;">0</span>
      <span id="local_year" style="display:none;">2025</span>
      <span id="local_month" style="display:none;">9</span>
      <span id="local_day" style="display:none;">4</span>
      <span id="local_hour" style="display:none;">12</span>
      <span id="local_minutes" style="display:none;">0</span>
      <span id="local_seconds" style="display:none;">0</span>
      <span id="lonspan" style="display:none;">0°</span>
      <span id="sky_flag" style="display:none;">0</span>
      <span id="dst_radiospan" style="display:none;">0</span>
      <span id="location-name-display" style="display:none;">--</span>
      
      <!-- Hidden diagnostic elements for timewheels.js -->
      <span id="minutewheel_y" style="display:none;"></span>
      <span id="minutewheel_val" style="display:none;">0</span>
      <span id="minutewheel_dy" style="display:none;"></span>
      <span id="hourwheel_y" style="display:none;"></span>
      <span id="hourwheel_val" style="display:none;">12</span>
      <span id="hourwheel_dy" style="display:none;"></span>
      <span id="daywheel_y" style="display:none;"></span>
      <span id="daywheel_val" style="display:none;">1</span>
      <span id="daywheel_dy" style="display:none;"></span>
      <span id="monthwheel_y" style="display:none;"></span>
      <span id="monthwheel_val" style="display:none;">1</span>
      <span id="monthwheel_dy" style="display:none;"></span>
      <span id="yearwheel_y" style="display:none;"></span>
      <span id="yearwheel_val" style="display:none;">2025</span>
      <span id="yearwheel_dy" style="display:none;"></span>
      <span id="daysinyear" style="display:none;">365</span>
      <span id="leapyearval" style="display:none;">0</span>
      <span id="oldLeap_buffer" style="display:none;">0</span>
      
      <!-- Additional hidden elements for infrastructure.js -->
      <input type="hidden" id="longitude" value="0">
      <input type="hidden" id="daylightsaving" value="0">
      <input type="hidden" id="utc_offset" value="0">
      <span id="latspan" style="display:none;">40°</span>
      
      <!-- Planet ephemeris elements - COMPLETE -->
      <span id="moonAlpha" style="display:none;">0</span>
      <span id="moonDelta" style="display:none;">0</span>
      <span id="moonLambdaSign" style="display:none;">0</span>
      <span id="moonLambda" style="display:none;">0</span>
      <span id="moonBeta" style="display:none;">0</span>
      <span id="moonAZ" style="display:none;">0</span>
      <span id="moonAL" style="display:none;">0</span>
      <span id="moonHouse" style="display:none;">0</span>
      <span id="moonHouseVal" style="display:none;">0</span>
      
      <span id="sunAlpha" style="display:none;">0</span>
      <span id="sunDelta" style="display:none;">0</span>
      <span id="sunLambdaSign" style="display:none;">0</span>
      <span id="sunLambda" style="display:none;">0</span>
      <span id="sunBeta" style="display:none;">0</span>
      <span id="sunAZ" style="display:none;">0</span>
      <span id="sunAL" style="display:none;">0</span>
      <span id="sunHouse" style="display:none;">0</span>
      <span id="sunHouseVal" style="display:none;">0</span>
      
      <span id="mercuryAlpha" style="display:none;">0</span>
      <span id="mercuryDelta" style="display:none;">0</span>
      <span id="mercuryLambdaSign" style="display:none;">0</span>
      <span id="mercuryLambda" style="display:none;">0</span>
      <span id="mercuryBeta" style="display:none;">0</span>
      <span id="mercuryAZ" style="display:none;">0</span>
      <span id="mercuryAL" style="display:none;">0</span>
      <span id="mercuryHouse" style="display:none;">0</span>
      <span id="mercuryHouseVal" style="display:none;">0</span>
      
      <span id="venusAlpha" style="display:none;">0</span>
      <span id="venusDelta" style="display:none;">0</span>
      <span id="venusLambdaSign" style="display:none;">0</span>
      <span id="venusLambda" style="display:none;">0</span>
      <span id="venusBeta" style="display:none;">0</span>
      <span id="venusAZ" style="display:none;">0</span>
      <span id="venusAL" style="display:none;">0</span>
      <span id="venusHouse" style="display:none;">0</span>
      <span id="venusHouseVal" style="display:none;">0</span>
      
      <span id="marsAlpha" style="display:none;">0</span>
      <span id="marsDelta" style="display:none;">0</span>
      <span id="marsLambdaSign" style="display:none;">0</span>
      <span id="marsLambda" style="display:none;">0</span>
      <span id="marsBeta" style="display:none;">0</span>
      <span id="marsAZ" style="display:none;">0</span>
      <span id="marsAL" style="display:none;">0</span>
      <span id="marsHouse" style="display:none;">0</span>
      <span id="marsHouseVal" style="display:none;">0</span>
      
      <span id="jupiterAlpha" style="display:none;">0</span>
      <span id="jupiterDelta" style="display:none;">0</span>
      <span id="jupiterLambdaSign" style="display:none;">0</span>
      <span id="jupiterLambda" style="display:none;">0</span>
      <span id="jupiterBeta" style="display:none;">0</span>
      <span id="jupiterAZ" style="display:none;">0</span>
      <span id="jupiterAL" style="display:none;">0</span>
      <span id="jupiterHouse" style="display:none;">0</span>
      <span id="jupiterHouseVal" style="display:none;">0</span>
      
      <span id="saturnAlpha" style="display:none;">0</span>
      <span id="saturnDelta" style="display:none;">0</span>
      <span id="saturnLambdaSign" style="display:none;">0</span>
      <span id="saturnLambda" style="display:none;">0</span>
      <span id="saturnBeta" style="display:none;">0</span>
      <span id="saturnAZ" style="display:none;">0</span>
      <span id="saturnAL" style="display:none;">0</span>
      <span id="saturnHouse" style="display:none;">0</span>
      <span id="saturnHouseVal" style="display:none;">0</span>
      
      <!-- Ascendant elements -->
      <span id="mc_span" style="display:none;">0</span>
      <span id="asc_span" style="display:none;">0</span>
      <span id="ascendantAlpha" style="display:none;">0</span>
      <span id="ascendantDelta" style="display:none;">0</span>
      <span id="ascendantLambdaSign" style="display:none;">0</span>
      <span id="ascendantLambda" style="display:none;">0</span>
      <span id="ascendantAZ" style="display:none;">0</span>
      
      <!-- Panel button status elements -->
      <span id="run_status" style="display:none;">run</span>
      <span id="ff_speed" style="display:none;">0</span>
      <span id="rr_speed" style="display:none;">0</span>
    </div>
  </div>
  
  <!-- Synchronization script -->
  <script src="includes/common.js"></script>
  <script>
  $(document).ready(function() {
    // Get session key
    const sessionKey = AstrolabeCommon.getSessionKey();
    
    console.log('=== DISPLAY PANEL DEBUG ===');
    console.log('Session Key:', sessionKey);
    console.log('Initial latitude:', window.latitude);
    console.log('Initial longitude:', window.longitude);
    
    // Disable star chart rotation for display mode
    window.disableStarChartRotation = true;
    
    // Initialize display
    let currentDisplay = 'astrolabe';
    let lastUpdate = Date.now();
    let isConnected = true;
    
    // Store previous state to detect changes
    let previousState = {
      latitude: null,
      longitude: null,
      julian_day: null,
      local_year: null,
      local_month: null,
      local_day: null,
      local_hour: null,
      local_minute: null,
      local_second: null,
      mask_rotation: null,
      star_chart_visible: null,
      astrolabe_visible: null,
      sky_coloration: null
    };
    
    // Function to update ephemeris table values
    function updateEphemerisTable() {
      // Get values from hidden spans and update table cells
      const planets = ['saturn', 'jupiter', 'mars', 'venus', 'mercury', 'moon', 'sun'];
      
      planets.forEach(planet => {
        // Get all values from spans
        const lambdaSign = $('#' + planet + 'LambdaSign').text();
        const lambda = $('#' + planet + 'Lambda').text();
        const beta = $('#' + planet + 'Beta').text();
        const alpha = $('#' + planet + 'Alpha').text();
        const delta = $('#' + planet + 'Delta').text();
        const az = $('#' + planet + 'AZ').text();
        const al = $('#' + planet + 'AL').text();
        const house = $('#' + planet + 'House').text();
        const houseVal = $('#' + planet + 'HouseVal').text();
        
        // Update table cells
        $('#' + planet + 'Row td:eq(2)').text(lambdaSign); // Lambda Sign column
        $('#' + planet + 'Row td:eq(3)').text(lambda); // Lambda column
        $('#' + planet + 'Row td:eq(4)').text(beta); // Beta column
        $('#' + planet + 'Row td:eq(5)').text(alpha); // Alpha column
        $('#' + planet + 'Row td:eq(6)').text(delta); // Delta column
        $('#' + planet + 'Row td:eq(7)').text(az); // Azimuth column
        $('#' + planet + 'Row td:eq(8)').text(al); // Altitude column
        $('#' + planet + 'Row td:eq(9)').text(house); // House column
        $('#' + planet + 'Row td:eq(10)').text(houseVal); // House Value column
      });
      
      // Update ascendant separately
      const ascLambdaSign = $('#ascendantLambdaSign').text();
      const ascLambda = $('#ascendantLambda').text();
      const ascAlpha = $('#ascendantAlpha').text();
      const ascDelta = $('#ascendantDelta').text();
      
      $('#ascendantRow td:eq(2)').text(ascLambdaSign);
      $('#ascendantRow td:eq(3)').text(ascLambda);
      $('#ascendantRow td:eq(5)').text(ascAlpha);
      $('#ascendantRow td:eq(6)').text(ascDelta);
    }
    
    // Function to switch display
    function switchDisplay(mode) {
      console.log('🖥️ DISPLAY: Switching to mode:', mode);
      currentDisplay = mode;
      
      if (mode === 'astrolabe') {
        $('#astrolabe-display').show();
        $('#star-chart-display').hide();
        $('#display-mode').text('ASTROLABE');
      } else if (mode === 'starchart') {
        $('#astrolabe-display').hide();
        $('#star-chart-display').show();
        $('#display-mode').text('STAR CHART');
        
        // Initialize star chart if needed
        if (typeof window.StarChart !== 'undefined') {
          // Check if star chart is already initialized
          if (!window.starChartInitialized) {
            // HTML structure is already in place, just sync with astrolabe
            if (typeof window.StarChart.syncWithAstrolabe === 'function') {
              window.StarChart.syncWithAstrolabe();
              window.starChartInitialized = true;
            }
          } else {
            // Just update the chart
            if (typeof window.StarChart.updateStarChart === 'function') {
              window.StarChart.updateStarChart();
            }
          }
        }
      }
    }
    
    // Polling function for state updates
    async function pollForUpdates() {
      try {
        const state = await AstrolabeCommon.fetchState(sessionKey);
        
        if (state && state.state) {
          // Update connection status
          lastUpdate = Date.now();
          if (!isConnected) {
            isConnected = true;
            $('.sync-status').removeClass('disconnected');
            $('#sync-text').text('SYNCED');
          }
          
          // Apply state updates
          const data = state.state;
          
          // Track if we need to update tympanum (only if latitude changes)
          let needsTympanumUpdate = false;
          
          // Track if we need to update planets (only if time changes)
          let needsPlanetUpdate = false;
          
          // Update latitude/longitude
          if (data.latitude !== undefined && data.latitude !== previousState.latitude) {
            console.log('📍 DISPLAY: Latitude changed from', previousState.latitude, 'to', data.latitude);
            $('#latitude').val(data.latitude);
            $('#latitudeSlider').val(data.latitude);
            if (window.latitude !== undefined) window.latitude = parseFloat(data.latitude);
            
            // Update latspan
            const lat = parseFloat(data.latitude);
            const dir = lat >= 0 ? 'N' : 'S';
            $('#latspan').text(Math.abs(lat).toFixed(1) + '°' + dir);
            
            previousState.latitude = data.latitude;
            needsTympanumUpdate = true;
          }
          
          if (data.longitude !== undefined && data.longitude !== previousState.longitude) {
            console.log('📍 DISPLAY: Longitude changed from', previousState.longitude, 'to', data.longitude);
            $('#longitude').val(data.longitude);
            $('#longitudeSlider').val(data.longitude);
            if (window.longitude !== undefined) window.longitude = parseFloat(data.longitude);
            
            // Update lonspan
            const lon = parseFloat(data.longitude);
            const dir = lon >= 0 ? 'E' : 'W';
            $('#lonspan').text(Math.abs(lon).toFixed(1) + '°' + dir);
            
            previousState.longitude = data.longitude;
            needsPlanetUpdate = true;
          }
          
          // Update date/time - check if any time component changed
          if (data.local_year && data.local_year !== previousState.local_year) {
            $('#local_year').text(data.local_year);
            $('#year-display').text(data.local_year);
            previousState.local_year = data.local_year;
            needsPlanetUpdate = true;
          }
          if (data.local_month && data.local_month !== previousState.local_month) {
            $('#local_month').text(data.local_month);
            $('#month-display').text(data.local_month);
            previousState.local_month = data.local_month;
            needsPlanetUpdate = true;
          }
          if (data.local_day && data.local_day !== previousState.local_day) {
            $('#local_day').text(data.local_day);
            $('#day-display').text(data.local_day);
            previousState.local_day = data.local_day;
            needsPlanetUpdate = true;
          }
          if (data.local_hour !== undefined && data.local_hour !== previousState.local_hour) {
            $('#local_hour').text(data.local_hour);
            $('#hour-display').text(data.local_hour.toString().padStart(2, '0'));
            previousState.local_hour = data.local_hour;
            needsPlanetUpdate = true;
          }
          if (data.local_minute !== undefined && data.local_minute !== previousState.local_minute) {
            $('#local_minutes').text(data.local_minute);
            $('#minute-display').text(data.local_minute.toString().padStart(2, '0'));
            previousState.local_minute = data.local_minute;
            needsPlanetUpdate = true;
          }
          if (data.local_second !== undefined && data.local_second !== previousState.local_second) {
            $('#local_seconds').text(data.local_second);
            previousState.local_second = data.local_second;
            needsPlanetUpdate = true;
          }
          if (data.julian_day && data.julian_day !== previousState.julian_day) {
            $('#julian_day_local').text(data.julian_day);
            $('#julian_day').text(data.julian_day);
            previousState.julian_day = data.julian_day;
            needsPlanetUpdate = true;
          }
          
          // Update display mode only if changed
          const shouldShowStarChart = data.star_chart_visible && !data.astrolabe_visible;
          const previousShowStarChart = previousState.star_chart_visible && !previousState.astrolabe_visible;
          if (shouldShowStarChart !== previousShowStarChart) {
            switchDisplay(shouldShowStarChart ? 'starchart' : 'astrolabe');
            previousState.star_chart_visible = data.star_chart_visible;
            previousState.astrolabe_visible = data.astrolabe_visible;
          }
          
          // Update sky coloration only if changed
          if (data.sky_coloration !== undefined && data.sky_coloration !== previousState.sky_coloration) {
            $('#sky_flag').text(data.sky_coloration ? '1' : '0');
            if (data.sky_coloration && typeof sky_coloration === 'function') {
              sky_coloration();
            }
            previousState.sky_coloration = data.sky_coloration;
          }
          
          // Update mask rotation if available and changed
          if (data.mask_rotation !== undefined && data.mask_rotation !== previousState.mask_rotation) {
            console.log('🎭 DISPLAY: Mask rotation changed from', previousState.mask_rotation, 'to', data.mask_rotation);
            
            // Apply mask rotation to astrolabe display
            const reteLayer = document.getElementById('reteLayer');
            if (reteLayer) {
              const rotation = parseFloat(data.mask_rotation);
              reteLayer.setAttribute('transform', `rotate(${rotation})`);
            }
            
            // Store mask rotation globally for star chart module to use
            window.currentMaskRotation = parseFloat(data.mask_rotation);
            
            // Update star chart mask if visible
            if (currentDisplay === 'starchart') {
              if (typeof window.StarChart !== 'undefined' && window.StarChart.updateStarChart) {
                window.StarChart.updateStarChart();
              }
            }
            
            previousState.mask_rotation = data.mask_rotation;
          }
          
          // Only call tympanum if latitude changed
          if (needsTympanumUpdate && typeof tympanum === 'function') {
            console.log('🔄 DISPLAY: Updating tympanum due to latitude change');
            tympanum();
          }
          
          // Only call planet_advance if time/location changed
          if (needsPlanetUpdate && typeof planet_advance === 'function') {
            console.log('🔄 DISPLAY: Updating planets due to time/location change');
            planet_advance();
            
            // Update ephemeris table values
            updateEphemerisTable();
          }
          
          // Update star chart location if it changed
          if ((data.latitude !== undefined || data.longitude !== undefined) && 
              (needsTympanumUpdate || needsPlanetUpdate)) {
            if (typeof window.StarChartDisplay !== 'undefined' && window.StarChartDisplay.setLocation) {
              window.StarChartDisplay.setLocation(parseFloat(data.latitude), parseFloat(data.longitude));
            } else if (typeof window.StarChart !== 'undefined' && window.StarChart.setLocation) {
              window.StarChart.setLocation(parseFloat(data.latitude), parseFloat(data.longitude));
            }
          }
        }
      } catch (error) {
        console.error('Polling error:', error);
      }
      
      // Check connection timeout
      if (Date.now() - lastUpdate > 3000 && isConnected) {
        isConnected = false;
        $('.sync-status').addClass('disconnected');
        $('#sync-text').text('DISCONNECTED');
      }
    }
    
    // First fetch initial state from DB, then initialize
    async function initializeDisplay() {
      try {
        // Get initial state from DB
        console.log('Fetching initial state from DB...');
        const state = await AstrolabeCommon.fetchState(sessionKey);
        
        if (state && state.state) {
          const data = state.state;
          console.log('Initial state received:', data);
          
          // Apply initial state values BEFORE initialization
          if (data.latitude !== undefined) {
            $('#latitude').val(data.latitude);
            $('#latitudeSlider').val(data.latitude);
            window.latitude = parseFloat(data.latitude);
            const lat = parseFloat(data.latitude);
            const dir = lat >= 0 ? 'N' : 'S';
            $('#latspan').text(Math.abs(lat).toFixed(1) + '°' + dir);
            previousState.latitude = data.latitude;
          }
          
          if (data.longitude !== undefined) {
            $('#longitude').val(data.longitude);
            $('#longitudeSlider').val(data.longitude);
            window.longitude = parseFloat(data.longitude);
            const lon = parseFloat(data.longitude);
            const dir = lon >= 0 ? 'E' : 'W';
            $('#lonspan').text(Math.abs(lon).toFixed(1) + '°' + dir);
            previousState.longitude = data.longitude;
          }
          
          // Set date/time values
          if (data.local_year) {
            $('#local_year').text(data.local_year);
            $('#year-display').text(data.local_year);
            previousState.local_year = data.local_year;
          }
          if (data.local_month) {
            $('#local_month').text(data.local_month);
            $('#month-display').text(data.local_month);
            previousState.local_month = data.local_month;
          }
          if (data.local_day) {
            $('#local_day').text(data.local_day);
            $('#day-display').text(data.local_day);
            previousState.local_day = data.local_day;
          }
          if (data.local_hour !== undefined) {
            $('#local_hour').text(data.local_hour);
            $('#hour-display').text(data.local_hour.toString().padStart(2, '0'));
            previousState.local_hour = data.local_hour;
          }
          if (data.local_minute !== undefined) {
            $('#local_minutes').text(data.local_minute);
            $('#minute-display').text(data.local_minute.toString().padStart(2, '0'));
            previousState.local_minute = data.local_minute;
          }
          if (data.local_second !== undefined) {
            $('#local_seconds').text(data.local_second);
            previousState.local_second = data.local_second;
          }
          if (data.julian_day) {
            $('#julian_day_local').text(data.julian_day);
            $('#julian_day').text(data.julian_day);
            previousState.julian_day = data.julian_day;
          }
          
          // Set other state
          if (data.mask_rotation !== undefined) {
            window.currentMaskRotation = parseFloat(data.mask_rotation);
            previousState.mask_rotation = data.mask_rotation;
          }
          
          previousState.star_chart_visible = data.star_chart_visible;
          previousState.astrolabe_visible = data.astrolabe_visible;
          previousState.sky_coloration = data.sky_coloration;
        }
      } catch (error) {
        console.error('Error fetching initial state:', error);
      }
      
      // Now initialize components with correct values
      console.log('Initializing components with DB values...');
      
      // Initialize wheel and controls
      if (typeof wheel_init === 'function') {
        wheel_init();
      }
      
      // Initialize astrolabe layers
      if (typeof mater === 'function') {
        console.log('Initializing mater...');
        mater();
      }
      if (typeof tympanum === 'function') {
        console.log('Initializing tympanum with latitude:', window.latitude);
        tympanum();
      }
      if (typeof star_init === 'function') {
        console.log('Initializing stars...');
        star_init();
      }
      if (typeof rete === 'function') {
        console.log('Initializing rete...');
        rete();
      }
      if (typeof rete_51459 === 'function') {
        console.log('Initializing rete_51459...');
        rete_51459();
      }
      if (typeof rule === 'function') {
        console.log('Initializing rule...');
        rule();
      }
      
      // Now calculate planets with correct date/time
      if (typeof planet_advance === 'function') {
        console.log('Calculating initial planet positions...');
        planet_advance();
        
        // Update ephemeris table with initial values
        setTimeout(() => {
          updateEphemerisTable();
        }, 500);
      }
      
      // Start regular polling
      setInterval(pollForUpdates, 200);
    }
    
    // Start initialization
    initializeDisplay();
    
    // Keyboard shortcuts
    $(document).keydown(function(e) {
      // F11 for fullscreen
      if (e.key === 'F11') {
        e.preventDefault();
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen();
        } else {
          document.exitFullscreen();
        }
      }
      
      // Tab to switch displays
      if (e.key === 'Tab') {
        e.preventDefault();
        if (currentDisplay === 'astrolabe') {
          switchDisplay('starchart');
        } else {
          switchDisplay('astrolabe');
        }
      }
    });
  });
  </script>
</body>
</html>
