<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Get session key
$sessionKey = $input['session'] ?? $input['session_key'] ?? 'default';

// Remove session from data
unset($input['session']);
unset($input['session_key']);

try {
    $db = new PDO("sqlite:../astrolabe.db");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get current state
    $stmt = $db->prepare("SELECT state FROM states WHERE session_key = ?");
    $stmt->execute([$sessionKey]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        // Merge with existing state
        $currentState = json_decode($result['state'], true);
        $newState = array_merge($currentState, $input);
        
        // Keep user-provided latitude/longitude if they exist, otherwise use Turkey defaults
        if (!isset($input['latitude'])) {
            $newState['latitude'] = 39.0;  // Turkey average latitude
        }
        if (!isset($input['longitude'])) {
            $newState['longitude'] = 35.0; // Turkey average longitude
        }
        
        // Update state
        $stmt = $db->prepare("UPDATE states SET state = ?, updated_at = datetime('now') WHERE session_key = ?");
        $stmt->execute([json_encode($newState), $sessionKey]);
    } else {
        // Create new state with defaults
        $defaults = [
            'latitude' => 39.0,  // Turkey average latitude
            'longitude' => 35.0, // Turkey average longitude
            'astrolabe_visible' => true,
            'star_chart_visible' => false,
            'local_year' => date('Y'),
            'local_month' => date('n'),
            'local_day' => date('j'),
            'local_hour' => date('G'),
            'local_minute' => date('i'),
            'local_second' => date('s'),
            'julian_day' => 2460563.5,
            'mask_rotation' => 0,
            'mask_hour_offset' => 0,
            'mask_minute_offset' => 0
        ];
        
        // Merge defaults with input (input takes priority)
        $newState = array_merge($defaults, $input);
        
        $stmt = $db->prepare("INSERT INTO states (session_key, state, updated_at) VALUES (?, ?, datetime('now'))");
        $stmt->execute([$sessionKey, json_encode($newState)]);
    }
    
    echo json_encode([
        'success' => true,
        'state' => $newState,
        'updated_at' => date('Y-m-d H:i:s')
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>