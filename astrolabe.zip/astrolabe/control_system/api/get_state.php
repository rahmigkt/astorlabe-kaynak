<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// Get session key from query parameter
$sessionKey = $_GET['session'] ?? $_GET['session_key'] ?? 'default';

try {
    $db = new PDO("sqlite:../astrolabe.db");
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get state from database
    $stmt = $db->prepare("SELECT state, updated_at FROM states WHERE session_key = ?");
    $stmt->execute([$sessionKey]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        echo json_encode([
            'success' => true,
            'state' => json_decode($result['state'], true),
            'updated_at' => $result['updated_at']
        ]);
    } else {
        // Create default state if not exists
        $defaultState = [
            'latitude' => 40,
            'longitude' => 0,
            'astrolabe_visible' => true,
            'star_chart_visible' => false,
            'local_year' => date('Y'),
            'local_month' => date('n'),
            'local_day' => date('j'),
            'local_hour' => date('G'),
            'local_minute' => date('i'),
            'local_second' => date('s'),
            'julian_day' => 2460563.5
        ];
        
        $stmt = $db->prepare("INSERT INTO states (session_key, state, updated_at) VALUES (?, ?, datetime('now'))");
        $stmt->execute([$sessionKey, json_encode($defaultState)]);
        
        echo json_encode([
            'success' => true,
            'state' => $defaultState,
            'updated_at' => date('Y-m-d H:i:s')
        ]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>