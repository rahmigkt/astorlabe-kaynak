<?php
require_once '../includes/db.php';

header('Content-Type: application/json');

$db = Database::getInstance();
$presets = $db->getLocationPresets();

echo json_encode($presets);
?>