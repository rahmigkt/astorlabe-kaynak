<?php
session_start();
require_once 'includes/db.php';

$db = Database::getInstance();
$db->logout();
?>
