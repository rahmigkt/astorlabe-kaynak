<?php
// Quick debug for email system

$downloadsDir = __DIR__ . '/downloads/';
echo "<h3>Quick Debug</h3>";

echo "<p><strong>Downloads directory path:</strong> " . $downloadsDir . "</p>";
echo "<p><strong>Downloads directory exists:</strong> " . (file_exists($downloadsDir) ? 'YES' : 'NO') . "</p>";
echo "<p><strong>Downloads directory writable:</strong> " . (is_writable($downloadsDir) ? 'YES' : 'NO') . "</p>";

if (file_exists($downloadsDir)) {
    $files = scandir($downloadsDir);
    echo "<p><strong>Files in downloads:</strong></p>";
    echo "<ul>";
    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            $filePath = $downloadsDir . $file;
            $fileSize = filesize($filePath);
            echo "<li>$file ($fileSize bytes) - <a href='downloads/$file' target='_blank'>View</a></li>";
        }
    }
    echo "</ul>";
} else {
    echo "<p>Downloads directory does not exist. Attempting to create...</p>";
    if (mkdir($downloadsDir, 0755, true)) {
        echo "<p>✅ Created successfully!</p>";
    } else {
        echo "<p>❌ Failed to create directory</p>";
    }
}

// Test file write
$testFile = $downloadsDir . 'test_write.html';
$testContent = '<html><body><h1>Test Write</h1><p>Current time: ' . date('Y-m-d H:i:s') . '</p></body></html>';
$writeResult = file_put_contents($testFile, $testContent);

echo "<p><strong>Test write result:</strong> " . ($writeResult !== false ? "SUCCESS ($writeResult bytes)" : 'FAILED') . "</p>";

if ($writeResult !== false) {
    echo "<p><a href='downloads/test_write.html' target='_blank'>📄 View Test File</a></p>";
}
?>