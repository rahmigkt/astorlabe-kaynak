<?php
// Test database connection and show current states
$db = new PDO("sqlite:astrolabe.db");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo "Database tables:\n";
$tables = $db->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);
print_r($tables);

echo "\nCurrent states:\n";
$states = $db->query("SELECT * FROM states")->fetchAll(PDO::FETCH_ASSOC);
foreach($states as $state) {
    echo "Session: " . $state['session_key'] . "\n";
    echo "State: " . $state['state'] . "\n";
    echo "Updated: " . $state['updated_at'] . "\n\n";
}

// Check if updates are working
$testSession = 'test_' . time();
$testState = json_encode(['test' => 'value', 'timestamp' => time()]);

$stmt = $db->prepare("INSERT OR REPLACE INTO states (session_key, state, updated_at) VALUES (?, ?, datetime('now'))");
$stmt->execute([$testSession, $testState]);

echo "Test insert successful!\n";

// Verify insert
$verify = $db->query("SELECT * FROM states WHERE session_key = '$testSession'")->fetch(PDO::FETCH_ASSOC);
echo "Verified: ";
print_r($verify);
?>