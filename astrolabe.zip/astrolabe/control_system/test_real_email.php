<?php
// Test real email sending with detailed debugging

// Create test request
$testData = [
    'horoscope_text' => 'Test burç yorumu ' . date('Y-m-d H:i:s'),
    'date' => date('D M d Y'),
    'latitude' => 41,
    'recipient_email' => 'test@example.com',
    'screenshots' => null
];

$ch = curl_init('http://localhost:8080/control_system/send_horoscope_email.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($testData));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<h2>Email Send Test Results</h2>";
echo "<p><strong>HTTP Code:</strong> $httpCode</p>";
echo "<p><strong>Raw Response:</strong></p>";
echo "<pre>" . htmlspecialchars($response) . "</pre>";

$json = json_decode($response, true);
if ($json) {
    echo "<p><strong>Parsed JSON:</strong></p>";
    echo "<pre>" . json_encode($json, JSON_PRETTY_PRINT) . "</pre>";
    
    if (isset($json['download_link'])) {
        echo "<p><strong>Download Link:</strong> " . ($json['download_link'] ?: 'NULL') . "</p>";
        if ($json['download_link']) {
            $fileUrl = 'http://localhost:8080/control_system/downloads/' . $json['download_link'];
            echo "<p><a href='$fileUrl' target='_blank'>📄 Test Download Link</a></p>";
        }
    }
} else {
    echo "<p style='color:red;'>Failed to parse JSON response</p>";
}

// Check for created files
echo "<hr><h3>Recently Created Files</h3>";
$downloadsDir = __DIR__ . '/downloads/';
$files = glob($downloadsDir . 'burc_yorumu_*.html');
usort($files, function($a, $b) {
    return filemtime($b) - filemtime($a);
});

echo "<ul>";
foreach (array_slice($files, 0, 5) as $file) {
    $filename = basename($file);
    $size = filesize($file);
    $time = date('Y-m-d H:i:s', filemtime($file));
    echo "<li>$filename - $size bytes - $time</li>";
}
echo "</ul>";
?>