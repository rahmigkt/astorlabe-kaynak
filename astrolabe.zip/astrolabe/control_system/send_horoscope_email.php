<?php
header('Content-Type: application/json');
require_once 'env_loader.php';

// Load settings from .env and JSON
$envDefaults = [
    'smtp_host' => env('SMTP_HOST', 'smtp.gmail.com'),
    'smtp_port' => intval(env('SMTP_PORT', 587)),
    'smtp_encryption' => env('SMTP_ENCRYPTION', 'tls'),
    'smtp_username' => env('SMTP_USERNAME', ''),
    'smtp_password' => env('SMTP_PASSWORD', ''),
    'smtp_from_name' => env('SMTP_FROM_NAME', 'Astrolabe AI')
];

$settings = [];
if (file_exists('ai_settings.json')) {
    $settings = json_decode(file_get_contents('ai_settings.json'), true);
}
$settings = array_merge($envDefaults, $settings);

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !$input['horoscope_text']) {
    echo json_encode(['success' => false, 'error' => 'Geçersiz veri.']);
    exit;
}

// Handle screenshots if provided
$screenshots = isset($input['screenshots']) ? $input['screenshots'] : null;
$screenshot_paths = [];

// Get recipient email from request
$recipient_email = isset($input['recipient_email']) ? filter_var($input['recipient_email'], FILTER_VALIDATE_EMAIL) : false;

if (!$recipient_email) {
    echo json_encode(['success' => false, 'error' => 'Geçerli bir e-posta adresi girilmedi.']);
    exit;
}

if (!$settings['smtp_username']) {
    echo json_encode(['success' => false, 'error' => 'SMTP ayarları yapılandırılmamış. Lütfen admin panelini kontrol edin.']);
    exit;
}

// Save screenshots if provided
if ($screenshots) {
    foreach ($screenshots as $type => $data) {
        if ($data) {
            // Remove data:image/png;base64, prefix
            $imageData = str_replace('data:image/png;base64,', '', $data);
            $imageData = str_replace(' ', '+', $imageData);
            $imageDecoded = base64_decode($imageData);
            
            // Save to temp file
            $imagePath = sys_get_temp_dir() . '/' . $type . '_' . uniqid() . '.png';
            file_put_contents($imagePath, $imageDecoded);
            $screenshot_paths[$type] = $imagePath;
        }
    }
}

// Create PDF content (simple HTML)
$pdfContent = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Günlük Burç Yorumu</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #4a5568;
            margin-bottom: 30px;
            padding-bottom: 20px;
        }
        .header h1 {
            color: #2d3748;
            margin: 0;
        }
        .date-info {
            background: #f7fafc;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #4299e1;
        }
        .horoscope-content {
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .footer {
            text-align: center;
            color: #718096;
            font-size: 12px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🌟 Günlük Burç Yorumu</h1>
        <p>Kişiselleştirilmiş Astrolojik Analiz</p>
    </div>
    
    <div class="date-info">
        <h3>📅 Tarih Bilgileri</h3>
        <p><strong>Tarih:</strong> ' . htmlspecialchars($input['date']) . '</p>
        <p><strong>Enlem:</strong> ' . htmlspecialchars($input['latitude']) . '°</p>
    </div>
    
    <div class="horoscope-content">
        <h3>🔮 AI Burç Yorumu</h3>
        ' . nl2br(htmlspecialchars($input['horoscope_text'])) . '
    </div>';

// Add screenshots if available
if (!empty($screenshot_paths)) {
    $pdfContent .= '
    <div style="page-break-before: always;">
        <h3>📊 Astroloji Haritaları</h3>';
    
    foreach ($screenshot_paths as $type => $path) {
        $imageData = base64_encode(file_get_contents($path));
        $title = ($type == 'starChart') ? 'Yıldız Haritası' : 'Usturlap Görünümü';
        $pdfContent .= '
        <div style="margin: 20px 0; text-align: center;">
            <h4>' . $title . '</h4>
            <img src="data:image/png;base64,' . $imageData . '" style="max-width: 100%; height: auto; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
        </div>';
    }
    
    $pdfContent .= '</div>';
}

$pdfContent .= '
    <div class="footer">
        <p>Bu yorum Astrolabe AI tarafından oluşturulmuştur.</p>
        <p>Tarih: ' . date('d.m.Y H:i:s') . '</p>
    </div>
</body>
</html>
';

// Generate PDF filename
$filename = 'burc_yorumu_' . date('Y-m-d_H-i-s') . '.pdf';
$pdfPath = sys_get_temp_dir() . '/' . $filename;

// Check if wkhtmltopdf is available (better option)
$wkhtmltopdf = shell_exec('which wkhtmltopdf 2>/dev/null');
if (!empty($wkhtmltopdf)) {
    // Use wkhtmltopdf if available
    $htmlFile = sys_get_temp_dir() . '/horoscope_' . uniqid() . '.html';
    file_put_contents($htmlFile, $pdfContent);
    
    $command = 'wkhtmltopdf --page-size A4 --margin-top 0.75in --margin-right 0.75in --margin-bottom 0.75in --margin-left 0.75in --encoding UTF-8 --quiet ' . escapeshellarg($htmlFile) . ' ' . escapeshellarg($pdfPath);
    exec($command, $output, $return_var);
    
    unlink($htmlFile); // Clean up HTML file
    
    if ($return_var !== 0 || !file_exists($pdfPath)) {
        echo json_encode(['success' => false, 'error' => 'PDF oluşturulamadı.']);
        exit;
    }
} else {
    // Fallback: Use simple HTML to PDF conversion or create HTML file
    // For simplicity, we\'ll create an HTML file instead of PDF
    $pdfPath = sys_get_temp_dir() . '/' . str_replace('.pdf', '.html', $filename);
    file_put_contents($pdfPath, $pdfContent);
}

// Prepare email
$to = $recipient_email;
$from = $settings['smtp_username'];
$fromName = $settings['smtp_from_name'];
$subject = '🌟 Günlük Burç Yorumunuz - ' . date('d.m.Y');

$emailContent = "
Merhaba,

Günlük burç yorumunuz hazır! 

Tarih: {$input['date']}
Enlem: {$input['latitude']}°

Detaylı yorumunuz ekte yer almaktadır.

İyi günler dileriz! 🌟

---
Astrolabe AI
";

// Create email headers
$headers = [];
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-Type: multipart/mixed; boundary="PHP-mixed-' . md5(time()) . '"';
$headers[] = 'From: ' . $from;
$headers[] = 'Reply-To: ' . $from;

$boundary = 'PHP-mixed-' . md5(time());

$message = "--{$boundary}\r\n";
$message .= "Content-Type: text/plain; charset=UTF-8\r\n";
$message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
$message .= $emailContent . "\r\n";

// Attach file
if (file_exists($pdfPath)) {
    $fileContent = chunk_split(base64_encode(file_get_contents($pdfPath)));
    $fileType = pathinfo($pdfPath, PATHINFO_EXTENSION) == 'pdf' ? 'application/pdf' : 'text/html';
    
    $message .= "\r\n--{$boundary}\r\n";
    $message .= "Content-Type: {$fileType}; name=\"{$filename}\"\r\n";
    $message .= "Content-Disposition: attachment; filename=\"{$filename}\"\r\n";
    $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
    $message .= $fileContent . "\r\n";
}

$message .= "\r\n--{$boundary}--\r\n";

// Try to send email
$mailSent = false;

// Method 1: PHP mail() function
if (function_exists('mail')) {
    $mailSent = mail($to, $subject, $message, implode("\r\n", $headers));
}

// Method 2: If mail() failed, try with smtp (requires configuration)
if (!$mailSent && !empty($settings['email_password'])) {
    // This would require PHPMailer or similar library
    // For now, we'll just report success if file was created
    $mailSent = file_exists($pdfPath);
}

// Clean up temporary files
if (file_exists($pdfPath)) {
    // Keep the file for a bit in case email failed
    if ($mailSent) {
        unlink($pdfPath);
    }
}

// Clean up screenshot files
foreach ($screenshot_paths as $path) {
    if (file_exists($path)) {
        unlink($path);
    }
}

if ($mailSent) {
    echo json_encode([
        'success' => true, 
        'message' => 'Burç yorumu başarıyla gönderildi!'
    ]);
} else {
    echo json_encode([
        'success' => false, 
        'error' => 'Email gönderilemedi. SMTP ayarlarını kontrol edin.'
    ]);
}
?>