// DEPRECATED - This file is no longer used
// Control panel now uses ../infrastructure.js for better synchronization
// Control Panel Infrastructure - Simplified version without astrolabe rendering

// Define Julian Day calculation if not already defined
if (typeof jd_from_array === 'undefined') {
    window.jd_from_array = function(ymdhms) {
        const year = ymdhms[0];
        const month = ymdhms[1];
        const day = ymdhms[2];
        const hour = ymdhms[3] || 0;
        const minute = ymdhms[4] || 0;
        const second = ymdhms[5] || 0;
        
        let y = year;
        let m = month;
        
        if (m <= 2) {
            y -= 1;
            m += 12;
        }
        
        const a = Math.floor(y / 100);
        const b = 2 - a + Math.floor(a / 4);
        
        const jd = Math.floor(365.25 * (y + 4716)) + 
                   Math.floor(30.6001 * (m + 1)) + 
                   day + b - 1524.5 + 
                   (hour + minute/60 + second/3600) / 24;
        
        return jd;
    };
}

// Define jd_to_array if not already defined
if (typeof jd_to_array === 'undefined') {
    window.jd_to_array = function(jd) {
        const jd_offset = jd + 0.5;
        const Z = Math.floor(jd_offset);
        const F = jd_offset - Z;
        
        let A = Z;
        if (Z >= 2299161) {
            const alpha = Math.floor((Z - 1867216.25) / 36524.25);
            A = Z + 1 + alpha - Math.floor(alpha / 4);
        }
        
        const B = A + 1524;
        const C = Math.floor((B - 122.1) / 365.25);
        const D = Math.floor(365.25 * C);
        const E = Math.floor((B - D) / 30.6001);
        
        const day = B - D - Math.floor(30.6001 * E) + F;
        const month = (E < 14) ? E - 1 : E - 13;
        const year = (month > 2) ? C - 4716 : C - 4715;
        
        const dayFraction = day - Math.floor(day);
        const hour = Math.floor(dayFraction * 24);
        const minute = Math.floor((dayFraction * 24 - hour) * 60);
        const second = Math.floor(((dayFraction * 24 - hour) * 60 - minute) * 60);
        
        return [year, month, Math.floor(day), hour, minute, second];
    };
}

// Define fullDateSet if not already defined
if (typeof fullDateSet === 'undefined') {
    window.fullDateSet = function(jd) {
        const ymdhms = jd_to_array(jd);
        document.getElementById('local_year').innerHTML = ymdhms[0];
        document.getElementById('local_month').innerHTML = ymdhms[1];
        document.getElementById('local_day').innerHTML = ymdhms[2];
        document.getElementById('local_hour').innerHTML = ymdhms[3];
        document.getElementById('local_minutes').innerHTML = ymdhms[4];
        document.getElementById('local_seconds').innerHTML = ymdhms[5];
        document.getElementById('julian_day_local').innerHTML = jd;
        
        // Call cosmic_update to update displays
        if (typeof cosmic_update === 'function') {
            cosmic_update();
        }
    };
}

// Define now function for getting current time
window.now = function() {
    const d = new Date();
    const year = d.getFullYear();
    const month = d.getMonth() + 1;
    const day = d.getDate();
    const hour = d.getHours();
    const minute = d.getMinutes();
    const second = d.getSeconds();
    
    // Update spans
    document.getElementById('local_year').innerHTML = year;
    document.getElementById('local_month').innerHTML = month;
    document.getElementById('local_day').innerHTML = day;
    document.getElementById('local_hour').innerHTML = hour;
    document.getElementById('local_minutes').innerHTML = minute;
    document.getElementById('local_seconds').innerHTML = second;
    
    // Calculate Julian Day
    const jd = jd_from_array([year, month, day, hour, minute, second]);
    document.getElementById('julian_day_local').innerHTML = jd;
    
    return jd;
};

// Define cosmic_update stub (control panel doesn't need full cosmic calculations)
window.cosmic_update = function() {
    console.log('Cosmic update called (stub for control panel)');
    // Update calendar displays if function exists
    if (typeof updateCalendarDisplays === 'function') {
        updateCalendarDisplays();
    }
};

// Define tympanum stub (control panel doesn't render astrolabe)
window.tympanum = function() {
    console.log('Tympanum called (stub for control panel)');
};

// Define planet_advance stub
window.planet_advance = function() {
    console.log('Planet advance called (stub for control panel)');
};

// Define rete stub
window.rete = function() {
    console.log('Rete called (stub for control panel)');
};

// Define rule stub
window.rule = function() {
    console.log('Rule called (stub for control panel)');
};

// Define star_init stub
window.star_init = function() {
    console.log('Star init called (stub for control panel)');
};

// Define mater stub
window.mater = function() {
    console.log('Mater called (stub for control panel)');
};

// Define star_precess stub (control panel doesn't need star precession)
window.star_precess = function() {
    console.log('Star precess called (stub for control panel)');
};

// Define leapYearQuery function (needed by timewheels.js)
window.leapYearQuery = function(year) {
    // Leap year calculation
    if (year % 400 === 0) return true;
    if (year % 100 === 0) return false;
    if (year % 4 === 0) return true;
    return false;
};

// Define daysInMonth function if needed
window.daysInMonth = function(year, month) {
    const days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (month === 2 && leapYearQuery(year)) {
        return 29;
    }
    return days[month - 1] || 31;
};

// Define yearSet, monthSet, daySet functions (needed by timewheels.js)
window.yearSet = function(year) {
    const yearElement = document.getElementById('local_year');
    if (yearElement) yearElement.innerHTML = year;
    
    const yearValElement = document.getElementById('yearwheel_val');
    if (yearValElement) yearValElement.innerHTML = year;
    
    console.log('Year set to:', year);
};

window.monthSet = function(month) {
    const monthElement = document.getElementById('local_month');
    if (monthElement) monthElement.innerHTML = month;
    
    const monthValElement = document.getElementById('monthwheel_val');
    if (monthValElement) monthValElement.innerHTML = month;
    
    console.log('Month set to:', month);
};

window.daySet = function(day) {
    const dayElement = document.getElementById('local_day');
    if (dayElement) dayElement.innerHTML = day;
    
    const dayValElement = document.getElementById('daywheel_val');
    if (dayValElement) dayValElement.innerHTML = day;
    
    console.log('Day set to:', day);
};

window.hourSet = function(hour) {
    const hourElement = document.getElementById('local_hour');
    if (hourElement) hourElement.innerHTML = hour;
    
    const hourValElement = document.getElementById('hourwheel_val');
    if (hourValElement) hourValElement.innerHTML = hour;
    
    // Update mask rotation based on hour
    // Convert hour to rotation (15 degrees = 1 hour)
    // Subtract 90 to align with clock (0 hour at top = -90 degrees)
    const rotation = (hour * 15 - 90) % 360;
    const iframe = document.getElementById('masking-iframe');
    if (iframe && iframe.contentWindow) {
        iframe.contentWindow.postMessage({
            type: 'setMaskRotation',
            rotation: rotation
        }, '*');
        console.log('🎯 Sent mask rotation to iframe:', rotation);
    }
    
    console.log('Hour set to:', hour);
};

window.minuteSet = function(minute) {
    const minuteElement = document.getElementById('local_minutes');
    if (minuteElement) minuteElement.innerHTML = minute;
    
    const minuteValElement = document.getElementById('minutewheel_val');
    if (minuteValElement) minuteValElement.innerHTML = minute;
    
    console.log('Minute set to:', minute);
};

// Define day_of_year function (needed by timewheels.js)
window.day_of_year = function(year, month, day) {
    const daysInMonths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    
    // Adjust for leap year
    if (leapYearQuery(year)) {
        daysInMonths[1] = 29;
    }
    
    let dayOfYear = day;
    for (let i = 0; i < month - 1; i++) {
        dayOfYear += daysInMonths[i];
    }
    
    return dayOfYear;
};

// Define wheelAdvance function (needed by timewheels.js)
window.wheelAdvance = function(jd) {
    console.log('Wheel advance called with JD:', jd);
    fullDateSet(jd);
    if (typeof cosmic_update === 'function') {
        cosmic_update();
    }
};

// Define other missing functions that panel_buttons.js might need
if (typeof panel_button_init === 'undefined') {
    window.panel_button_init = function() {
        console.log('Panel button init (stub for control panel)');
    };
}

// Define updateCalendarDisplays if not already defined
if (typeof updateCalendarDisplays === 'undefined') {
    window.updateCalendarDisplays = function() {
        console.log('Update calendar displays called');
        
        try {
            // Update the displayed dates in the UI
            const year = document.getElementById('local_year')?.innerHTML || '2025';
            const month = document.getElementById('local_month')?.innerHTML || '1';
            const day = document.getElementById('local_day')?.innerHTML || '1';
            const hour = document.getElementById('local_hour')?.innerHTML || '12';
            const minute = document.getElementById('local_minutes')?.innerHTML || '0';
            
            // Update Julian display if elements exist
            const julianDisplay = document.getElementById('julian-display');
            if (julianDisplay) {
                const jd = document.getElementById('julian_day_local')?.innerHTML || '2460563.5';
                julianDisplay.textContent = parseFloat(jd).toFixed(2);
            }
            
            // Update Gregorian display
            const gregorianDisplay = document.getElementById('gregorian-display');
            if (gregorianDisplay) {
                const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                   'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                const monthName = monthNames[parseInt(month) - 1] || 'Jan';
                const hourStr = String(hour).padStart(2,'0');
                const minuteStr = String(minute).padStart(2,'0');
                gregorianDisplay.textContent = `${day} ${monthName} ${year}, ${hourStr}:${minuteStr}`;
            }
            
            // Update Rumi and Hijri displays with placeholder
            const rumiDisplay = document.getElementById('rumi-display');
            if (rumiDisplay) {
                const rumiYear = parseInt(year) - 584;
                rumiDisplay.textContent = `${day}/${month}/${rumiYear}`;
            }
            
            const hijriDisplay = document.getElementById('hijri-display');
            if (hijriDisplay) {
                const hijriYear = parseInt(year) - 622;
                hijriDisplay.textContent = `${day}/${month}/${hijriYear}`;
            }
            
            console.log('Calendar displays updated:', {year, month, day, hour, minute});
        } catch (error) {
            console.error('Error updating calendar displays:', error);
        }
    };
}

// Enhanced wheel synchronization function
window.syncWheelsToCurrentTime = function() {
    try {
        const year = parseInt(document.getElementById('local_year').innerHTML || '2025');
        const month = parseInt(document.getElementById('local_month').innerHTML || '1');
        const day = parseInt(document.getElementById('local_day').innerHTML || '1');
        const hour = parseInt(document.getElementById('local_hour').innerHTML || '12');
        const minute = parseInt(document.getElementById('local_minutes').innerHTML || '0');
        
        console.log('Syncing wheels to current time:', {year, month, day, hour, minute});
        
        // Sync year wheel
        if (typeof yearSet === 'function') {
            yearSet(year);
        }
        
        // Sync month wheel
        if (typeof monthSet === 'function') {
            monthSet(month);
        }
        
        // Sync day wheel
        const doy = day_of_year(year, month, day);
        const leapYear = leapYearQuery(year) ? 1 : 0;
        if (typeof daySet === 'function') {
            daySet(doy, 365 + leapYear);
        }
        
        // Sync hour wheel
        if (typeof hourSet === 'function') {
            hourSet(hour);
        }
        
        // Sync minute wheel
        if (typeof minuteSet === 'function') {
            minuteSet(minute);
        }
        
        console.log('Wheels synchronized to current time');
    } catch (error) {
        console.error('Error syncing wheels:', error);
    }
};

// Enhanced initialization with proper calendar setup
window.initializeCalendarSystem = function() {
    console.log('Initializing calendar system...');
    
    try {
        // Set current time first
        if (typeof now_button_pressed === 'function') {
            now_button_pressed();
            console.log('Current time set');
        }
        
        // Sync wheels to current time
        setTimeout(function() {
            if (typeof syncWheelsToCurrentTime === 'function') {
                syncWheelsToCurrentTime();
                console.log('Wheels synchronized');
            }
            
            // Update calendar displays
            setTimeout(function() {
                if (typeof updateCalendarDisplays === 'function') {
                    updateCalendarDisplays();
                    console.log('Calendar displays updated');
                }
            }, 200);
        }, 200);
        
        console.log('Calendar system initialization complete');
    } catch (error) {
        console.error('Error initializing calendar system:', error);
    }
};

$(document).ready(function(){
  console.log('Control Panel Infrastructure loaded');
  
  // Initialize with current system time immediately
  setTimeout(function() {
    console.log('Setting initial current time...');
    now(); // Set to current time
    if (typeof updateCalendarDisplays === 'function') {
      updateCalendarDisplays();
    }
  }, 100);
  
  // Initialize latitude slider
  $("#latitudeSlider").change(function(){
      const lat = parseFloat(this.value);
      const latDisplay = document.getElementById('latitude');
      if (latDisplay) latDisplay.textContent = lat;
      window.latitude = lat;
      
      // Update display
      const dir = lat >= 0 ? 'N' : 'S';
      $('#latspan').text(Math.abs(lat).toFixed(1) + '°' + dir);
  });

  // Initialize longitude slider  
  $("#longitudeSlider").change(function(){
      const lon = parseFloat(this.value);
      const lonDisplay = document.getElementById('longitude');
      if (lonDisplay) lonDisplay.textContent = lon;
      window.longitude = lon;
      
      // Update display
      const dir = lon >= 0 ? 'E' : 'W';
      $('#lonspan').text(Math.abs(lon).toFixed(1) + '°' + dir);
  });

  // Initialize date/time display with live updating
  function updateDateTime() {
    const nowDate = new Date();
    $('#local_year').text(nowDate.getFullYear());
    $('#local_month').text(nowDate.getMonth() + 1);
    $('#local_day').text(nowDate.getDate());
    $('#local_hour').text(nowDate.getHours());
    $('#local_minutes').text(nowDate.getMinutes());
    $('#local_seconds').text(nowDate.getSeconds());
    
    // Calculate and update Julian Day
    const jd = jd_from_array([
      nowDate.getFullYear(), 
      nowDate.getMonth() + 1, 
      nowDate.getDate(), 
      nowDate.getHours(), 
      nowDate.getMinutes(), 
      nowDate.getSeconds()
    ]);
    $('#julian_day_local').text(jd);
    
    // Update calendar displays
    if (typeof updateCalendarDisplays === 'function') {
      updateCalendarDisplays();
    }
  }
  
  updateDateTime();
  setInterval(updateDateTime, 1000);
  
  // Initialize wheel if needed for time controls
  if (typeof wheel_init === 'function') {
    try {
      wheel_init();
    } catch(e) {
      console.log('Wheel init not needed for control panel');
    }
  }
});
