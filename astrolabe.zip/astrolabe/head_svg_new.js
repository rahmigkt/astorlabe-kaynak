function loadHeadSvg(language) {
    // Dil klasörünü belirle
    let languageFolder = '';
    switch(language) {
        case 'arabic':
            languageFolder = 'differences_output/arapca_farkli';
            break;
        case 'turkish':
            languageFolder = 'differences_output/turkce_farkli';
            break;
        case 'latin':
            languageFolder = 'differences_output/latince_farkli';
            break;
        default:
            languageFolder = 'differences_output/latince_farkli';
    }
    
    const headSvgPath = languageFolder + '/head.svg';
    console.log('Loading head SVG for language:', language, 'from:', headSvgPath);
    
    // SVG içeriğini doğrudan yükle
    fetch(headSvgPath)
        .then(response => response.text())
        .then(svgContent => {
            // SVG içeriğini parse et
            const parser = new DOMParser();
            const svgDoc = parser.parseFromString(svgContent, 'image/svg+xml');
            const svgElement = svgDoc.querySelector('svg');
            
            if (svgElement) {
                // Head grubu elemanını bul
                const headGroup = document.getElementById('headGroup');
                if (!headGroup) {
                  console.error('Head group not found');
                  return;
                }
                
                // Eski içeriği temizle
                headGroup.innerHTML = '';
                
                // SVG'nin viewBox'ını al
                const viewBox = svgElement.getAttribute('viewBox');
                if (viewBox) {
                    const [minX, minY, width, height] = viewBox.split(' ').map(Number);
                    console.log('Head SVG viewBox:', {minX, minY, width, height});
                    
                    // İçeriği uygun transform ile ekle
                    const g = svgElement.querySelector('g') || svgElement;
                    const paths = g.querySelectorAll('path, circle, rect, polygon');
                    
                    // Scale faktörünü hesapla (limb boyutuna göre)
                    const scaleFactor = language === 'arabic' ? 0.02 : 0.015;
                    
                    // Limb'in üstüne yerleştirmek için Y offset
                    const yOffset = language === 'arabic' ? 110 : 105;
                    
                    console.log('Head transform params:', {scaleFactor, yOffset, pathCount: paths.length});
                    
                    paths.forEach(path => {
                        const clonedPath = path.cloneNode(true);
                        
                        // Stil ayarları - brass rengi
                        clonedPath.setAttribute('fill', '#DAA520');
                        clonedPath.setAttribute('stroke', '#B8860B');
                        clonedPath.setAttribute('stroke-width', '0.5');
                        
                        // Transform uygula - SVG koordinat sistemine göre
                        const currentTransform = clonedPath.getAttribute('transform') || '';
                        clonedPath.setAttribute('transform', 
                            `translate(0, ${yOffset}) scale(${scaleFactor}) translate(${-width/2}, ${-height}) ${currentTransform}`);
                        
                        headGroup.appendChild(clonedPath);
                    });
                    
                    console.log('Head SVG successfully loaded with', paths.length, 'elements');
                }
            }
        })
        .catch(error => {
            console.error('Error loading head SVG:', error);
        });
}