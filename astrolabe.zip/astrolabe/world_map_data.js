// World Map Data - Detailed country boundaries
// Based on Natural Earth simplified geometries

const WorldMapData = {
    // Detailed world geometry in GeoJSON-like format
    // Simplified for web performance while maintaining accuracy
    continents: {
        // North America with detailed coastlines
        northAmerica: {
            name: "North America",
            color: "#2d5a3d",
            paths: [
                // United States Continental
                "M-170,49 -168,52 -165,54 -162,55 -158,58 -155,59 -150,61 -145,60 -140,59 -135,58 -130,55 -125,50 -120,46 -115,42 -110,40 -105,38 -100,35 -95,30 -90,29 -85,30 -80,32 -75,35 -70,40 -68,42 -65,44 -70,45 -75,42 -80,40 -82,38 -85,36 -88,33 -92,31 -95,32 -98,33 -102,35 -105,36 -110,38 -115,40 -120,42 -125,45 -130,48 -135,50 -140,52 -145,53 -150,54 -155,52 -160,50 -165,48 -170,49",
                // Canada
                "M-140,55 -135,58 -130,60 -125,62 -120,64 -115,66 -110,68 -105,70 -100,72 -95,73 -90,74 -85,72 -80,70 -75,68 -70,65 -65,62 -60,60 -55,58 -50,60 -45,62 -50,65 -55,68 -60,70 -65,72 -70,74 -75,75 -80,76 -85,77 -90,78 -95,77 -100,76 -105,75 -110,73 -115,71 -120,69 -125,67 -130,65 -135,62 -140,58 -140,55",
                // Mexico
                "M-115,32 -112,30 -108,28 -105,25 -102,22 -100,20 -98,18 -95,16 -92,15 -90,16 -88,18 -86,20 -88,22 -90,23 -92,24 -95,25 -98,26 -100,28 -103,30 -106,31 -110,32 -115,32",
                // Alaska
                "M-165,60 -160,62 -155,64 -150,66 -145,68 -140,70 -135,71 -130,70 -135,68 -140,66 -145,64 -150,62 -155,60 -160,58 -165,60",
                // Greenland
                "M-45,72 -40,74 -35,76 -30,78 -25,80 -20,82 -15,83 -20,81 -25,79 -30,77 -35,75 -40,73 -45,72"
            ]
        },
        
        southAmerica: {
            name: "South America", 
            color: "#3d5a2d",
            paths: [
                // Main continent
                "M-80,10 -78,8 -75,5 -73,2 -70,0 -68,-3 -65,-5 -62,-8 -60,-10 -58,-12 -55,-15 -52,-18 -50,-20 -48,-23 -45,-25 -43,-28 -40,-30 -38,-32 -35,-35 -37,-38 -40,-40 -42,-42 -45,-45 -48,-48 -50,-50 -53,-52 -55,-54 -58,-53 -60,-51 -62,-48 -65,-45 -67,-42 -70,-40 -72,-37 -73,-34 -75,-31 -76,-28 -77,-25 -78,-22 -79,-19 -80,-16 -81,-13 -82,-10 -81,-7 -80,-4 -79,-1 -78,2 -77,5 -78,7 -80,10"
            ]
        },
        
        europe: {
            name: "Europe",
            color: "#2d4a5a",
            paths: [
                // Western Europe
                "M-10,36 -8,38 -5,40 -2,42 0,43 2,44 5,45 8,46 10,47 12,48 15,49 18,50 20,51 22,52 25,53 20,54 15,55 10,56 5,57 0,58 -5,56 -10,54 -12,52 -10,50 -8,48 -5,46 -3,44 -5,42 -8,40 -10,38 -10,36",
                // Scandinavia
                "M5,60 8,62 12,65 15,68 18,70 20,72 25,71 30,70 28,68 25,65 22,62 18,60 15,58 12,60 10,62 8,60 5,60",
                // Eastern Europe
                "M25,50 30,52 35,54 40,55 45,56 50,55 55,54 60,52 58,50 55,48 50,46 45,45 40,46 35,48 30,49 25,50",
                // Mediterranean
                "M-5,36 0,37 5,38 10,37 15,36 20,37 18,39 15,40 10,41 5,40 0,39 -5,38 -5,36"
            ]
        },
        
        africa: {
            name: "Africa",
            color: "#5a4d2d",
            paths: [
                // Main continent
                "M-15,35 -10,33 -5,31 0,30 5,28 10,26 15,25 20,23 25,22 30,20 35,18 40,15 45,12 50,10 52,8 51,5 50,2 48,0 46,-3 44,-6 42,-10 40,-13 38,-16 36,-20 34,-23 32,-26 30,-30 28,-33 25,-35 20,-34 15,-32 10,-30 5,-28 0,-26 -5,-24 -8,-20 -10,-16 -12,-12 -14,-8 -15,-4 -16,0 -17,4 -18,8 -19,12 -20,16 -18,20 -16,24 -14,28 -15,32 -15,35"
            ]
        },
        
        asia: {
            name: "Asia",
            color: "#4a5a2d",
            paths: [
                // Middle East
                "M35,30 40,32 45,33 50,32 55,30 60,28 58,26 55,25 50,24 45,25 40,27 35,28 35,30",
                // Central Asia
                "M50,40 55,42 60,44 65,45 70,46 75,45 80,44 85,42 90,40 88,38 85,36 80,35 75,36 70,37 65,38 60,39 55,38 50,40",
                // India
                "M65,25 70,23 75,20 80,18 78,15 75,12 70,10 65,8 68,10 70,13 72,16 74,19 72,22 70,24 68,25 65,25",
                // China
                "M75,35 80,37 85,38 90,39 95,38 100,36 105,34 110,32 115,30 120,32 118,34 115,36 110,38 105,40 100,41 95,40 90,39 85,37 80,35 75,35",
                // Southeast Asia
                "M95,20 100,18 105,15 110,12 115,10 110,8 105,10 100,12 95,15 90,18 95,20",
                // Japan
                "M135,35 138,37 140,40 142,38 140,35 138,33 135,35",
                // Russia/Siberia
                "M30,55 40,57 50,58 60,60 70,62 80,64 90,65 100,66 110,67 120,68 130,69 140,68 150,66 160,64 170,62 175,60 170,58 160,56 150,55 140,54 130,53 120,52 110,51 100,50 90,48 80,47 70,46 60,45 50,44 40,46 30,48 30,55"
            ]
        },
        
        oceania: {
            name: "Oceania",
            color: "#2d5a4a",
            paths: [
                // Australia
                "M110,-35 115,-33 120,-32 125,-31 130,-30 135,-29 140,-28 145,-27 150,-28 152,-30 151,-32 150,-34 148,-36 145,-38 140,-39 135,-40 130,-41 125,-40 120,-39 115,-38 110,-37 110,-35",
                // New Zealand
                "M165,-40 168,-38 170,-36 172,-38 170,-40 168,-42 165,-40",
                "M173,-45 175,-43 177,-41 175,-43 173,-45",
                // Papua New Guinea
                "M140,-5 145,-4 150,-3 148,-6 145,-8 142,-7 140,-5",
                // Indonesia
                "M95,-5 100,-4 105,-3 110,-2 115,-3 120,-4 125,-5 130,-6 125,-7 120,-8 115,-7 110,-6 105,-5 100,-6 95,-5"
            ]
        },
        
        antarctica: {
            name: "Antarctica",
            color: "#e8f4f8",
            paths: [
                "M-180,-65 -150,-66 -120,-67 -90,-68 -60,-69 -30,-70 0,-70 30,-70 60,-69 90,-68 120,-67 150,-66 180,-65 180,-85 150,-85 120,-85 90,-85 60,-85 30,-85 0,-85 -30,-85 -60,-85 -90,-85 -120,-85 -150,-85 -180,-85 -180,-65"
            ]
        }
    },
    
    // Major cities for reference
    cities: [
        { name: 'New York', lat: 40.71, lon: -74.01, capital: false },
        { name: 'Washington DC', lat: 38.90, lon: -77.04, capital: true },
        { name: 'London', lat: 51.51, lon: -0.13, capital: true },
        { name: 'Paris', lat: 48.86, lon: 2.35, capital: true },
        { name: 'Berlin', lat: 52.52, lon: 13.41, capital: true },
        { name: 'Moscow', lat: 55.76, lon: 37.62, capital: true },
        { name: 'Tokyo', lat: 35.68, lon: 139.69, capital: true },
        { name: 'Beijing', lat: 39.90, lon: 116.41, capital: true },
        { name: 'New Delhi', lat: 28.61, lon: 77.21, capital: true },
        { name: 'Sydney', lat: -33.87, lon: 151.21, capital: false },
        { name: 'Cairo', lat: 30.04, lon: 31.24, capital: true },
        { name: 'Istanbul', lat: 41.01, lon: 28.98, capital: false },
        { name: 'Dubai', lat: 25.20, lon: 55.27, capital: false },
        { name: 'Singapore', lat: 1.35, lon: 103.82, capital: true },
        { name: 'Hong Kong', lat: 22.32, lon: 114.17, capital: false },
        { name: 'Los Angeles', lat: 34.05, lon: -118.24, capital: false },
        { name: 'Chicago', lat: 41.88, lon: -87.63, capital: false },
        { name: 'Toronto', lat: 43.65, lon: -79.38, capital: false },
        { name: 'Mexico City', lat: 19.43, lon: -99.13, capital: true },
        { name: 'São Paulo', lat: -23.55, lon: -46.63, capital: false },
        { name: 'Buenos Aires', lat: -34.61, lon: -58.38, capital: true },
        { name: 'Rio de Janeiro', lat: -22.91, lon: -43.17, capital: false },
        { name: 'Lima', lat: -12.05, lon: -77.04, capital: true },
        { name: 'Bogotá', lat: 4.71, lon: -74.07, capital: true },
        { name: 'Santiago', lat: -33.46, lon: -70.65, capital: true },
        { name: 'Madrid', lat: 40.42, lon: -3.70, capital: true },
        { name: 'Rome', lat: 41.90, lon: 12.50, capital: true },
        { name: 'Amsterdam', lat: 52.37, lon: 4.90, capital: true },
        { name: 'Brussels', lat: 50.85, lon: 4.35, capital: true },
        { name: 'Vienna', lat: 48.21, lon: 16.37, capital: true },
        { name: 'Stockholm', lat: 59.33, lon: 18.07, capital: true },
        { name: 'Oslo', lat: 59.91, lon: 10.75, capital: true },
        { name: 'Copenhagen', lat: 55.68, lon: 12.57, capital: true },
        { name: 'Helsinki', lat: 60.17, lon: 24.94, capital: true },
        { name: 'Warsaw', lat: 52.23, lon: 21.01, capital: true },
        { name: 'Prague', lat: 50.08, lon: 14.44, capital: true },
        { name: 'Budapest', lat: 47.50, lon: 19.04, capital: true },
        { name: 'Athens', lat: 37.98, lon: 23.73, capital: true },
        { name: 'Ankara', lat: 39.93, lon: 32.86, capital: true },
        { name: 'Tel Aviv', lat: 32.09, lon: 34.78, capital: false },
        { name: 'Jerusalem', lat: 31.77, lon: 35.22, capital: true },
        { name: 'Riyadh', lat: 24.71, lon: 46.68, capital: true },
        { name: 'Tehran', lat: 35.69, lon: 51.39, capital: true },
        { name: 'Mumbai', lat: 19.08, lon: 72.88, capital: false },
        { name: 'Kolkata', lat: 22.57, lon: 88.36, capital: false },
        { name: 'Chennai', lat: 13.08, lon: 80.27, capital: false },
        { name: 'Bangalore', lat: 12.97, lon: 77.59, capital: false },
        { name: 'Karachi', lat: 24.86, lon: 67.00, capital: false },
        { name: 'Islamabad', lat: 33.69, lon: 73.05, capital: true },
        { name: 'Dhaka', lat: 23.81, lon: 90.41, capital: true },
        { name: 'Bangkok', lat: 13.76, lon: 100.50, capital: true },
        { name: 'Jakarta', lat: -6.21, lon: 106.85, capital: true },
        { name: 'Manila', lat: 14.60, lon: 120.98, capital: true },
        { name: 'Kuala Lumpur', lat: 3.14, lon: 101.69, capital: true },
        { name: 'Seoul', lat: 37.57, lon: 126.98, capital: true },
        { name: 'Shanghai', lat: 31.23, lon: 121.47, capital: false },
        { name: 'Guangzhou', lat: 23.13, lon: 113.26, capital: false },
        { name: 'Shenzhen', lat: 22.54, lon: 114.06, capital: false },
        { name: 'Taipei', lat: 25.03, lon: 121.57, capital: true },
        { name: 'Osaka', lat: 34.69, lon: 135.50, capital: false },
        { name: 'Melbourne', lat: -37.81, lon: 144.96, capital: false },
        { name: 'Brisbane', lat: -27.47, lon: 153.03, capital: false },
        { name: 'Perth', lat: -31.95, lon: 115.86, capital: false },
        { name: 'Auckland', lat: -36.85, lon: 174.76, capital: false },
        { name: 'Wellington', lat: -41.29, lon: 174.78, capital: true },
        { name: 'Cape Town', lat: -33.93, lon: 18.42, capital: false },
        { name: 'Johannesburg', lat: -26.20, lon: 28.05, capital: false },
        { name: 'Nairobi', lat: -1.29, lon: 36.82, capital: true },
        { name: 'Lagos', lat: 6.52, lon: 3.38, capital: false },
        { name: 'Casablanca', lat: 33.57, lon: -7.59, capital: false },
        { name: 'Algiers', lat: 36.75, lon: 3.04, capital: true },
        { name: 'Tunis', lat: 36.82, lon: 10.17, capital: true },
        { name: 'Tripoli', lat: 32.89, lon: 13.19, capital: true },
        { name: 'Addis Ababa', lat: 8.98, lon: 38.76, capital: true },
        { name: 'Khartoum', lat: 15.50, lon: 32.56, capital: true }
    ],
    
    // Ocean labels
    oceans: [
        { name: 'PACIFIC OCEAN', lat: 0, lon: -150 },
        { name: 'ATLANTIC OCEAN', lat: 0, lon: -30 },
        { name: 'INDIAN OCEAN', lat: -20, lon: 80 },
        { name: 'ARCTIC OCEAN', lat: 85, lon: 0 },
        { name: 'SOUTHERN OCEAN', lat: -65, lon: 0 }
    ],
    
    // Graticule (lat/lon grid)
    graticule: {
        meridians: 15, // Every 15 degrees longitude
        parallels: 15  // Every 15 degrees latitude
    }
};

// Make WorldMapData available globally
window.WorldMapData = WorldMapData;