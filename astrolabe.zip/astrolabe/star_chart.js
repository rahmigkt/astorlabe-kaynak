// Star Chart Module
// Interactive celestial map synchronized with the astrolabe

const StarChart = (function() {
    // Use comprehensive constellation data if available
    const allStars = window.ConstellationData ? window.ConstellationData.stars : [];
    const constellations = window.ConstellationData ? window.ConstellationData.constellations : {};
    const constellationNames = window.ConstellationData ? window.ConstellationData.constellationNames : {};

    let chartSVG = null;
    let latitude = 40; // Default latitude
    let longitude = 0; // Default longitude
    let jd_local = null; // Julian day local
    let isDragging = false;
    let lastMousePos = { x: 0, y: 0 };
    let rotation = 0;
    let altitude = 45; // View altitude angle
    
    // Viewport dragging variables
    let isDraggingViewport = false;
    let viewportDragStart = { x: 0, y: 0 };
    let startLatLon = { lat: 0, lon: 0 };

    function init() {
        // Check if star chart HTML structure already exists
        const existingStarChart = document.getElementById('star-chart-display');
        if (existingStarChart && existingStarChart.querySelector('#starwheel-visible')) {
            // HTML structure already exists (e.g., in display.php)
            console.log('StarChart: Using existing HTML structure');
            
            // Just setup event listeners and sync
            setupEventListeners();
            updateStarChart();
            syncWithAstrolabe();
            return;
        }

        // Create star chart container (for index.html)
        const container = document.querySelector('.main-container');
        if (!container) return;

        // Create star chart section with custom frame (hidden by default)
        const starChartHTML = `
            <div class="star-chart-container" style="max-width: 600px; min-width: 400px; width: 100%; display: none;">
                <div class="star-chart-wrapper" style="padding: 0; border: none; box-shadow: none; position: relative;">
                    <div style="position: relative; width: 100%; padding-bottom: 100%; overflow: hidden; border-radius: 50%;">
                        <!-- Star chart layer with mask (bottom layer) -->
                        <div style="position: absolute; top: 10%; left: 10%; width: 80%; height: 80%; z-index: 3; overflow: hidden; border-radius: 50%;">
                            <svg viewBox="0 0 100 100" style="width: 100%; height: 100%; position: relative; z-index: 1;">
                                <defs>
                                    <!-- Radial gradient for non-visible space -->
                                    <radialGradient id="spaceGradient" cx="50%" cy="50%">
                                        <stop offset="0%" style="stop-color:#ff4444; stop-opacity:0.6"/>
                                        <stop offset="30%" style="stop-color:#cc2222; stop-opacity:0.4"/>
                                        <stop offset="60%" style="stop-color:#881111; stop-opacity:0.2"/>
                                        <stop offset="100%" style="stop-color:#440000; stop-opacity:0.05"/>
                                    </radialGradient>
                                    
                                    <!-- Inverse mask for non-visible area -->
                                    <mask id="nonVisibleSkyMask">
                                        <!-- White background (everything visible) -->
                                        <rect x="0" y="0" width="100" height="100" fill="white"/>
                                        <!-- Black ellipse for visible area (to hide) -->
                                        <ellipse id="nonVisibleArea" cx="50" cy="50" rx="49" ry="49" fill="black"/>
                                    </mask>
                                    
                                    <!-- Visible sky mask -->
                                    <mask id="visibleSkyMask">
                                        <!-- Black background (everything hidden) -->
                                        <rect x="0" y="0" width="100" height="100" fill="black"/>
                                        <!-- White ellipse for visible area -->
                                        <ellipse id="visibleArea" cx="50" cy="50" rx="49" ry="49" fill="white"/>
                                    </mask>
                                </defs>
                                
                                <!-- Starwheel layers -->
                                <g>
                                    <!-- Dark background for contrast -->
                                    <rect x="0" y="0" width="100" height="100" fill="#0a0a0a"/>
                                    
                                    <!-- Dimmed star chart (below horizon) -->
                                    <image href="${window.location.pathname.includes('control_system') ? '../' : ''}starwheel_40N_en.svg" x="0" y="0" width="100" height="100"
                                           style="opacity: 0.15;" id="starwheel-dim"/>
                                    
                                    <!-- Red gradient overlay for non-visible space -->
                                    <rect id="gradient-overlay" x="0" y="0" width="100" height="100"
                                          fill="url(#spaceGradient)"
                                          mask="url(#nonVisibleSkyMask)"
                                          style="pointer-events: none;"/>
                                    
                                    <!-- Visible star chart (above horizon) with increased brightness -->
                                    <image href="${window.location.pathname.includes('control_system') ? '../' : ''}starwheel_40N_en.svg" x="0" y="0" width="100" height="100"
                                           mask="url(#visibleSkyMask)"
                                           style="filter: brightness(1.2) contrast(1.1);"
                                           id="starwheel-visible"/>
                                </g>
                            </svg>
                        </div>
                        
                        
                        <!-- Star clock layer (middle layer) -->
                        <div id="star-clock-container" style="position: absolute; width: 100%; height: 100%; z-index: 5;">
                            <img id="star-clock" src="${window.location.pathname.includes('control_system') ? '../' : ''}yildiz_saat.svg" 
                                 style="width: 100%; height: 100%;" />
                        </div>
                        
                        <!-- Frame layer (top layer) -->
                        <img src="${window.location.pathname.includes('control_system') ? '../' : ''}yildiz_cerceve.svg" 
                             style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 10; pointer-events: none;" />
                    </div>
                </div>
            </div>
        `;

        // Find where to insert (inside charts-wrapper, after astrolabe-container)
        const chartsWrapper = document.querySelector('.charts-wrapper');
        if (chartsWrapper) {
            const astrolabeContainer = chartsWrapper.querySelector('.astrolabe-container');
            if (astrolabeContainer) {
                astrolabeContainer.insertAdjacentHTML('afterend', starChartHTML);
            }
        }

        // No need to get SVG reference since we're using an external file
        // chartSVG = document.getElementById('star-chart-svg');

        // Limb and markings are not needed with the new fixed star design
        // createLimb();
        // addLimbMarkings();
        // addLimbNumerals();
        // addAzimuthLines();
        
        // Add event listeners
        setupEventListeners();
        
        // Draw initial chart
        updateStarChart();
        
        // Sync with astrolabe if available
        syncWithAstrolabe();
    }

    function setupEventListeners() {
        // Event listeners can be added here if needed for the external SVG

        // Control buttons
        const resetBtn = document.getElementById('star-reset-view');
        const toggleNamesBtn = document.getElementById('star-toggle-names');
        const toggleLinesBtn = document.getElementById('star-toggle-lines');

        if (resetBtn) {
            resetBtn.addEventListener('click', resetView);
        }
        if (toggleNamesBtn) {
            toggleNamesBtn.addEventListener('click', toggleStarNames);
        }
        if (toggleLinesBtn) {
            toggleLinesBtn.addEventListener('click', toggleConstellationLines);
        }
    }

    function handleMouseDown(e) {
        isDragging = true;
        lastMousePos = { x: e.clientX, y: e.clientY };
        chartSVG.style.cursor = 'grabbing';
    }

    function handleMouseMove(e) {
        if (!isDragging) return;
        
        const deltaX = e.clientX - lastMousePos.x;
        const deltaY = e.clientY - lastMousePos.y;
        
        rotation += deltaX * 0.5;
        altitude = Math.max(-90, Math.min(90, altitude - deltaY * 0.5));
        
        lastMousePos = { x: e.clientX, y: e.clientY };
        updateStarChart();
    }

    function handleMouseUp() {
        isDragging = false;
        chartSVG.style.cursor = 'grab';
    }

    function handleTouchStart(e) {
        if (e.touches.length === 1) {
            isDragging = true;
            lastMousePos = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        }
    }

    function handleTouchMove(e) {
        if (!isDragging || e.touches.length !== 1) return;
        e.preventDefault();
        
        const deltaX = e.touches[0].clientX - lastMousePos.x;
        const deltaY = e.touches[0].clientY - lastMousePos.y;
        
        rotation += deltaX * 0.5;
        altitude = Math.max(-90, Math.min(90, altitude - deltaY * 0.5));
        
        lastMousePos = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        updateStarChart();
    }

    function handleTouchEnd() {
        isDragging = false;
    }
    
    // Viewport drag handlers
    function handleViewportMouseDown(e) {
        isDraggingViewport = true;
        const rect = chartSVG.getBoundingClientRect();
        viewportDragStart = { 
            x: e.clientX - rect.left,
            y: e.clientY - rect.top 
        };
        startLatLon = { lat: latitude, lon: longitude };
        e.preventDefault();
        e.stopPropagation();
    }

    function handleViewportMouseMove(e) {
        if (!isDraggingViewport) return;
        
        const rect = chartSVG.getBoundingClientRect();
        const currentX = e.clientX - rect.left;
        const currentY = e.clientY - rect.top;
        
        const deltaX = (currentX - viewportDragStart.x) * 0.5;
        const deltaY = (currentY - viewportDragStart.y) * 0.5;
        
        longitude = Math.max(-180, Math.min(180, startLatLon.lon + deltaX));
        latitude = Math.max(-90, Math.min(90, startLatLon.lat - deltaY));
        
        updateLatLonDisplay();
        updateStarChart();
    }

    function handleViewportMouseUp() {
        isDraggingViewport = false;
    }

    function handleViewportTouchStart(e) {
        if (e.touches.length === 1) {
            isDraggingViewport = true;
            const rect = chartSVG.getBoundingClientRect();
            viewportDragStart = { 
                x: e.touches[0].clientX - rect.left,
                y: e.touches[0].clientY - rect.top 
            };
            startLatLon = { lat: latitude, lon: longitude };
            e.preventDefault();
        }
    }

    function handleViewportTouchMove(e) {
        if (!isDraggingViewport || e.touches.length !== 1) return;
        
        const rect = chartSVG.getBoundingClientRect();
        const currentX = e.touches[0].clientX - rect.left;
        const currentY = e.touches[0].clientY - rect.top;
        
        const deltaX = (currentX - viewportDragStart.x) * 0.5;
        const deltaY = (currentY - viewportDragStart.y) * 0.5;
        
        longitude = Math.max(-180, Math.min(180, startLatLon.lon + deltaX));
        latitude = Math.max(-90, Math.min(90, startLatLon.lat - deltaY));
        
        updateLatLonDisplay();
        updateStarChart();
        e.preventDefault();
    }

    function handleViewportTouchEnd() {
        isDraggingViewport = false;
    }
    
    function updateLatLonDisplay() {
        const latEl = document.getElementById('latitude');
        const lonEl = document.getElementById('longitude');
        if (latEl) latEl.value = latitude;
        if (lonEl) lonEl.value = longitude;
        
        const latDisplay = document.getElementById('latValue');
        const lonDisplay = document.getElementById('lonValue');
        if (latDisplay) latDisplay.innerHTML = `${Math.round(latitude)}<span class="degree-symbol">°</span>`;
        if (lonDisplay) lonDisplay.innerHTML = `${Math.round(longitude)}<span class="degree-symbol">°</span>`;
    }

    function updateStarChart() {
        // Update visible sky mask based on latitude
        updateVisibleSkyMask();
        
        // Rotate starwheel based on time/date if needed
        updateStarwheelRotation();
    }
    
    function updateVisibleSkyMask() {
        // Check for display.php specific element first, then fallback to regular
        let visibleArea = document.getElementById('visibleAreaDisplay');
        let nonVisibleArea = document.getElementById('nonVisibleAreaDisplay');
        
        if (!visibleArea) {
            visibleArea = document.getElementById('visibleArea');
        }
        if (!nonVisibleArea) {
            nonVisibleArea = document.getElementById('nonVisibleArea');
        }
        
        if (!visibleArea) return;
        
        // Get current mask rotation from control panel (if available)
        const maskRotation = window.currentMaskRotation || 0;
        
        // Calculate visible sky area and position based on latitude
        let radiusX, radiusY, centerX, centerY;
        
        if (latitude >= 0) {
            // Northern latitudes
            // Base radius increases from equator to pole
            // At equator: need radius that just touches Polaris
            const baseRadius = 27 + (22 * (latitude / 90)); // Range: 27-49 (balanced between 20 and 35)
            
            // Horizontal radius (rx) - stays relatively circular
            radiusX = baseRadius;
            
            // Vertical radius (ry) - compressed based on latitude for stereographic projection
            // At equator (lat=0): maximum compression (elliptical)
            // At pole (lat=90): no compression (circular)
            const compressionFactor = 1 - (0.3 * Math.cos(latitude * Math.PI / 180)); // More compression near equator
            radiusY = baseRadius * compressionFactor;
            
            centerX = 50;
            centerY = 68 - (18 * (latitude / 90)); // Range: 68 (equator) to 50 (pole) - balanced positioning
            
        } else {
            // Southern latitudes
            const absLat = Math.abs(latitude);
            if (absLat <= 30) {
                // Balanced radius for southern latitudes
                const baseRadius = Math.max(10, 27 - (17 * (absLat / 30))); // Balanced: 27 at equator, 10 at -30°
                radiusX = baseRadius;
                
                // Similar compression for southern latitudes
                const compressionFactor = 1 - (0.3 * Math.cos(absLat * Math.PI / 180));
                radiusY = baseRadius * compressionFactor;
                
                centerX = 50;
                centerY = 68 + (12 * (absLat / 30)); // Balanced: 68 at equator to 80 at -30°
            } else {
                radiusX = 0;
                radiusY = 0;
                centerX = 50;
                centerY = 100;
            }
        }
        
        // Update both visible and non-visible area masks with ellipse parameters
        visibleArea.setAttribute('rx', radiusX);
        visibleArea.setAttribute('ry', radiusY);
        visibleArea.setAttribute('cx', centerX);
        visibleArea.setAttribute('cy', centerY);
        
        // Calculate rotation based on display mode
        let transform;
        
        if (window.disableStarChartRotation) {
            // In display mode, use mask rotation from control panel
            // Add 270 degrees (180 + 90) to flip and rotate right
            transform = `rotate(${maskRotation + 270} 50 50)`;
        } else {
            // In normal mode, calculate rotation based on time, date AND longitude (same as starwheel)
            // Use Local Sidereal Time which includes longitude
            const lst = calculateLST(longitude, jd_local);
            
            // Convert LST to rotation angle (same as starwheel)
            const timeRotation = -lst; // Negative for correct rotation direction
            transform = `rotate(${timeRotation} 50 50)`;
        }
        
        // Apply rotation transformation to the mask
        visibleArea.setAttribute('transform', transform);
        
        // Update the inverse mask for gradient overlay
        if (nonVisibleArea) {
            nonVisibleArea.setAttribute('rx', radiusX);
            nonVisibleArea.setAttribute('ry', radiusY);
            nonVisibleArea.setAttribute('cx', centerX);
            nonVisibleArea.setAttribute('cy', centerY);
            // Apply the same rotation to the gradient mask
            nonVisibleArea.setAttribute('transform', transform);
        }
    }
    
    function updateStarwheelRotation() {
        const starwheelDim = document.getElementById('starwheel-dim');
        const starwheelVisible = document.getElementById('starwheel-visible');
        const gradientOverlay = document.getElementById('gradient-overlay');
        const starClock = document.getElementById('star-clock');
        
        if (!starwheelDim || !starwheelVisible) return;
        
        // Check if rotation is disabled (for display mode)
        if (window.disableStarChartRotation) {
            // Keep starwheel in fixed upright position (no rotation)
            const transform = `rotate(0 50 50)`;
            starwheelDim.setAttribute('transform', transform);
            starwheelVisible.setAttribute('transform', transform);
            if (gradientOverlay) {
                gradientOverlay.setAttribute('transform', transform);
            }
            
            // Keep star clock also fixed upright
            if (starClock) {
                starClock.style.transform = `rotate(0deg)`;
                starClock.style.transformOrigin = 'center';
            }
            return; // Exit early, no rotation calculation needed
        }
        
        // Calculate rotation based on time, date AND longitude
        // Use Local Sidereal Time which includes longitude
        const lst = calculateLST(longitude, jd_local);
        
        // Convert LST to rotation angle
        // LST is in degrees (0-360), representing the hour angle
        // We need to rotate the star wheel accordingly
        const timeRotation = -lst; // Negative for correct rotation direction
        
        // Apply rotation to starwheel and gradient
        const transform = `rotate(${timeRotation} 50 50)`;
        starwheelDim.setAttribute('transform', transform);
        starwheelVisible.setAttribute('transform', transform);
        if (gradientOverlay) {
            gradientOverlay.setAttribute('transform', transform);
        }
        
        // Update star clock rotation
        // Star clock needs to be synchronized with star chart
        if (starClock) {
            // Star clock should rotate with the same LST as the star chart
            // but with 180 degree offset (as mentioned by user)
            const clockRotation = -lst + 180; // Same LST rotation + 180 degree offset
            
            // Apply rotation to star clock
            starClock.style.transform = `rotate(${clockRotation}deg)`;
            starClock.style.transformOrigin = 'center';
        }
    }

    // Convert RA/Dec to fixed chart position using azimuthal equidistant projection
    function convertRADecToChart(ra, dec) {
        // Convert RA to degrees (0-360)
        const raDeg = (ra * 15) % 360;
        
        // Convert to radians
        const raRad = raDeg * Math.PI / 180;
        const decRad = dec * Math.PI / 180;
        
        // Azimuthal equidistant projection centered at celestial north pole
        // Distance from pole
        const theta = (90 - dec) * Math.PI / 180;
        
        // Scale factor for chart (max radius 250)
        const scale = 250 / (Math.PI / 2); // Scale so edge is at 90 degrees from pole
        const r = theta * scale;
        
        // Convert to cartesian coordinates
        const x = r * Math.sin(raRad);
        const y = -r * Math.cos(raRad); // Negative for correct orientation
        
        // Clamp to chart bounds
        if (r > 250) {
            const factor = 250 / r;
            return { x: x * factor, y: y * factor, visible: true };
        }
        
        return { x, y, visible: true };
    }
    
    // Draw fixed star at position
    function drawFixedStar(container, star, pos, isDimmed) {
        // Only draw stars with valid positions
        if (isNaN(pos.x) || isNaN(pos.y)) return;
        
        const starCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        starCircle.setAttribute('cx', pos.x);
        starCircle.setAttribute('cy', pos.y);
        
        // Simple star sizing based on magnitude (only show bright stars)
        const mag = star.mag || 3;
        if (mag > 6) return; // Don't show very dim stars
        
        const radius = Math.max(0.5, 2.5 - mag * 0.3);
        starCircle.setAttribute('r', radius);
        
        // White colors
        starCircle.setAttribute('fill', '#ffffff');
        starCircle.setAttribute('opacity', 0.8);
        
        container.appendChild(starCircle);
    }
    
    // Update viewport position based on lat/lon
    function updateViewportPosition() {
        const indicator = document.getElementById('viewport-indicator');
        
        if (!indicator) return;
        
        // Keep viewport centered for now
        indicator.setAttribute('cx', 0);
        indicator.setAttribute('cy', 0);
    }
    
    function drawGrid(gridGroup) {
        // Altitude circles
        for (let alt = 30; alt <= 90; alt += 30) {
            const r = 240 * (90 - alt) / 90;
            const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            circle.setAttribute('cx', '0');
            circle.setAttribute('cy', '0');
            circle.setAttribute('r', r);
            circle.setAttribute('fill', 'none');
            circle.setAttribute('stroke', 'rgba(200, 200, 200, 0.1)');
            circle.setAttribute('stroke-width', '0.5');
            circle.setAttribute('stroke-dasharray', '2,2');
            gridGroup.appendChild(circle);
        }

        // Azimuth lines
        for (let az = 0; az < 360; az += 45) {
            const rad = (az + rotation) * Math.PI / 180;
            const x = 240 * Math.sin(rad);
            const y = -240 * Math.cos(rad);
            
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', '0');
            line.setAttribute('y1', '0');
            line.setAttribute('x2', x);
            line.setAttribute('y2', y);
            line.setAttribute('stroke', 'rgba(200, 200, 200, 0.1)');
            line.setAttribute('stroke-width', '0.5');
            line.setAttribute('stroke-dasharray', '2,2');
            gridGroup.appendChild(line);
        }
    }

    function calculateStarPosition(star, lst, lat, rotation, viewAlt) {
        // Convert RA/Dec to Alt/Az
        const ha = (lst - star.ra) * Math.PI / 180;
        const dec = star.dec * Math.PI / 180;
        const latRad = lat * Math.PI / 180;

        // Calculate altitude and azimuth
        const sinAlt = Math.sin(dec) * Math.sin(latRad) + Math.cos(dec) * Math.cos(latRad) * Math.cos(ha);
        const alt = Math.asin(sinAlt) * 180 / Math.PI;

        const cosA = (Math.sin(dec) - Math.sin(latRad) * sinAlt) / (Math.cos(latRad) * Math.cos(alt * Math.PI / 180));
        let az = Math.acos(Math.max(-1, Math.min(1, cosA))) * 180 / Math.PI;
        if (Math.sin(ha) > 0) az = 360 - az;

        // Apply rotation
        az = (az + rotation) % 360;

        // Stereographic projection (better for star charts)
        // Only show stars above horizon (alt > -5 degrees for twilight)
        const altLimit = -5; // Show stars slightly below horizon for twilight
        const visible = alt > altLimit;
        
        if (!visible) {
            return {
                x: 0,
                y: 0,
                visible: false,
                altitude: alt,
                azimuth: az
            };
        }

        // Use stereographic projection for less distortion
        const zenithDistance = (90 - alt) * Math.PI / 180;
        const r = 240 * Math.tan(zenithDistance / 2) / Math.tan(Math.PI / 4); // Max radius at horizon
        
        // Limit radius to viewport
        const maxR = Math.min(r, 235);
        const theta = az * Math.PI / 180;
        const x = maxR * Math.sin(theta);
        const y = -maxR * Math.cos(theta);

        return {
            x: x,
            y: y,
            visible: visible && maxR < 240,
            altitude: alt,
            azimuth: az
        };
    }

    function drawStar(starGroup, labelGroup, star, pos) {
        // Create star group
        const starG = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        starG.setAttribute('transform', `translate(${pos.x}, ${pos.y})`);
        
        // Calculate star size based on magnitude (smaller variation for professional look)
        const scale = Math.max(0.5, 1.5 - star.mag * 0.25);
        
        // Simple circle for stars (cleaner, more professional)
        const starCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        starCircle.setAttribute('r', 2 * scale);
        starCircle.setAttribute('fill', getStarColorBrass(star.mag));
        starCircle.setAttribute('opacity', Math.max(0.4, 1 - star.mag * 0.15));
        
        // Add subtle glow for bright stars only
        if (star.mag < 2) {
            starCircle.setAttribute('filter', 'url(#starGlow)');
        }
        
        starG.appendChild(starCircle);
        
        // Add ring for very bright stars (magnitude < 1)
        if (star.mag < 1) {
            const ring = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            ring.setAttribute('r', 4 * scale);
            ring.setAttribute('fill', 'none');
            ring.setAttribute('stroke', getStarColorBrass(star.mag));
            ring.setAttribute('stroke-width', '0.3');
            ring.setAttribute('opacity', '0.4');
            starG.appendChild(ring);
        }
        
        starGroup.appendChild(starG);
        // Don't add individual star names - we'll show constellation names instead
    }

    function getStarColor(magnitude) {
        if (magnitude < 0) return '#ffffff';
        if (magnitude < 1) return '#ffffee';
        if (magnitude < 2) return '#ffeecc';
        return '#ffddaa';
    }
    
    // Star colors in white tones
    function getStarColorBrass(magnitude) {
        if (magnitude < 0) return '#ffffff';  // Pure white
        if (magnitude < 1) return '#f8f8ff';  // Ghost white
        if (magnitude < 2) return '#f0f0f0';  // Light grey
        if (magnitude < 3) return '#e8e8e8';  // Lighter grey
        return '#d0d0d0';  // Light grey
    }

    function calculateLST(longitude, jd) {
        // Use Julian Day if available, otherwise use current date
        if (jd) {
            // Calculate LST from Julian Day
            const T = (jd - 2451545.0) / 36525.0; // Julian centuries since J2000
            const lst = (280.46061837 + 360.98564736629 * (jd - 2451545.0) + longitude) % 360;
            return lst < 0 ? lst + 360 : lst; // Ensure positive value
        } else {
            // Fallback to date calculation from astrolabe elements
            const year = parseInt(document.getElementById('local_year')?.textContent) || new Date().getFullYear();
            const month = parseInt(document.getElementById('local_month')?.textContent) || (new Date().getMonth() + 1);
            const day = parseInt(document.getElementById('local_day')?.textContent) || new Date().getDate();
            const hour = parseInt(document.getElementById('local_hour')?.textContent) || new Date().getHours();
            const minutes = parseInt(document.getElementById('local_minutes')?.textContent) || new Date().getMinutes();
            const seconds = parseInt(document.getElementById('local_seconds')?.textContent) || new Date().getSeconds();
            
            const date = new Date(year, month - 1, day, hour, minutes, seconds);
            const J2000 = new Date('2000-01-01T12:00:00Z');
            const daysSinceJ2000 = (date - J2000) / (1000 * 60 * 60 * 24);
            const lst = (100.46 + 0.985647 * daysSinceJ2000 + longitude + 15 * (hour + minutes / 60)) % 360;
            return lst < 0 ? lst + 360 : lst; // Ensure positive value
        }
    }

    function parseLongitudeFromText(lonText) {
        // Parse longitude from format like "74°W" or "30°E"
        if (!lonText) return 0;
        
        const match = lonText.match(/(\d+\.?\d*)°([WE])/);
        if (match) {
            let lon = parseFloat(match[1]);
            if (match[2] === 'W') lon = -lon;
            return lon;
        }
        
        // Fallback to simple parse if no degree format
        return parseFloat(lonText) || 0;
    }
    
    function syncWithAstrolabe() {
        // Get initial latitude
        const latSlider = document.getElementById('latitudeSlider');
        if (latSlider) {
            latitude = parseFloat(latSlider.value) || 40;
            
            // Override jQuery change event to add star chart update
            const originalChange = latSlider.onchange;
            latSlider.addEventListener('input', (e) => {
                latitude = parseFloat(e.target.value) || latitude;
                updateStarChart();
            });
        }
        
        // Get initial longitude from lonspan or slider
        const lonSpan = document.getElementById('lonspan');
        if (lonSpan && lonSpan.textContent) {
            longitude = parseLongitudeFromText(lonSpan.textContent);
        } else {
            const lonSlider = document.getElementById('longitudeSlider');
            if (lonSlider) {
                longitude = parseFloat(lonSlider.value) || 0;
            }
        }
        
        // Watch for longitude updates
        if (lonSpan) {
            const observer = new MutationObserver(() => {
                const lonText = lonSpan.textContent;
                const newLon = parseLongitudeFromText(lonText);
                if (newLon !== longitude) {
                    longitude = newLon;
                    updateStarChart();
                }
            });
            observer.observe(lonSpan, { childList: true, characterData: true, subtree: true });
        }

        // Get initial Julian Day
        const jdLocalSpan = document.getElementById('julian_day_local');
        if (jdLocalSpan && jdLocalSpan.textContent) {
            jd_local = parseFloat(jdLocalSpan.textContent);
        }

        // Watch for Julian Day updates (main time keeper)
        if (jdLocalSpan) {
            const observer = new MutationObserver(() => {
                const newJD = parseFloat(jdLocalSpan.textContent);
                if (!isNaN(newJD) && newJD !== jd_local) {
                    jd_local = newJD;
                    updateStarChart();
                }
            });
            observer.observe(jdLocalSpan, { childList: true, characterData: true, subtree: true });
        }
        
        // Watch all date/time inputs for changes
        const dateTimeInputs = ['local_year', 'local_month', 'local_day', 'local_hour', 'local_minutes', 'local_seconds'];
        dateTimeInputs.forEach(id => {
            const elem = document.getElementById(id);
            if (elem) {
                const observer = new MutationObserver(() => {
                    updateStarChart();
                });
                observer.observe(elem, { childList: true, characterData: true, subtree: true });
            }
        });

        // Hook into astrolabe's cosmic_update if available
        if (typeof window.cosmic_update === 'function') {
            const originalCosmicUpdate = window.cosmic_update;
            window.cosmic_update = function(jd) {
                originalCosmicUpdate.call(this, jd);
                jd_local = jd;
                updateStarChart();
            };
        }
        
        // Initial update
        updateStarChart();
    }

    function resetView() {
        rotation = 0;
        altitude = 45;
        updateStarChart();
    }

    function toggleStarNames() {
        const labels = document.getElementById('star-labels');
        if (labels) {
            labels.style.display = labels.style.display === 'none' ? 'block' : 'none';
        }
    }
    
    function drawConstellationNames(constellationCenters) {
        const labelGroup = document.getElementById('star-labels');
        if (!labelGroup) return;
        
        labelGroup.innerHTML = '';
        
        // Use global constellation names from ConstellationData
        const names = window.ConstellationData ? window.ConstellationData.constellationNames : constellationNames;
        
        Object.keys(constellationCenters).forEach(constKey => {
            const center = constellationCenters[constKey];
            if (center.count > 0) {
                const x = center.x / center.count;
                const y = center.y / center.count;
                
                const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
                text.setAttribute('x', x);
                text.setAttribute('y', y);
                text.setAttribute('text-anchor', 'middle');
                text.setAttribute('font-size', '10');
                text.setAttribute('font-weight', 'bold');
                text.setAttribute('fill', 'rgba(255, 255, 255, 0.7)');
                text.setAttribute('letter-spacing', '1');
                text.setAttribute('class', 'constellation-name');
                text.textContent = names[constKey] || constKey;
                labelGroup.appendChild(text);
            }
        });
    }

    function drawConstellationLines(container, starPositions, isDimmed) {
        if (!container) return;
        
        // Draw lines for each constellation
        Object.keys(constellations).forEach(constName => {
            const connections = constellations[constName];
            
            connections.forEach(([star1Name, star2Name]) => {
                const star1Pos = starPositions[star1Name];
                const star2Pos = starPositions[star2Name];
                
                if (star1Pos && star2Pos) {
                    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                    line.setAttribute('x1', star1Pos.x);
                    line.setAttribute('y1', star1Pos.y);
                    line.setAttribute('x2', star2Pos.x);
                    line.setAttribute('y2', star2Pos.y);
                    container.appendChild(line);
                }
            });
        });
    }

    function toggleConstellationLines() {
        const lines = document.getElementById('constellation-lines');
        if (lines) {
            lines.style.display = lines.style.display === 'none' ? 'block' : 'none';
        }
    }

    function updateInfoDisplay() {
        const latDisplay = document.getElementById('star-lat-display');
        const lonDisplay = document.getElementById('star-lon-display');
        const timeDisplay = document.getElementById('star-time-display');

        if (latDisplay) {
            latDisplay.textContent = `Lat: ${latitude.toFixed(2)}°${latitude >= 0 ? 'N' : 'S'}`;
        }
        if (lonDisplay) {
            lonDisplay.textContent = `Lon: ${Math.abs(longitude).toFixed(2)}°${longitude >= 0 ? 'E' : 'W'}`;
        }
        if (timeDisplay) {
            // Get time from astrolabe elements if available
            const year = document.getElementById('local_year')?.textContent || new Date().getFullYear();
            const month = document.getElementById('local_month')?.textContent || (new Date().getMonth() + 1);
            const day = document.getElementById('local_day')?.textContent || new Date().getDate();
            const hour = document.getElementById('local_hour')?.textContent || new Date().getHours();
            const min = document.getElementById('local_minutes')?.textContent || new Date().getMinutes();
            
            timeDisplay.textContent = `${year}/${month}/${day} ${hour}:${String(min).padStart(2, '0')}`;
        }
    }

    // Create limb path (like astrolabe)
    function createLimb() {
        const limb = document.getElementById('star-limb');
        if (!limb) return;
        
        // Create limb path (annular ring)
        const rOuter = 260;
        const rInner = 235;
        const d = `M 0,${-rOuter} 
                   A ${rOuter},${rOuter} 0 1,1 0,${rOuter}
                   A ${rOuter},${rOuter} 0 1,1 0,${-rOuter}
                   M 0,${-rInner}
                   A ${rInner},${rInner} 0 1,1 0,${rInner}
                   A ${rInner},${rInner} 0 1,1 0,${-rInner}
                   Z`;
        limb.setAttribute('d', d);
    }
    
    // Add professional limb markings exactly like astrolabe
    function addLimbMarkings() {
        const markingsGroup = document.getElementById('limb-markings');
        if (!markingsGroup) return;
        
        // Clear existing markings beyond circles
        while (markingsGroup.children.length > 3) {
            markingsGroup.removeChild(markingsGroup.lastChild);
        }
        
        // Add 1 degree marks - EXACTLY like astrolabe
        for (let i = 0; i < 360; i++) {
            const ptick = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const pString = "M 0 232 L 0 237"; // From c3r to c2r scaled
            const pRotateString = `rotate(${i})`;
            ptick.setAttribute('d', pString);
            ptick.setAttribute('transform', pRotateString);
            markingsGroup.appendChild(ptick);
        }
        
        // Add 5 degree marks - EXACTLY like astrolabe
        const vdegmarkings = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        markingsGroup.appendChild(vdegmarkings);
        for (let i = 0; i < 360; i += 5) {
            const ptick = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            const pString = "M 0 237 L 0 247"; // From c2r to c1r scaled
            const pRotateString = `rotate(${i})`;
            ptick.setAttribute('d', pString);
            ptick.setAttribute('transform', pRotateString);
            vdegmarkings.appendChild(ptick);
        }
    }
    
    // Add limb numerals - EXACTLY like astrolabe
    function addLimbNumerals() {
        const numeralsGroup = document.getElementById('limb-numerals');
        if (!numeralsGroup) return;
        
        // Clear existing numerals
        numeralsGroup.innerHTML = '';
        
        // Scaled values from astrolabe (multiplied by 2.55 for 260 radius)
        const radius = 250; // 1.01 * c1r scaled
        const numerals = ["1","2","3","4","5","6","7","8","9","10","11","12"];
        const fullNumerals = numerals.concat(numerals);
        
        for (let indx = 0; indx < 24; indx++) {
            const phi = 15 + 15 * indx;
            const x = radius * Math.sin(phi * Math.PI / 180);
            const y = -radius * Math.cos(phi * Math.PI / 180);
            const rotationString = `rotate(${phi})`;
            const translationString = `translate(${x},${y})`;
            
            const tx = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            tx.setAttribute('x', 0);
            tx.setAttribute('y', 0);
            tx.setAttribute('transform', rotationString);
            const tn = document.createTextNode(fullNumerals[indx]);
            tx.appendChild(tn);
            
            const textGroup2 = document.createElementNS('http://www.w3.org/2000/svg', 'g');
            textGroup2.setAttribute('transform', translationString);
            textGroup2.appendChild(tx);
            numeralsGroup.appendChild(textGroup2);
        }
    }
    
    // Add azimuth lines (radial lines from center)
    function addAzimuthLines() {
        const azimuthGroup = document.getElementById('azimuth-lines');
        if (!azimuthGroup) return;
        
        // Add azimuth lines every 15 degrees
        for (let deg = 0; deg < 360; deg += 15) {
            const angle = (deg - 90) * Math.PI / 180; // Convert to radians
            const x = 225 * Math.cos(angle);
            const y = 225 * Math.sin(angle);
            
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', 0);
            line.setAttribute('y1', 0);
            line.setAttribute('x2', x);
            line.setAttribute('y2', y);
            line.setAttribute('stroke', 'rgba(200, 200, 200, 0.1)');
            line.setAttribute('stroke-width', '0.5');
            
            // Make cardinal directions slightly more prominent
            if (deg % 90 === 0) {
                line.setAttribute('stroke', 'rgba(200, 200, 200, 0.2)');
                line.setAttribute('stroke-width', '0.8');
            }
            
            azimuthGroup.appendChild(line);
        }
    }

    // Public API
    return {
        init: init,
        setLocation: function(lat, lon) {
            latitude = lat;
            longitude = lon;
            updateStarChart();
        },
        setTime: function(julianDay) {
            jd_local = julianDay;
            updateStarChart();
        },
        updateStarChart: updateStarChart,
        syncWithAstrolabe: syncWithAstrolabe,
        
        toggleStarNames: function(show) {
            // Toggle between SVG files with and without star names
            const starwheelVisible = document.getElementById('starwheel-visible');
            const starwheelDim = document.getElementById('starwheel-dim');
            
            const prefix = window.location.pathname.includes('control_system') ? '../' : '';
            const svgFile = prefix + (show ? 'starwheel_40N_en.svg' : 'starwheel_40N_en_nonames.svg');
            
            if (starwheelVisible) {
                starwheelVisible.setAttribute('href', svgFile);
            }
            
            if (starwheelDim) {
                starwheelDim.setAttribute('href', svgFile);
            }
        }
    };
})();

// Make StarChart available globally
window.StarChart = StarChart;

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', StarChart.init);
} else {
    StarChart.init();
}
