// iPhone Style Sliders JavaScript

// Generate ticks for slider
function generateTicks(container, count, min, max, currentValue) {
    container.innerHTML = '';
    const range = max - min;
    const center = 50; // Center position in percentage
    
    for (let i = 0; i <= count; i++) {
        const tick = document.createElement('div');
        tick.className = 'tick';
        
        // Major tick every 5
        if (i % 5 === 0) {
            tick.classList.add('major');
        }
        
        // Position calculation
        const percentage = (i / count) * 100;
        const value = min + (range * i / count);
        
        // Check if this tick should be filled (red)
        const currentPercentage = ((currentValue - min) / range) * 100;
        if (Math.abs(percentage - center) <= Math.abs(currentPercentage - center) && 
            ((currentPercentage > center && percentage >= center && percentage <= currentPercentage) ||
             (currentPercentage < center && percentage <= center && percentage >= currentPercentage) ||
             (currentPercentage === center && percentage === center))) {
            tick.classList.add('filled');
        }
        
        tick.style.left = percentage + '%';
        container.appendChild(tick);
    }
}

// Update slider based on click/drag position
function updateSlider(wrapper, container, valueDisplay, currentValueDisplay, input, min, max, suffix = '°', onUpdate) {
    const rect = wrapper.getBoundingClientRect();
    const tickCount = wrapper.id.includes('lat') ? 45 : 72;
    
    function update(clientX) {
        const x = clientX - rect.left;
        const percentage = (x / rect.width) * 100;
        const value = Math.round(min + ((max - min) * percentage / 100));
        const clampedValue = Math.max(min, Math.min(max, value));
        
        input.value = clampedValue;
        valueDisplay.innerHTML = clampedValue + '<span class="degree-symbol">°</span>';
        currentValueDisplay.textContent = clampedValue + suffix;
        
        generateTicks(container, tickCount, min, max, clampedValue);
        
        // Trigger change event on the original input for backward compatibility
        const event = new Event('change', { bubbles: true });
        input.dispatchEvent(event);
        
        // Also trigger input event
        const inputEvent = new Event('input', { bubbles: true });
        input.dispatchEvent(inputEvent);
        
        // Call update callback if provided
        if (onUpdate) {
            onUpdate(clampedValue);
        }
    }
    
    return update;
}

// Initialize iPhone style sliders
function initializeIPhoneSliders() {
    // Latitude slider setup
    const latWrapper = document.getElementById('latSliderWrapper');
    const latContainer = document.getElementById('latTickContainer');
    const latValue = document.getElementById('latValue');
    const latCurrentValue = document.getElementById('latCurrentValue');
    const latInput = document.getElementById('latitudeSlider');
    
    if (latWrapper && latContainer && latValue && latCurrentValue && latInput) {
        const updateLat = updateSlider(latWrapper, latContainer, latValue, latCurrentValue, latInput, 0, 90, '°', function(value) {
            // Update astrolabe when latitude changes
            if (typeof tympanum_set_lat === 'function') {
                tympanum_set_lat(value);
            }
            // Update header display
            const headerLat = document.getElementById('header-latitude');
            if (headerLat) {
                headerLat.textContent = value + '° N';
            }
            // Update location name
            if (typeof updateLocationName === 'function') {
                updateLocationName();
            }
        });
        
        // Initial render
        const initialLat = parseFloat(latInput.value) || 40;
        generateTicks(latContainer, 45, 0, 90, initialLat);
        latValue.innerHTML = initialLat + '<span class="degree-symbol">°</span>';
        latCurrentValue.textContent = initialLat + '°';
        
        // Mouse events for latitude
        let latDragging = false;
        latWrapper.addEventListener('mousedown', (e) => {
            latDragging = true;
            updateLat(e.clientX);
        });
        
        document.addEventListener('mousemove', (e) => {
            if (latDragging) {
                updateLat(e.clientX);
            }
        });
        
        document.addEventListener('mouseup', () => {
            latDragging = false;
        });
        
        // Touch events
        latWrapper.addEventListener('touchstart', (e) => {
            latDragging = true;
            updateLat(e.touches[0].clientX);
        });
        
        document.addEventListener('touchmove', (e) => {
            if (latDragging) {
                updateLat(e.touches[0].clientX);
            }
        });
        
        document.addEventListener('touchend', () => {
            latDragging = false;
        });
    }

    // Longitude slider setup
    const lonWrapper = document.getElementById('lonSliderWrapper');
    const lonContainer = document.getElementById('lonTickContainer');
    const lonValue = document.getElementById('lonValue');
    const lonCurrentValue = document.getElementById('lonCurrentValue');
    const lonInput = document.getElementById('longitudeSlider');
    
    if (lonWrapper && lonContainer && lonValue && lonCurrentValue && lonInput) {
        const updateLon = updateSlider(lonWrapper, lonContainer, lonValue, lonCurrentValue, lonInput, -180, 180, '°', function(value) {
            // Update header display
            const headerLon = document.getElementById('header-longitude');
            if (headerLon) {
                const direction = value >= 0 ? 'E' : 'W';
                headerLon.textContent = Math.abs(value) + '° ' + direction;
            }
            // Update location name
            if (typeof updateLocationName === 'function') {
                updateLocationName();
            }
        });
        
        // Initial render
        const initialLon = parseFloat(lonInput.value) || -74;
        generateTicks(lonContainer, 72, -180, 180, initialLon);
        lonValue.innerHTML = initialLon + '<span class="degree-symbol">°</span>';
        lonCurrentValue.textContent = initialLon + '°';
        
        // Mouse events for longitude
        let lonDragging = false;
        lonWrapper.addEventListener('mousedown', (e) => {
            lonDragging = true;
            updateLon(e.clientX);
        });
        
        document.addEventListener('mousemove', (e) => {
            if (lonDragging) {
                updateLon(e.clientX);
            }
        });
        
        document.addEventListener('mouseup', () => {
            lonDragging = false;
        });
        
        // Touch events
        lonWrapper.addEventListener('touchstart', (e) => {
            lonDragging = true;
            updateLon(e.touches[0].clientX);
        });
        
        document.addEventListener('touchmove', (e) => {
            if (lonDragging) {
                updateLon(e.touches[0].clientX);
            }
        });
        
        document.addEventListener('touchend', () => {
            lonDragging = false;
        });
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeIPhoneSliders);
} else {
    initializeIPhoneSliders();
}