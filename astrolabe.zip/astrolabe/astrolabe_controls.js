/**
 * Enhanced Astrolabe Controls for KisMini
 * - Movement/dragging controls
 * - Scaling/zoom functionality
 * - Session persistence
 */

// Global variables for astrolabe control state
var astrolabe_state = {
    position: { x: 0, y: 0 },
    scale: 1,
    rotation: 0,
    settings: {
        movement_enabled: true,
        scaling_enabled: true,
        auto_save: true,
        session_key: 'astrolabe_session'
    }
};

// Initialize astrolabe controls
function initialize_astrolabe_controls() {
    // Load saved session if available
    load_session_state();
    
    // Add movement controls
    setup_movement_controls();
    
    // Add scaling controls
    setup_scaling_controls();
    
    // Add keyboard shortcuts
    setup_keyboard_controls();
    
    // Apply saved state
    apply_saved_state();
    
    // Auto-save on changes
    if (astrolabe_state.settings.auto_save) {
        setup_auto_save();
    }
}

// Movement controls implementation
function setup_movement_controls() {
    var svg_element = document.getElementById("svg_astrolabe");
    var astrolabe_group = document.getElementById("astrolabe_main_group");
    
    // Create main astrolabe group if it doesn't exist
    if (!astrolabe_group) {
        astrolabe_group = document.createElementNS("http://www.w3.org/2000/svg", "g");
        astrolabe_group.setAttribute("id", "astrolabe_main_group");
        
        // Move all existing astrolabe elements into the group
        var existing_elements = svg_element.querySelectorAll("g:not(defs):not(#astrolabe_main_group)");
        existing_elements.forEach(function(element) {
            astrolabe_group.appendChild(element);
        });
        
        svg_element.appendChild(astrolabe_group);
    }
    
    // Enhanced drag functionality with momentum and constraints
    var astrolabe_drag = d3.drag()
        .on("start", function() {
            stop_button_pressed();
            astrolabe_group.style.cursor = "grabbing";
            
            // Store initial position
            var transform = astrolabe_group.getAttribute("transform") || "";
            var match = transform.match(/translate\(([^,]+),([^)]+)\)/);
            if (match) {
                astrolabe_state.position.x = parseFloat(match[1]);
                astrolabe_state.position.y = parseFloat(match[2]);
            }
        })
        .on("drag", function() {
            // Calculate new position
            var dx = d3.event.dx;
            var dy = d3.event.dy;
            
            astrolabe_state.position.x += dx;
            astrolabe_state.position.y += dy;
            
            // Apply constraints (keep within reasonable bounds)
            var bounds = get_movement_bounds();
            astrolabe_state.position.x = Math.max(bounds.min_x, Math.min(bounds.max_x, astrolabe_state.position.x));
            astrolabe_state.position.y = Math.max(bounds.min_y, Math.min(bounds.max_y, astrolabe_state.position.y));
            
            // Update transform
            update_astrolabe_transform();
        })
        .on("end", function() {
            astrolabe_group.style.cursor = "grab";
            
            // Save position
            if (astrolabe_state.settings.auto_save) {
                save_session_state();
            }
        });
    
    // Apply drag to the astrolabe group
    d3.select("#astrolabe_main_group").call(astrolabe_drag);
    
    // Add visual feedback
    astrolabe_group.addEventListener("mouseenter", function() {
        if (astrolabe_state.settings.movement_enabled) {
            this.style.cursor = "grab";
        }
    });
    
    astrolabe_group.addEventListener("mouseleave", function() {
        this.style.cursor = "default";
    });
}

// Scaling controls implementation
function setup_scaling_controls() {
    var svg_element = document.getElementById("svg_astrolabe");
    
    // Mouse wheel zoom
    svg_element.addEventListener("wheel", function(event) {
        if (!astrolabe_state.settings.scaling_enabled) return;
        
        event.preventDefault();
        
        var delta = event.deltaY * -0.001;
        var new_scale = astrolabe_state.scale * (1 + delta);
        
        // Apply scaling constraints
        new_scale = Math.max(0.5, Math.min(3.0, new_scale));
        
        // Update scale based on situation (adaptive scaling)
        var situation_factor = get_situation_scaling_factor();
        astrolabe_state.scale = new_scale * situation_factor;
        
        update_astrolabe_transform();
        
        if (astrolabe_state.settings.auto_save) {
            save_session_state();
        }
    });
    
    // Touch gesture support for mobile (if Hammer.js is available)
    if (typeof Hammer !== 'undefined') {
        var hammer = new Hammer(svg_element);
        hammer.get('pinch').set({ enable: true });
        
        hammer.on('pinchstart', function(event) {
            stop_button_pressed();
        });
        
        hammer.on('pinchmove', function(event) {
            var new_scale = astrolabe_state.scale * event.scale;
            new_scale = Math.max(0.5, Math.min(3.0, new_scale));
            
            astrolabe_state.scale = new_scale;
            update_astrolabe_transform();
        });
        
        hammer.on('pinchend', function(event) {
            if (astrolabe_state.settings.auto_save) {
                save_session_state();
            }
        });
    } else {
        console.warn("Hammer.js not available, touch gestures disabled");
    }
}

// Keyboard controls
function setup_keyboard_controls() {
    document.addEventListener("keydown", function(event) {
        // Only handle keys when astrolabe is focused
        if (!document.getElementById("svg_astrolabe").matches(":focus")) return;
        
        var step = 5; // Movement step in pixels
        var scale_step = 0.1; // Scale step
        
        switch(event.key) {
            case 'ArrowUp':
                event.preventDefault();
                astrolabe_state.position.y -= step;
                break;
            case 'ArrowDown':
                event.preventDefault();
                astrolabe_state.position.y += step;
                break;
            case 'ArrowLeft':
                event.preventDefault();
                astrolabe_state.position.x -= step;
                break;
            case 'ArrowRight':
                event.preventDefault();
                astrolabe_state.position.x += step;
                break;
            case '+':
            case '=':
                event.preventDefault();
                astrolabe_state.scale = Math.min(3.0, astrolabe_state.scale + scale_step);
                break;
            case '-':
                event.preventDefault();
                astrolabe_state.scale = Math.max(0.5, astrolabe_state.scale - scale_step);
                break;
            case 'r':
            case 'R':
                event.preventDefault();
                reset_astrolabe_position();
                break;
            case 's':
            case 'S':
                if (event.ctrlKey || event.metaKey) {
                    event.preventDefault();
                    save_session_state();
                }
                break;
        }
        
        update_astrolabe_transform();
        
        if (astrolabe_state.settings.auto_save) {
            save_session_state();
        }
    });
    
    // Make astrolabe focusable
    var svg_element = document.getElementById("svg_astrolabe");
    svg_element.setAttribute("tabindex", "0");
}

// Update astrolabe transform based on current state
function update_astrolabe_transform() {
    var astrolabe_group = document.getElementById("astrolabe_main_group");
    if (!astrolabe_group) return;
    
    var transform_string = 
        "translate(" + astrolabe_state.position.x + "," + astrolabe_state.position.y + ") " +
        "scale(" + astrolabe_state.scale + ") " +
        "rotate(" + astrolabe_state.rotation + ")";
    
    astrolabe_group.setAttribute("transform", transform_string);
}

// Get movement bounds based on current viewport
function get_movement_bounds() {
    var svg_element = document.getElementById("svg_astrolabe");
    var rect = svg_element.getBoundingClientRect();
    
    return {
        min_x: -rect.width * 0.5,
        max_x: rect.width * 0.5,
        min_y: -rect.height * 0.5,
        max_y: rect.height * 0.5
    };
}

// Adaptive scaling based on current situation
function get_situation_scaling_factor() {
    // Check current time and celestial conditions
    var current_hour = Number(document.getElementById("local_hour").innerHTML);
    var sun_visible = document.getElementById("sunGroup").getAttribute("visibility") !== "hidden";
    var planets_visible = document.getElementById("jupiterGroup").getAttribute("visibility") !== "hidden";
    
    // Scale smaller during busy times (many objects visible)
    if (sun_visible && planets_visible) {
        return 0.9; // Smaller scale for crowded view
    }
    
    // Scale larger during night time for better star visibility
    if (current_hour < 6 || current_hour > 20) {
        return 1.1; // Larger scale for night viewing
    }
    
    return 1.0; // Default scale
}

// Session persistence functions
function save_session_state() {
    var session_data = {
        position: astrolabe_state.position,
        scale: astrolabe_state.scale,
        rotation: astrolabe_state.rotation,
        timestamp: new Date().toISOString(),
        settings: astrolabe_state.settings
    };
    
    try {
        localStorage.setItem(astrolabe_state.settings.session_key, JSON.stringify(session_data));
    } catch (e) {
        console.warn("Unable to save session state:", e);
    }
}

function load_session_state() {
    try {
        var saved_data = localStorage.getItem(astrolabe_state.settings.session_key);
        if (saved_data) {
            var session_data = JSON.parse(saved_data);
            
            // Check if session is not too old (24 hours)
            var saved_time = new Date(session_data.timestamp);
            var now = new Date();
            var hours_diff = (now - saved_time) / (1000 * 60 * 60);
            
            if (hours_diff < 24) {
                astrolabe_state.position = session_data.position || { x: 0, y: 0 };
                astrolabe_state.scale = session_data.scale || 1;
                astrolabe_state.rotation = session_data.rotation || 0;
                
                // Merge settings
                if (session_data.settings) {
                    Object.assign(astrolabe_state.settings, session_data.settings);
                }
                
                return true;
            }
        }
    } catch (e) {
        console.warn("Unable to load session state:", e);
    }
    
    return false;
}

function apply_saved_state() {
    update_astrolabe_transform();
    update_control_buttons();
}

function update_control_buttons() {
    // Update movement button
    var movement_button = document.getElementById("movement-toggle");
    if (movement_button) {
        movement_button.textContent = "Movement: " + (astrolabe_state.settings.movement_enabled ? "ON" : "OFF");
    }
    
    // Update scaling button
    var scaling_button = document.getElementById("scaling-toggle");
    if (scaling_button) {
        scaling_button.textContent = "Scaling: " + (astrolabe_state.settings.scaling_enabled ? "ON" : "OFF");
    }
}

function reset_astrolabe_position() {
    astrolabe_state.position = { x: 0, y: 0 };
    astrolabe_state.scale = 1;
    astrolabe_state.rotation = 0;
    
    update_astrolabe_transform();
    
    if (astrolabe_state.settings.auto_save) {
        save_session_state();
    }
}

// Auto-save setup
function setup_auto_save() {
    // Save state periodically
    setInterval(function() {
        save_session_state();
    }, 30000); // Every 30 seconds
    
    // Save on page unload
    window.addEventListener("beforeunload", function() {
        save_session_state();
    });
}

// Control panel functions
function toggle_movement_controls() {
    astrolabe_state.settings.movement_enabled = !astrolabe_state.settings.movement_enabled;
    
    var astrolabe_group = document.getElementById("astrolabe_main_group");
    if (astrolabe_group) {
        astrolabe_group.style.cursor = astrolabe_state.settings.movement_enabled ? "grab" : "default";
    }
    
    // Update button text
    var button = document.getElementById("movement-toggle");
    if (button) {
        button.textContent = "Movement: " + (astrolabe_state.settings.movement_enabled ? "ON" : "OFF");
    }
    
    save_session_state();
}

function toggle_scaling_controls() {
    astrolabe_state.settings.scaling_enabled = !astrolabe_state.settings.scaling_enabled;
    
    // Update button text
    var button = document.getElementById("scaling-toggle");
    if (button) {
        button.textContent = "Scaling: " + (astrolabe_state.settings.scaling_enabled ? "ON" : "OFF");
    }
    
    save_session_state();
}

function toggle_auto_save() {
    astrolabe_state.settings.auto_save = !astrolabe_state.settings.auto_save;
    
    if (astrolabe_state.settings.auto_save) {
        setup_auto_save();
    }
}

// Export current session
function export_session() {
    var session_data = {
        position: astrolabe_state.position,
        scale: astrolabe_state.scale,
        rotation: astrolabe_state.rotation,
        timestamp: new Date().toISOString(),
        settings: astrolabe_state.settings,
        astrolabe_settings: {
            latitude: document.getElementById("latitudeSlider").value,
            time: {
                year: document.getElementById("local_year").innerHTML,
                month: document.getElementById("local_month").innerHTML,
                day: document.getElementById("local_day").innerHTML,
                hour: document.getElementById("local_hour").innerHTML,
                minute: document.getElementById("local_minutes").innerHTML
            }
        }
    };
    
    var data_str = JSON.stringify(session_data, null, 2);
    var data_blob = new Blob([data_str], { type: 'application/json' });
    
    var link = document.createElement('a');
    link.href = URL.createObjectURL(data_blob);
    link.download = 'astrolabe_session_' + new Date().toISOString().split('T')[0] + '.json';
    link.click();
}

// Import session
function import_session(file_input) {
    var file = file_input.files[0];
    if (!file) return;
    
    var reader = new FileReader();
    reader.onload = function(e) {
        try {
            var session_data = JSON.parse(e.target.result);
            
            // Apply imported state
            astrolabe_state.position = session_data.position || { x: 0, y: 0 };
            astrolabe_state.scale = session_data.scale || 1;
            astrolabe_state.rotation = session_data.rotation || 0;
            
            if (session_data.settings) {
                Object.assign(astrolabe_state.settings, session_data.settings);
            }
            
            // Apply astrolabe settings if available
            if (session_data.astrolabe_settings) {
                if (session_data.astrolabe_settings.latitude) {
                    $("#latitudeSlider").val(session_data.astrolabe_settings.latitude).slider("refresh");
                }
                // Additional settings can be applied here
            }
            
            update_astrolabe_transform();
            save_session_state();
            
            alert("Session imported successfully!");
            
        } catch (e) {
            alert("Error importing session: " + e.message);
        }
    };
    
    reader.readAsText(file);
}

// Initialize on document ready
$(document).ready(function() {
    // Add a small delay to ensure all astrolabe elements are loaded
    setTimeout(function() {
        initialize_astrolabe_controls();
    }, 1000);
});