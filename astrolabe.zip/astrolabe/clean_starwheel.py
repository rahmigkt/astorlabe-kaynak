import xml.etree.ElementTree as ET
import re

def clean_starwheel_svg(input_file, output_file):
    """Remove month names and day numbers from starwheel SVG"""
    
    # Parse SVG
    tree = ET.parse(input_file)
    root = tree.getroot()
    
    # Register namespaces
    namespaces = {
        'svg': 'http://www.w3.org/2000/svg',
        'xlink': 'http://www.w3.org/1999/xlink'
    }
    
    # Month patterns to search for in use elements
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
              'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    
    # Find all use elements and g groups
    elements_to_remove = []
    
    # Look for use elements that might reference month/day glyphs
    for use in root.findall('.//svg:use', namespaces):
        xlink_href = use.get('{http://www.w3.org/1999/xlink}href')
        if xlink_href:
            # Check if it references a day number (1-31) or month glyph
            if any(f'glyph-{i}-' in xlink_href for i in range(10)):
                # Get parent g element if exists
                parent = use.getparent() if hasattr(use, 'getparent') else None
                if parent is not None and parent.tag.endswith('g'):
                    elements_to_remove.append(parent)
                else:
                    elements_to_remove.append(use)
    
    # Look for g elements with suspicious transforms (likely date/month positions)
    for g in root.findall('.//svg:g', namespaces):
        transform = g.get('transform')
        if transform:
            # Check for typical date positions (outer ring transforms)
            if 'translate' in transform and 'rotate' in transform:
                # Look for patterns that suggest date/month positioning
                if any(use.get('{http://www.w3.org/1999/xlink}href', '').startswith('#glyph-') 
                       for use in g.findall('.//svg:use', namespaces)):
                    elements_to_remove.append(g)
    
    # Remove identified elements
    for elem in elements_to_remove:
        parent = elem.getparent() if hasattr(elem, 'getparent') else None
        if parent is not None:
            parent.remove(elem)
    
    # Save cleaned SVG
    tree.write(output_file, encoding='utf-8', xml_declaration=True)
    print(f"Cleaned SVG saved to {output_file}")
    print(f"Removed {len(elements_to_remove)} elements")

# Process all starwheel SVG files
files_to_clean = [
    ('starwheel_40N_en.svg', 'starwheel_40N_en_clean.svg'),
    ('starwheel_40N_en_nonames.svg', 'starwheel_40N_en_nonames_clean.svg')
]

for input_file, output_file in files_to_clean:
    try:
        clean_starwheel_svg(input_file, output_file)
    except FileNotFoundError:
        print(f"File {input_file} not found, skipping...")
    except Exception as e:
        print(f"Error processing {input_file}: {e}")