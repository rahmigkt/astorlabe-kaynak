// Geolocation functionality for Astrolabe

function initializeGeolocation() {
    // Directly use IP-based geolocation (no permission needed)
    fetch('https://ipapi.co/json/')
        .then(response => response.json())
        .then(data => {
            if (data.latitude && data.longitude) {
                const lat = Math.round(data.latitude);
                const lon = Math.round(data.longitude);
                const country = data.country_name || 'Unknown';
                const city = data.city || '';
                
                console.log('Location detected:', city ? city + ', ' + country : country, lat + '°N, ' + lon + '°E');
                
                // Update sliders
                const latSlider = document.getElementById('latitudeSlider');
                if (latSlider) {
                    latSlider.value = Math.abs(lat);
                    const event = new Event('change', { bubbles: true });
                    latSlider.dispatchEvent(event);
                }
                
                const lonSlider = document.getElementById('longitudeSlider');
                if (lonSlider) {
                    lonSlider.value = lon;
                    const event = new Event('change', { bubbles: true });
                    lonSlider.dispatchEvent(event);
                }
                
                // Update iPhone style sliders
                const latValue = document.getElementById('latValue');
                const latCurrentValue = document.getElementById('latCurrentValue');
                const latContainer = document.getElementById('latTickContainer');
                
                if (latValue && latCurrentValue && latContainer) {
                    latValue.innerHTML = Math.abs(lat) + '<span class="degree-symbol">°</span>';
                    latCurrentValue.textContent = Math.abs(lat) + '°';
                    
                    if (typeof generateTicks === 'function') {
                        generateTicks(latContainer, 45, 0, 90, Math.abs(lat));
                    }
                }
                
                const lonValue = document.getElementById('lonValue');
                const lonCurrentValue = document.getElementById('lonCurrentValue');
                const lonContainer = document.getElementById('lonTickContainer');
                
                if (lonValue && lonCurrentValue && lonContainer) {
                    lonValue.innerHTML = lon + '<span class="degree-symbol">°</span>';
                    lonCurrentValue.textContent = lon + '°';
                    
                    if (typeof generateTicks === 'function') {
                        generateTicks(lonContainer, 72, -180, 180, lon);
                    }
                }
                
                // Update location display with city and country name
                const locationDisplay = document.getElementById('location-name-display');
                if (locationDisplay) {
                    locationDisplay.textContent = city ? city : country;
                }
            }
        })
        .catch(err => {
            console.log('IP geolocation failed:', err);
            // Try alternative service
            fetch('https://ip-api.com/json/')
                .then(response => response.json())
                .then(data => {
                    if (data.lat && data.lon) {
                        const lat = Math.round(data.lat);
                        const lon = Math.round(data.lon);
                        const country = data.country || 'Unknown';
                        const city = data.city || '';
                        
                        console.log('Location detected (backup):', city ? city + ', ' + country : country, lat + '°N, ' + lon + '°E');
                        
                        // Update sliders
                        const latSlider = document.getElementById('latitudeSlider');
                        if (latSlider) {
                            latSlider.value = Math.abs(lat);
                            const event = new Event('change', { bubbles: true });
                            latSlider.dispatchEvent(event);
                        }
                        
                        const lonSlider = document.getElementById('longitudeSlider');
                        if (lonSlider) {
                            lonSlider.value = lon;
                            const event = new Event('change', { bubbles: true });
                            lonSlider.dispatchEvent(event);
                        }
                        
                        // Update iPhone style sliders
                        const latValue = document.getElementById('latValue');
                        const latCurrentValue = document.getElementById('latCurrentValue');
                        const latContainer = document.getElementById('latTickContainer');
                        
                        if (latValue && latCurrentValue && latContainer) {
                            latValue.innerHTML = Math.abs(lat) + '<span class="degree-symbol">°</span>';
                            latCurrentValue.textContent = Math.abs(lat) + '°';
                            
                            if (typeof generateTicks === 'function') {
                                generateTicks(latContainer, 45, 0, 90, Math.abs(lat));
                            }
                        }
                        
                        const lonValue = document.getElementById('lonValue');
                        const lonCurrentValue = document.getElementById('lonCurrentValue');
                        const lonContainer = document.getElementById('lonTickContainer');
                        
                        if (lonValue && lonCurrentValue && lonContainer) {
                            lonValue.innerHTML = lon + '<span class="degree-symbol">°</span>';
                            lonCurrentValue.textContent = lon + '°';
                            
                            if (typeof generateTicks === 'function') {
                                generateTicks(lonContainer, 72, -180, 180, lon);
                            }
                        }
                        
                        // Update location display
                        const locationDisplay = document.getElementById('location-name-display');
                        if (locationDisplay) {
                            locationDisplay.textContent = city ? city : country;
                        }
                    }
                })
                .catch(err => {
                    console.log('All geolocation methods failed, using defaults');
                });
        });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        // Wait a bit for other scripts to initialize
        setTimeout(initializeGeolocation, 1000);
    });
} else {
    // DOM is already loaded
    setTimeout(initializeGeolocation, 1000);
}