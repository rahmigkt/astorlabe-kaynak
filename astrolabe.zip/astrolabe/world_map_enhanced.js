// Enhanced World Map Module with SimpleMaps SVG
// Interactive 2D world map synchronized with the astrolabe

const WorldMapEnhanced = (function() {
    let mapContainer = null;
    let mapSVG = null;
    let marker = null;
    let isDragging = false;
    let currentLat = 40.7128; // Default: New York
    let currentLon = -74.0060;
    let svgDoc = null;
    let countriesGroup = null;
    
    // Debounce timer for marker updates
    let updateTimer = null;
    
    // Map view settings
    const MAP_WIDTH = 2000;
    const MAP_HEIGHT = 857;
    
    function init() {
        createMapContainer();
        loadWorldSVG();
        setupEventListeners();
        syncWithAstrolabe();
        // Set initial location display
        updateDisplay();
    }
    
    function createMapContainer() {
        // Find the control block to place the map inside it
        const controlBlock = document.getElementById('controlblock');
        
        if (!controlBlock) return;
        
        const mapHTML = `
            <div class="world-map-container" style="
                margin: 20px 0;
                width: 100%;
            ">
                <div class="world-map-wrapper" style="
                    background: linear-gradient(145deg, #2a2a2a 0%, #333333 25%, #2a2a2a 50%, #333333 75%, #2a2a2a 100%);
                    padding: 15px;
                    border-radius: 10px;
                    border: 1px solid rgba(135, 206, 235, 0.3);
                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
                    position: relative;
                    overflow: hidden;
                ">
                    <div id="world-map-svg-container" style="
                        width: 100%;
                        height: auto;
                        position: relative;
                        cursor: crosshair;
                        filter: drop-shadow(0 10px 30px rgba(0, 0, 0, 0.5));
                    ">
                        <!-- SVG will be loaded here -->
                    </div>
                    
                    <!-- Overlay for effects -->
                    <div style="
                        position: absolute;
                        top: 0;
                        left: 0;
                        right: 0;
                        bottom: 0;
                        pointer-events: none;
                        background: radial-gradient(circle at center, transparent 30%, rgba(0, 0, 0, 0.3) 100%);
                        mix-blend-mode: multiply;
                    "></div>
                </div>
            </div>
        `;
        
        controlBlock.insertAdjacentHTML('beforeend', mapHTML);
        mapContainer = document.querySelector('.world-map-container');
    }
    
    function loadWorldSVG() {
        const container = document.getElementById('world-map-svg-container');
        if (!container) return;
        
        // Load the SVG file
        fetch('world.svg')
            .then(response => response.text())
            .then(svgText => {
                container.innerHTML = svgText;
                
                // Get the SVG element
                mapSVG = container.querySelector('svg');
                if (!mapSVG) return;
                
                // Style the SVG
                mapSVG.style.width = '100%';
                mapSVG.style.height = 'auto';
                mapSVG.style.display = 'block';
                
                // Apply custom styles to the map
                styleWorldMap();
                
                // Add marker layer
                addMarkerLayer();
                
                // Set initial marker position
                updateMarkerPosition();
            })
            .catch(error => {
                console.error('Error loading world.svg:', error);
                // Fallback to embedded SVG if file load fails
                container.innerHTML = '<p style="color: #ff6b6b;">Error loading map. Please ensure world.svg is in the project directory.</p>';
            });
    }
    
    function styleWorldMap() {
        if (!mapSVG) return;
        
        // Update SVG attributes for better presentation
        mapSVG.setAttribute('preserveAspectRatio', 'xMidYMid meet');
        
        // Style all countries
        const countries = mapSVG.querySelectorAll('path');
        countries.forEach(country => {
            // Set base styles
            country.style.fill = 'rgba(204, 68, 68, 0.8)';
            country.style.stroke = 'rgba(135, 206, 235, 0.3)';
            country.style.strokeWidth = '0.5';
            country.style.transition = 'all 0.3s ease';
            country.style.cursor = 'pointer';
            
            // Add hover effects
            country.addEventListener('mouseenter', function() {
                this.style.fill = 'rgba(204, 68, 68, 1)';
                this.style.stroke = 'rgba(135, 206, 235, 0.8)';
                this.style.strokeWidth = '1.5';
                this.style.filter = 'brightness(1.3) drop-shadow(0 0 10px rgba(135, 206, 235, 0.5))';
            });
            
            country.addEventListener('mouseleave', function() {
                this.style.fill = 'rgba(204, 68, 68, 0.8)';
                this.style.stroke = 'rgba(135, 206, 235, 0.3)';
                this.style.strokeWidth = '0.5';
                this.style.filter = 'none';
            });
            
            // Add click handler
            country.addEventListener('click', handleCountryClick);
        });
        
        // Add ocean background
        const ocean = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        ocean.setAttribute('x', '0');
        ocean.setAttribute('y', '0');
        ocean.setAttribute('width', '2000');
        ocean.setAttribute('height', '857');
        ocean.style.fill = '#0a2540';
        ocean.style.opacity = '0.9';
        mapSVG.insertBefore(ocean, mapSVG.firstChild);
        
        // Add grid overlay
        addGridOverlay();
    }
    
    function addGridOverlay() {
        if (!mapSVG) return;
        
        const gridGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        gridGroup.setAttribute('id', 'grid-overlay');
        gridGroup.style.opacity = '0.15';
        
        // Add latitude lines
        for (let lat = -60; lat <= 60; lat += 30) {
            const y = ((90 - lat) / 180) * 857;
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', '0');
            line.setAttribute('y1', y);
            line.setAttribute('x2', '2000');
            line.setAttribute('y2', y);
            line.style.stroke = lat === 0 ? 'rgba(255, 200, 100, 0.4)' : 'rgba(135, 206, 235, 0.3)';
            line.style.strokeWidth = lat === 0 ? '1.5' : '0.5';
            line.style.strokeDasharray = lat === 0 ? 'none' : '5,5';
            gridGroup.appendChild(line);
        }
        
        // Add longitude lines
        for (let lon = -150; lon <= 150; lon += 30) {
            const x = ((lon + 180) / 360) * 2000;
            const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            line.setAttribute('x1', x);
            line.setAttribute('y1', '0');
            line.setAttribute('x2', x);
            line.setAttribute('y2', '857');
            line.style.stroke = lon === 0 ? 'rgba(255, 200, 100, 0.4)' : 'rgba(135, 206, 235, 0.3)';
            line.style.strokeWidth = lon === 0 ? '1.5' : '0.5';
            line.style.strokeDasharray = lon === 0 ? 'none' : '5,5';
            gridGroup.appendChild(line);
        }
        
        mapSVG.appendChild(gridGroup);
    }
    
    function addMarkerLayer() {
        if (!mapSVG) return;
        
        // Create marker group
        const markerGroup = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        markerGroup.setAttribute('id', 'location-marker');
        markerGroup.style.cursor = 'grab';
        
        // Create pulsing circle effect
        const pulseCircle1 = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        pulseCircle1.setAttribute('r', '8');
        pulseCircle1.setAttribute('fill', 'none');
        pulseCircle1.setAttribute('stroke', 'rgb(193, 177, 88)');
        pulseCircle1.setAttribute('stroke-width', '2');
        pulseCircle1.setAttribute('opacity', '0.6');
        
        const pulseAnimate1 = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
        pulseAnimate1.setAttribute('attributeName', 'r');
        pulseAnimate1.setAttribute('values', '8;20;8');
        pulseAnimate1.setAttribute('dur', '2s');
        pulseAnimate1.setAttribute('repeatCount', 'indefinite');
        pulseCircle1.appendChild(pulseAnimate1);
        
        const opacityAnimate1 = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
        opacityAnimate1.setAttribute('attributeName', 'opacity');
        opacityAnimate1.setAttribute('values', '0.6;0.1;0.6');
        opacityAnimate1.setAttribute('dur', '2s');
        opacityAnimate1.setAttribute('repeatCount', 'indefinite');
        pulseCircle1.appendChild(opacityAnimate1);
        
        // Second pulse ring
        const pulseCircle2 = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        pulseCircle2.setAttribute('r', '12');
        pulseCircle2.setAttribute('fill', 'none');
        pulseCircle2.setAttribute('stroke', 'rgb(193, 177, 88)');
        pulseCircle2.setAttribute('stroke-width', '1');
        pulseCircle2.setAttribute('opacity', '0.4');
        
        const pulseAnimate2 = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
        pulseAnimate2.setAttribute('attributeName', 'r');
        pulseAnimate2.setAttribute('values', '12;25;12');
        pulseAnimate2.setAttribute('dur', '2s');
        pulseAnimate2.setAttribute('begin', '0.5s');
        pulseAnimate2.setAttribute('repeatCount', 'indefinite');
        pulseCircle2.appendChild(pulseAnimate2);
        
        const opacityAnimate2 = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
        opacityAnimate2.setAttribute('attributeName', 'opacity');
        opacityAnimate2.setAttribute('values', '0.4;0.05;0.4');
        opacityAnimate2.setAttribute('dur', '2s');
        opacityAnimate2.setAttribute('begin', '0.5s');
        opacityAnimate2.setAttribute('repeatCount', 'indefinite');
        pulseCircle2.appendChild(opacityAnimate2);
        
        // Center pin
        const pin = document.createElementNS('http://www.w3.org/2000/svg', 'g');
        
        // Pin shadow
        const shadow = document.createElementNS('http://www.w3.org/2000/svg', 'ellipse');
        shadow.setAttribute('cx', '2');
        shadow.setAttribute('cy', '15');
        shadow.setAttribute('rx', '6');
        shadow.setAttribute('ry', '2');
        shadow.setAttribute('fill', 'rgba(0, 0, 0, 0.3)');
        
        // Pin body
        const pinBody = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        pinBody.setAttribute('d', 'M 0,-15 C -8,-15 -15,-8 -15,0 C -15,5 -10,10 0,20 C 10,10 15,5 15,0 C 15,-8 8,-15 0,-15 Z');
        pinBody.setAttribute('fill', 'rgb(193, 177, 88)');
        pinBody.setAttribute('stroke', '#ffffff');
        pinBody.setAttribute('stroke-width', '2');
        
        // Inner circle
        const innerCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        innerCircle.setAttribute('cy', '-5');
        innerCircle.setAttribute('r', '5');
        innerCircle.setAttribute('fill', '#ffffff');
        
        pin.appendChild(shadow);
        pin.appendChild(pinBody);
        pin.appendChild(innerCircle);
        
        // Assemble marker
        markerGroup.appendChild(pulseCircle2);
        markerGroup.appendChild(pulseCircle1);
        markerGroup.appendChild(pin);
        
        mapSVG.appendChild(markerGroup);
        marker = markerGroup;
    }
    
    function handleCountryClick(e) {
        if (!mapSVG) return;
        
        const rect = mapSVG.getBoundingClientRect();
        const svgPoint = mapSVG.createSVGPoint();
        svgPoint.x = e.clientX;
        svgPoint.y = e.clientY;
        
        // Transform to SVG coordinates
        const ctm = mapSVG.getScreenCTM();
        const point = svgPoint.matrixTransform(ctm.inverse());
        
        // Convert to lat/lon
        const lon = (point.x / 2000) * 360 - 180;
        const lat = 90 - (point.y / 857) * 180;
        
        updateLocation(lat, lon);
    }
    
    function setupEventListeners() {
        if (!mapContainer) return;
        
        // Setup click handler on the container
        const svgContainer = document.getElementById('world-map-svg-container');
        if (svgContainer) {
            svgContainer.addEventListener('click', function(e) {
                if (e.target.tagName === 'svg' || e.target.tagName === 'rect') {
                    handleMapClick(e);
                }
            });
        }
    }
    
    function handleMapClick(e) {
        const svgContainer = document.getElementById('world-map-svg-container');
        if (!svgContainer || !mapSVG) return;
        
        const rect = mapSVG.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 2000;
        const y = ((e.clientY - rect.top) / rect.height) * 857;
        
        // Convert to lat/lon
        const lon = (x / 2000) * 360 - 180;
        const lat = 90 - (y / 857) * 180;
        
        updateLocation(lat, lon);
    }
    
    function updateLocation(lat, lon, immediate = true) {
        currentLat = Math.max(-90, Math.min(90, lat));
        currentLon = Math.max(-180, Math.min(180, lon));
        
        updateMarkerPosition(immediate);
        updateDisplay();
        updateAstrolabe();
    }
    
    function updateMarkerPosition(immediate = false) {
        if (!marker || !mapSVG) return;
        
        // Clear existing timer
        if (updateTimer) {
            clearTimeout(updateTimer);
        }
        
        // Function to actually update the marker
        const doUpdate = () => {
            // Convert lat/lon to SVG coordinates
            const x = ((currentLon + 180) / 360) * 2000;
            const y = ((90 - currentLat) / 180) * 857;
            
            marker.setAttribute('transform', `translate(${x}, ${y})`);
        };
        
        if (immediate) {
            doUpdate();
        } else {
            // Debounce: wait 100ms before updating
            updateTimer = setTimeout(doUpdate, 100);
        }
    }
    
    function updateDisplay() {
        // Update location name in control panel
        const locationNameDisplay = document.getElementById('location-name-display');
        if (locationNameDisplay) {
            locationNameDisplay.textContent = getLocationName(currentLat, currentLon);
        }
    }
    
    function updateAstrolabe() {
        // Update latitude slider WITHOUT triggering change event to avoid infinite loop
        const latSlider = document.getElementById('latitudeSlider');
        if (latSlider) {
            $(latSlider).val(currentLat).slider('refresh');
            // DO NOT trigger change - it causes infinite loop!
            // The slider value is already updated visually
        }
        
        // Update longitude slider WITHOUT triggering change event
        const lonSlider = document.getElementById('longitudeSlider');
        if (lonSlider) {
            $(lonSlider).val(currentLon).slider('refresh');
            // DO NOT trigger change - it causes infinite loop!
        }
        
        // Update other displays directly
        const lonElem = document.getElementById('longitude');
        if (lonElem) {
            lonElem.innerHTML = currentLon;
        }
        
        const lonSpan = document.getElementById('lonspan');
        if (lonSpan) {
            lonSpan.textContent = currentLon.toFixed(2);
        }
        
        // Update latitude display
        const latDisplay = document.getElementById('latitude');
        if (latDisplay) {
            latDisplay.textContent = currentLat;
        }
        
        // Manually call the astrolabe update functions
        if (typeof tympanum === 'function') {
            tympanum();
        }
        if (typeof planet_advance === 'function') {
            planet_advance();
        }
        if (document.getElementById("sky_flag") && document.getElementById("sky_flag").innerHTML == 1) {
            if (typeof sky_coloration === 'function') {
                sky_coloration();
            }
        }
    }
    
    function syncWithAstrolabe() {
        // Watch for latitude changes
        const latSlider = document.getElementById('latitudeSlider');
        if (latSlider) {
            currentLat = parseFloat(latSlider.value) || currentLat;
            updateMarkerPosition();
            updateDisplay();
            
            $(latSlider).on('change', function(e) {
                const newLat = parseFloat(e.target.value);
                if (!isNaN(newLat) && newLat !== currentLat) {
                    currentLat = newLat;
                    updateMarkerPosition();
                    updateDisplay();
                }
            });
        }
        
        // Watch for longitude changes
        const lonSlider = document.getElementById('longitudeSlider');
        if (lonSlider) {
            currentLon = parseFloat(lonSlider.value) || currentLon;
            updateMarkerPosition();
            updateDisplay();
            
            $(lonSlider).on('change', function(e) {
                const newLon = parseFloat(e.target.value);
                if (!isNaN(newLon) && newLon !== currentLon) {
                    currentLon = newLon;
                    updateMarkerPosition();
                    updateDisplay();
                }
            });
        }
    }
    
    function getLocationName(lat, lon) {
        // Country-based location detection
        const countries = [
            // North America
            { name: 'USA', bounds: { lat: [24, 49], lon: [-125, -66] } },
            { name: 'Canada', bounds: { lat: [49, 75], lon: [-141, -52] } },
            { name: 'Mexico', bounds: { lat: [14, 33], lon: [-118, -86] } },
            
            // Europe
            { name: 'UK', bounds: { lat: [49, 61], lon: [-8, 2] } },
            { name: 'France', bounds: { lat: [41, 51], lon: [-5, 10] } },
            { name: 'Germany', bounds: { lat: [47, 55], lon: [5, 15] } },
            { name: 'Italy', bounds: { lat: [36, 47], lon: [6, 19] } },
            { name: 'Spain', bounds: { lat: [36, 44], lon: [-9, 4] } },
            { name: 'Turkey', bounds: { lat: [36, 42], lon: [26, 45] } },
            { name: 'Poland', bounds: { lat: [49, 55], lon: [14, 24] } },
            { name: 'Netherlands', bounds: { lat: [50, 54], lon: [3, 8] } },
            { name: 'Belgium', bounds: { lat: [49, 52], lon: [2, 7] } },
            { name: 'Greece', bounds: { lat: [34, 42], lon: [19, 29] } },
            { name: 'Portugal', bounds: { lat: [37, 42], lon: [-10, -6] } },
            { name: 'Sweden', bounds: { lat: [55, 70], lon: [11, 24] } },
            { name: 'Norway', bounds: { lat: [58, 72], lon: [4, 31] } },
            { name: 'Finland', bounds: { lat: [59, 70], lon: [20, 32] } },
            { name: 'Denmark', bounds: { lat: [54, 58], lon: [8, 13] } },
            { name: 'Switzerland', bounds: { lat: [45, 48], lon: [5, 11] } },
            { name: 'Austria', bounds: { lat: [46, 49], lon: [9, 17] } },
            
            // Asia
            { name: 'Russia', bounds: { lat: [41, 82], lon: [27, 180] } },
            { name: 'China', bounds: { lat: [18, 54], lon: [73, 135] } },
            { name: 'Japan', bounds: { lat: [30, 46], lon: [129, 146] } },
            { name: 'India', bounds: { lat: [8, 35], lon: [68, 97] } },
            { name: 'South Korea', bounds: { lat: [33, 39], lon: [124, 132] } },
            { name: 'Indonesia', bounds: { lat: [-11, 6], lon: [95, 141] } },
            { name: 'Thailand', bounds: { lat: [5, 21], lon: [97, 106] } },
            { name: 'Vietnam', bounds: { lat: [8, 24], lon: [102, 110] } },
            { name: 'Philippines', bounds: { lat: [4, 21], lon: [116, 127] } },
            { name: 'Malaysia', bounds: { lat: [0, 8], lon: [99, 120] } },
            { name: 'Singapore', bounds: { lat: [1, 2], lon: [103, 104] } },
            
            // Middle East
            { name: 'Saudi Arabia', bounds: { lat: [16, 32], lon: [34, 56] } },
            { name: 'Iran', bounds: { lat: [25, 40], lon: [44, 64] } },
            { name: 'Iraq', bounds: { lat: [29, 38], lon: [38, 49] } },
            { name: 'Israel', bounds: { lat: [29, 34], lon: [34, 36] } },
            { name: 'UAE', bounds: { lat: [22, 27], lon: [51, 57] } },
            { name: 'Egypt', bounds: { lat: [22, 32], lon: [25, 37] } },
            
            // South America
            { name: 'Brazil', bounds: { lat: [-34, 5], lon: [-74, -34] } },
            { name: 'Argentina', bounds: { lat: [-55, -22], lon: [-74, -53] } },
            { name: 'Chile', bounds: { lat: [-56, -17], lon: [-76, -66] } },
            { name: 'Peru', bounds: { lat: [-18, 0], lon: [-82, -68] } },
            { name: 'Colombia', bounds: { lat: [-5, 13], lon: [-79, -66] } },
            { name: 'Venezuela', bounds: { lat: [0, 13], lon: [-73, -59] } },
            
            // Africa
            { name: 'South Africa', bounds: { lat: [-35, -22], lon: [16, 33] } },
            { name: 'Nigeria', bounds: { lat: [4, 14], lon: [2, 15] } },
            { name: 'Kenya', bounds: { lat: [-5, 5], lon: [33, 42] } },
            { name: 'Morocco', bounds: { lat: [27, 36], lon: [-13, -1] } },
            { name: 'Algeria', bounds: { lat: [19, 37], lon: [-9, 12] } },
            
            // Oceania
            { name: 'Australia', bounds: { lat: [-44, -10], lon: [112, 154] } },
            { name: 'New Zealand', bounds: { lat: [-47, -34], lon: [166, 179] } }
        ];
        
        // Check countries first
        for (const country of countries) {
            if (lat >= country.bounds.lat[0] && lat <= country.bounds.lat[1] &&
                lon >= country.bounds.lon[0] && lon <= country.bounds.lon[1]) {
                return country.name;
            }
        }
        
        // Fall back to regions
        const regions = [
            { name: 'North America', bounds: { lat: [15, 75], lon: [-170, -50] } },
            { name: 'South America', bounds: { lat: [-60, 15], lon: [-85, -35] } },
            { name: 'Europe', bounds: { lat: [35, 75], lon: [-15, 40] } },
            { name: 'Africa', bounds: { lat: [-40, 40], lon: [-20, 55] } },
            { name: 'Middle East', bounds: { lat: [10, 45], lon: [25, 65] } },
            { name: 'Asia', bounds: { lat: [0, 75], lon: [40, 150] } },
            { name: 'Oceania', bounds: { lat: [-50, 0], lon: [100, 180] } }
        ];
        
        for (const region of regions) {
            if (lat >= region.bounds.lat[0] && lat <= region.bounds.lat[1] &&
                lon >= region.bounds.lon[0] && lon <= region.bounds.lon[1]) {
                return region.name;
            }
        }
        
        // Default to ocean
        if (lat > -60 && lat < 60) {
            if (lon > -180 && lon < -20) return 'Pacific Ocean';
            if (lon > -20 && lon < 20) return 'Atlantic Ocean';
            if (lon > 20 && lon < 100) return 'Indian Ocean';
            return 'Pacific Ocean';
        }
        
        return 'Ocean';
    }
    
    // Public API
    return {
        init: init,
        setLocation: function(lat, lon) {
            // Only update internal state and marker position, don't update astrolabe
            currentLat = Math.max(-90, Math.min(90, lat));
            currentLon = Math.max(-180, Math.min(180, lon));
            updateMarkerPosition(false); // Use debounced update
            updateDisplay();
            // DO NOT call updateAstrolabe here - it causes infinite loop!
        },
        getLocation: function() {
            return { lat: currentLat, lon: currentLon };
        },
        getLocationName: getLocationName
    };
})();

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', WorldMapEnhanced.init);
} else {
    WorldMapEnhanced.init();
}

// Make WorldMapEnhanced available globally
window.WorldMapEnhanced = WorldMapEnhanced;